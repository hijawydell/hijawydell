===========================
 Jardinains! (version 1.1)
===========================

********************* IMPORTANT *********************
*     Jardinains! REQUIRES DirextX Version 7        *
* or later to run.  DirectX Can be downloaded from: *
*       http://www.microsoft.com/directx/           *
*****************************************************

Jardinains! is a fun new twist on an old classic.  Break bricks, dodge flower pots, bounce nains, and rack up as many points as you can!

This is the first full release of the Jardinains! game.  It's quite stable, quite fun, and quite addictive.  There's bound to be an occasional bug here and there; should you stumble across one, please let me know what happened in as much detail as possible.  Send bug reports to bugs@jardinains.com.

==============
AUTHOR'S TIPS:
==============

* To enter cheat codes, pause the game (P) and press the backtick (`) key, and enter one of the following codes (followed by RETURN):

	-- "gomomgo": extra 30 lives
	-- "uuddlrlrba": instant Brickplow Boomers (powerful balls, indeed)
	-- "they're everywhere": Many, many nains
	-- "20 goto ##": skip to level ## (where ## is a number, eh?)

* Play with the level editor (press 'E' at the main menu!)  Send your own custom levels to levels@jardinains.com...  (levels are located in the jardinains/data/levels/current directory)

* Confused?  Stuck?  Don't forget to read the instruction manual!  If you have any questions, comments, suggestions, or requests, please send them to feedback@jardinains.com.

===========
CHANGE LOG:
===========

Version 1.1:
------------
* Added level pack instruction manual
* Upgraded compiler, eliminated significant numbers of "Illegal Memory Address" issues
* Added game timer: now you can see exactly how long you've been playing Jardinains!
* Cash bonus now worth 10x as much as before
* Modified 2x powerup -- don't get too greedy!
* Tweaked Hard, Insane level settings
* Added Absurdedly High Score support
* Added windowed mode
* Added Continue feature
* Added Boss Button ([K] button, works only during actual gameplay!  Use judiciously--it exits quickly, but may leak memory...)
* Added Hard and Insane difficulty levels
* Added Level Flipping after completion of all levels
* Added keyboard controls
* Fixed small bug where ball went too far into upper edge of playing field
* Fixed bug with design of level 22; no longer possible to become 'stuck' in level
* Fixed game save bug where score multiplier was not being saved
* Improved anti-stuckedness code
* Minor bug fixes, improved game stability
* Fixed minor bug that occasionally caused menu items to activate when returning to menu from game
* Changed ball split powerup from splitting horizontally to splitting vertically
* Added sparklies to the pause screen and main menu, fer cuteness' sake.
* Added "uuddlrlrba" cheat code; does the same thing as "upupdowndownleftrightleftrightbastart" does.

Version 1.01:
-------------
* Fixed small bug with auto-save files

Version 1.0:
--------------------
* Fanfare!  First full release!
* Heavy testing, comfortably version 1 quality
* Laser glitch fixed
* Updated artwork
* Slight modifications to burning
* Incremental auto-saves in case of game crashing
* Fixed typo in change log (heh)
* Other minor bugfixes

Release Candidate 1:
--------------------
* Various little bug fixes
* Added auto-save functionality
* Heavily tested
* Deemed Fit For Release Candidate status

Alpha 4:
--------
* Major bug fix--the notorious game freeze bug has been vanquished!
* Added new music
* Added new levels (to 50)
* Added "remember player" functionality
* Fixed and modified lasers
* Updated graphics
* Improved memory management
* Reduced overall sprite count
* Introduced "fireboxes" in menus
* Added "change" functionality to editor
* Buncha Buncha Other Stuff Performed With The Aid Of My Good Friend, Generic Fermented Vegetable Product(tm)

Alpha 3:
--------

* Successfully created self-installing package.
* Added "Current Player" display on main menu.
* Lotsa Other Stuff.  Mostly piddly little bug fixes.


Alpha 2:
--------

* First PUBLIC release.
* Fixed several bugs that caused "Illegal Memory Address" errors to occur.
* Fixed the "Neverending-bouncing ball" problem.
* Added "Current Player" display and copyright notice to main menu.
* Made minor modifications to artwork.
* Nains 150% as likely as before to throw flowerpots.
* Added Screenshot capablility.
* Added sound prefs memory.
* Fixed a minor bug in high score update.
* Fixed a minor bug with cheat codes.
* Fixed a bug with the sound that caused the music to stop playing after lots of explosions at once.
* Modified brickbomb, laser powerups.
* Made minor modifications to certain levels; added levels 41 and 42.
* Various and sundry changes I can't think of right now

Alpha 1:
--------
* First Alpha Release.


==========
THANK YOU!
==========


This software is provided AS IS, without any warranty.  You are solely responsible for anything that may occur as a result of installing or using this software.  This software is NOT for use in mission-critical applications, either, though I would -love- to hear excatly how you would use this for a mission-critical application.

Copyright 2001-2002, Thomas Darby (tom@snowplow.org)