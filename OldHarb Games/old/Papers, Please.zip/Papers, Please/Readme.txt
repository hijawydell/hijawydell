
PAPERS, PLEASE
A Dystopian Document Thriller
http://papersplea.se
_______________________________________________________________________________

Congratulations.  

The October labor lottery is complete. 

Your name was pulled.

For immediate placement, report to the The Ministry of Admission at Grestin
Border Checkpoint.  

An apartment will be provided for you and your family in East Grestin. Expect
a Class-8 dwelling.  

Glory to Arstotzka.


The communist state of Arstotzka has just ended a 6-year war with neighboring
Kolechia and reclaimed its rightful half of the border town, Grestin. Your job
as immigration inspector is to control the flow of people entering the
Arstotzkan side of Grestin from Kolechia. Among the throngs of immigrants and
visitors looking for work are hidden smugglers, spies, and terrorists. Using
only the documents provided by travelers and the Ministry of Admission's
primitive inspect, search, and fingerprint systems you must decide who can
enter Arstotzka and who will be turned away or arrested.

_______________________________________________________________________________

If you have trouble running the game, notice bugs, or have any other issues, 
please visit http://papersplea.se/support

Thank you!

- Lucas Pope

_______________________________________________________________________________
Version 1.0.33
