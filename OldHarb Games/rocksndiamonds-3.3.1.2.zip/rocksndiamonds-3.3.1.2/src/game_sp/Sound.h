// ----------------------------------------------------------------------------
// Sound.h
// ----------------------------------------------------------------------------

#ifndef GAME_SP_SOUND_H
#define GAME_SP_SOUND_H

#include "global.h"


extern void subSoundFX(int, int, int);

#endif /* GAME_SP_SOUND_H */
