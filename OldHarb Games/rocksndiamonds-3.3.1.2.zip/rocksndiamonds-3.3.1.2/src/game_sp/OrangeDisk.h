// ----------------------------------------------------------------------------
// OrangeDisk.h
// ----------------------------------------------------------------------------

#ifndef ORANGEDISK_H
#define ORANGEDISK_H

#include "global.h"


extern void subAnimateOrangeDisks(int);

#endif /* ORANGEDISK_H */
