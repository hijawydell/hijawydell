// ----------------------------------------------------------------------------
// DDSpriteBuffer.h
// ----------------------------------------------------------------------------

#ifndef DDSPRITEBUFFER_H
#define DDSPRITEBUFFER_H

#include "global.h"


extern void DDSpriteBuffer_BltImg(int pX, int pY, int graphic, int sync_frame);

#endif /* DDSPRITEBUFFER_H */
