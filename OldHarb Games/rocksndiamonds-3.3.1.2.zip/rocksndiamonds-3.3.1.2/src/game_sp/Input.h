// ----------------------------------------------------------------------------
// Input.h
// ----------------------------------------------------------------------------

#ifndef INPUT_H
#define INPUT_H

#include "global.h"


extern void subProcessKeyboardInput(byte);

#endif /* INPUT_H */
