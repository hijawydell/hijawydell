/***********************************************************
* Artsoft Retro-Game Library                               *
*----------------------------------------------------------*
* (c) 1994-2006 Artsoft Entertainment                      *
*               Holger Schemel                             *
*               Detmolder Strasse 189                      *
*               33604 Bielefeld                            *
*               Germany                                    *
*               e-mail: info@artsoft.org                   *
*----------------------------------------------------------*
* game_sp.h                                                *
***********************************************************/

#ifndef GAME_SP_H
#define GAME_SP_H

#define GAME_SP_VERSION_1_0_0

#include "export.h"

#endif	/* GAME_SP_H */
