// ----------------------------------------------------------------------------
// Infotrons.h
// ----------------------------------------------------------------------------

#ifndef INFOTRONS_H
#define INFOTRONS_H

#include "global.h"


extern void subAnimateInfotrons(int);
extern void subCleanUpForInfotronsAbove(int);

#endif /* INFOTRONS_H */
