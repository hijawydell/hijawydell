/***********************************************************
* Rocks'n'Diamonds -- McDuffin Strikes Back!               *
*----------------------------------------------------------*
* (c) 1995-2006 Artsoft Entertainment                      *
*               Holger Schemel                             *
*               Detmolder Strasse 189                      *
*               33604 Bielefeld                            *
*               Germany                                    *
*               e-mail: info@artsoft.org                   *
*----------------------------------------------------------*
* tools.c                                                  *
***********************************************************/

#include "libgame/libgame.h"

#include "tools.h"
#include "init.h"
#include "game.h"
#include "events.h"
#include "cartoons.h"
#include "network.h"
#include "tape.h"
#include "screens.h"


/* select level set with EMC X11 graphics before activating EM GFX debugging */
#define DEBUG_EM_GFX	0

/* tool button identifiers */
#define TOOL_CTRL_ID_YES	0
#define TOOL_CTRL_ID_NO		1
#define TOOL_CTRL_ID_CONFIRM	2
#define TOOL_CTRL_ID_PLAYER_1	3
#define TOOL_CTRL_ID_PLAYER_2	4
#define TOOL_CTRL_ID_PLAYER_3	5
#define TOOL_CTRL_ID_PLAYER_4	6

#define NUM_TOOL_BUTTONS	7

/* forward declaration for internal use */
static void UnmapToolButtons();
static void HandleToolButtons(struct GadgetInfo *);
static int el_act_dir2crm(int, int, int);
static int el_act2crm(int, int);

static struct GadgetInfo *tool_gadget[NUM_TOOL_BUTTONS];
static int request_gadget_id = -1;

static char *print_if_not_empty(int element)
{
  static char *s = NULL;
  char *token_name = element_info[element].token_name;

  if (s != NULL)
    free(s);

  s = checked_malloc(strlen(token_name) + 10 + 1);

  if (element != EL_EMPTY)
    sprintf(s, "%d\t['%s']", element, token_name);
  else
    sprintf(s, "%d", element);

  return s;
}

void DumpTile(int x, int y)
{
  int sx = SCREENX(x);
  int sy = SCREENY(y);

  if (level.game_engine_type == GAME_ENGINE_TYPE_EM)
  {
    x--;
    y--;
  }

  printf_line("-", 79);
  printf("Field Info: SCREEN(%d, %d), LEVEL(%d, %d)\n", sx, sy, x, y);
  printf_line("-", 79);

  if (!IN_LEV_FIELD(x, y))
  {
    printf("(not in level field)\n");
    printf("\n");

    return;
  }

  printf("  Feld:        %d\t['%s']\n", Feld[x][y],
	 element_info[Feld[x][y]].token_name);
  printf("  Back:        %s\n", print_if_not_empty(Back[x][y]));
  printf("  Store:       %s\n", print_if_not_empty(Store[x][y]));
  printf("  Store2:      %s\n", print_if_not_empty(Store2[x][y]));
  printf("  StorePlayer: %s\n", print_if_not_empty(StorePlayer[x][y]));
  printf("  MovPos:      %d\n", MovPos[x][y]);
  printf("  MovDir:      %d\n", MovDir[x][y]);
  printf("  MovDelay:    %d\n", MovDelay[x][y]);
  printf("  ChangeDelay: %d\n", ChangeDelay[x][y]);
  printf("  CustomValue: %d\n", CustomValue[x][y]);
  printf("  GfxElement:  %d\n", GfxElement[x][y]);
  printf("  GfxAction:   %d\n", GfxAction[x][y]);
  printf("  GfxFrame:    %d\n", GfxFrame[x][y]);
  printf("\n");
}

void SetDrawtoField(int mode)
{
  if (mode == DRAW_BUFFERED && setup.soft_scrolling)
  {
#if NEW_TILESIZE
#if NEW_SCROLL
    FX = 2 * TILEX_VAR;
    FY = 2 * TILEY_VAR;
    BX1 = -2;
    BY1 = -2;
    BX2 = SCR_FIELDX + 1;
    BY2 = SCR_FIELDY + 1;
    redraw_x1 = 2;
    redraw_y1 = 2;
#else
    FX = TILEX_VAR;
    FY = TILEY_VAR;
    BX1 = -1;
    BY1 = -1;
    BX2 = SCR_FIELDX;
    BY2 = SCR_FIELDY;
    redraw_x1 = 1;
    redraw_y1 = 1;
#endif
#else
#if NEW_SCROLL
    FX = 2 * TILEX;
    FY = 2 * TILEY;
    BX1 = -2;
    BY1 = -2;
    BX2 = SCR_FIELDX + 1;
    BY2 = SCR_FIELDY + 1;
    redraw_x1 = 2;
    redraw_y1 = 2;
#else
    FX = TILEX;
    FY = TILEY;
    BX1 = -1;
    BY1 = -1;
    BX2 = SCR_FIELDX;
    BY2 = SCR_FIELDY;
    redraw_x1 = 1;
    redraw_y1 = 1;
#endif
#endif

    drawto_field = fieldbuffer;
  }
  else	/* DRAW_BACKBUFFER */
  {
    FX = SX;
    FY = SY;
    BX1 = 0;
    BY1 = 0;
    BX2 = SCR_FIELDX - 1;
    BY2 = SCR_FIELDY - 1;
    redraw_x1 = 0;
    redraw_y1 = 0;

    drawto_field = backbuffer;
  }
}

void RedrawPlayfield(boolean force_redraw, int x, int y, int width, int height)
{
  if (game_status == GAME_MODE_PLAYING &&
      level.game_engine_type == GAME_ENGINE_TYPE_EM)
  {
    /* currently there is no partial redraw -- always redraw whole playfield */
    RedrawPlayfield_EM(TRUE);

    /* blit playfield from scroll buffer to normal back buffer for fading in */
    BlitScreenToBitmap_EM(backbuffer);
  }
  else if (game_status == GAME_MODE_PLAYING &&
	   level.game_engine_type == GAME_ENGINE_TYPE_SP)
  {
    /* currently there is no partial redraw -- always redraw whole playfield */
    RedrawPlayfield_SP(TRUE);

    /* blit playfield from scroll buffer to normal back buffer for fading in */
    BlitScreenToBitmap_SP(backbuffer);
  }
  else if (game_status == GAME_MODE_PLAYING &&
	   !game.envelope_active)
  {
    if (force_redraw)
    {
      x = gfx.sx - TILEX;
      y = gfx.sy - TILEY;
      width = gfx.sxsize + 2 * TILEX;
      height = gfx.sysize + 2 * TILEY;
    }

    if (force_redraw)
    {
      int xx, yy;
      int x1 = (x - SX) / TILEX, y1 = (y - SY) / TILEY;
      int x2 = (x - SX + width) / TILEX, y2 = (y - SY + height) / TILEY;

      for (xx = BX1; xx <= BX2; xx++)
	for (yy = BY1; yy <= BY2; yy++)
	  if (xx >= x1 && xx <= x2 && yy >= y1 && yy <= y2)
	    DrawScreenField(xx, yy);
      DrawAllPlayers();
    }

    if (setup.soft_scrolling)
    {
      int fx = FX, fy = FY;

      fx += (ScreenMovDir & (MV_LEFT|MV_RIGHT) ? ScreenGfxPos : 0);
      fy += (ScreenMovDir & (MV_UP|MV_DOWN)    ? ScreenGfxPos : 0);

      BlitBitmap(fieldbuffer, backbuffer, fx,fy, SXSIZE,SYSIZE, SX,SY);
    }
  }

  if (force_redraw)
  {
    x = gfx.sx;
    y = gfx.sy;
    width = gfx.sxsize;
    height = gfx.sysize;
  }

  BlitBitmap(drawto, window, x, y, width, height, x, y);
}

void DrawMaskedBorder_Rect(int x, int y, int width, int height)
{
  Bitmap *bitmap = graphic_info[IMG_GLOBAL_BORDER].bitmap;

  SetClipOrigin(bitmap, bitmap->stored_clip_gc, 0, 0);
  BlitBitmapMasked(bitmap, backbuffer, x, y, width, height, x, y);
}

void DrawMaskedBorder_FIELD()
{
  if (global.border_status >= GAME_MODE_TITLE &&
      global.border_status <= GAME_MODE_PLAYING &&
      border.draw_masked[global.border_status])
    DrawMaskedBorder_Rect(REAL_SX, REAL_SY, FULL_SXSIZE, FULL_SYSIZE);
}

void DrawMaskedBorder_DOOR_1()
{
  if (border.draw_masked[GFX_SPECIAL_ARG_DOOR] &&
      (global.border_status != GAME_MODE_EDITOR ||
       border.draw_masked[GFX_SPECIAL_ARG_EDITOR]))
    DrawMaskedBorder_Rect(DX, DY, DXSIZE, DYSIZE);
}

void DrawMaskedBorder_DOOR_2()
{
  if (border.draw_masked[GFX_SPECIAL_ARG_DOOR] &&
      global.border_status != GAME_MODE_EDITOR)
    DrawMaskedBorder_Rect(VX, VY, VXSIZE, VYSIZE);
}

void DrawMaskedBorder_DOOR_3()
{
  /* currently not available */
}

void DrawMaskedBorder_ALL()
{
  DrawMaskedBorder_FIELD();
  DrawMaskedBorder_DOOR_1();
  DrawMaskedBorder_DOOR_2();
  DrawMaskedBorder_DOOR_3();
}

void DrawMaskedBorder(int redraw_mask)
{
  /* never draw masked screen borders on borderless screens */
  if (effectiveGameStatus() == GAME_MODE_LOADING ||
      effectiveGameStatus() == GAME_MODE_TITLE)
    return;

  /* never draw masked screen borders when displaying request outside door */
  if (effectiveGameStatus() == GAME_MODE_PSEUDO_DOOR &&
      global.use_envelope_request)
    return;

  if (redraw_mask & REDRAW_ALL)
    DrawMaskedBorder_ALL();
  else
  {
    if (redraw_mask & REDRAW_FIELD)
      DrawMaskedBorder_FIELD();
    if (redraw_mask & REDRAW_DOOR_1)
      DrawMaskedBorder_DOOR_1();
    if (redraw_mask & REDRAW_DOOR_2)
      DrawMaskedBorder_DOOR_2();
    if (redraw_mask & REDRAW_DOOR_3)
      DrawMaskedBorder_DOOR_3();
  }
}

void BlitScreenToBitmap(Bitmap *target_bitmap)
{
  DrawBuffer *buffer = (drawto_field == window ? backbuffer : drawto_field);
  int fx = FX, fy = FY;

#if NEW_TILESIZE
  int dx = (ScreenMovDir & (MV_LEFT | MV_RIGHT) ? ScreenGfxPos : 0);
  int dy = (ScreenMovDir & (MV_UP | MV_DOWN)    ? ScreenGfxPos : 0);
  int dx_var = dx * TILESIZE_VAR / TILESIZE;
  int dy_var = dy * TILESIZE_VAR / TILESIZE;
  int ffx, ffy;

  // fx += dx * TILESIZE_VAR / TILESIZE;
  // fy += dy * TILESIZE_VAR / TILESIZE;
#else
  fx += (ScreenMovDir & (MV_LEFT | MV_RIGHT) ? ScreenGfxPos : 0);
  fy += (ScreenMovDir & (MV_UP | MV_DOWN)    ? ScreenGfxPos : 0);
#endif

  ffx = (scroll_x - SBX_Left)  * TILEX_VAR + dx_var;
  ffy = (scroll_y - SBY_Upper) * TILEY_VAR + dy_var;

  if (EVEN(SCR_FIELDX))
  {
    if (ffx < SBX_Right * TILEX_VAR + TILEX_VAR / 2 + TILEX_VAR)
      fx += dx_var - MIN(ffx, TILEX_VAR / 2) + TILEX_VAR;
    else
      fx += (dx_var > 0 ? TILEX_VAR : 0);
  }
  else
  {
    fx += dx_var;
  }

  if (EVEN(SCR_FIELDY))
  {
    if (ffy < SBY_Lower * TILEY_VAR + TILEY_VAR / 2 + TILEY_VAR)
      fy += dy_var - MIN(ffy, TILEY_VAR / 2) + TILEY_VAR;
    else
      fy += (dy_var > 0 ? TILEY_VAR : 0);
  }
  else
  {
    fy += dy_var;
  }

#if 0
  printf("::: (%d, %d) [(%d / %d, %d / %d)] => %d, %d\n",
	 scroll_x, scroll_y,
	 SBX_Left, SBX_Right,
	 SBY_Upper, SBY_Lower,
	 fx, fy);
#endif

  if (border.draw_masked[GAME_MODE_PLAYING])
  {
    if (buffer != backbuffer)
    {
      /* copy playfield buffer to backbuffer to add masked border */
      BlitBitmap(buffer, backbuffer, fx, fy, SXSIZE, SYSIZE, SX, SY);
      DrawMaskedBorder(REDRAW_FIELD);
    }

    BlitBitmap(backbuffer, target_bitmap,
	       REAL_SX, REAL_SY, FULL_SXSIZE, FULL_SYSIZE,
	       REAL_SX, REAL_SY);
  }
  else
  {
    BlitBitmap(buffer, target_bitmap, fx, fy, SXSIZE, SYSIZE, SX, SY);
  }
}

void BackToFront()
{
  int x, y;
  DrawBuffer *buffer = (drawto_field == window ? backbuffer : drawto_field);

#if 0
  printf("::: TILES TO REFRESH: %d\n", redraw_tiles);
  for (x = 0; x < SCR_FIELDX; x++)
    for (y = 0 ; y < SCR_FIELDY; y++)
      if (redraw[redraw_x1 + x][redraw_y1 + y])
	printf("::: - %d, %d [%s]\n",
	       LEVELX(x), LEVELY(y),
	       EL_NAME(Feld[LEVELX(x)][LEVELY(y)]));
#endif

  if (redraw_mask & REDRAW_TILES && redraw_tiles > REDRAWTILES_THRESHOLD)
    redraw_mask |= REDRAW_FIELD;

#if 0
  // never redraw single tiles, always redraw the whole field
  // (redrawing single tiles up to a certain threshold was faster on old,
  // now legacy graphics, but slows things down on modern graphics now)
  // UPDATE: this is now globally defined by value of REDRAWTILES_THRESHOLD
  if (redraw_mask & REDRAW_TILES)
    redraw_mask |= REDRAW_FIELD;
#endif

#if 0
  /* !!! TEST ONLY !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */
  /* (force full redraw) */
  if (game_status == GAME_MODE_PLAYING)
    redraw_mask |= REDRAW_FIELD;
#endif

  if (redraw_mask & REDRAW_FIELD)
    redraw_mask &= ~REDRAW_TILES;

  if (redraw_mask == REDRAW_NONE)
    return;

#if 0
  printf("::: ");
  if (redraw_mask & REDRAW_ALL)
    printf("[REDRAW_ALL]");
  if (redraw_mask & REDRAW_FIELD)
    printf("[REDRAW_FIELD]");
  if (redraw_mask & REDRAW_TILES)
    printf("[REDRAW_TILES]");
  if (redraw_mask & REDRAW_DOOR_1)
    printf("[REDRAW_DOOR_1]");
  if (redraw_mask & REDRAW_DOOR_2)
    printf("[REDRAW_DOOR_2]");
  if (redraw_mask & REDRAW_FROM_BACKBUFFER)
    printf("[REDRAW_FROM_BACKBUFFER]");
  printf(" [%d]\n", FrameCounter);
#endif

  if (redraw_mask & REDRAW_TILES &&
      game_status == GAME_MODE_PLAYING &&
      border.draw_masked[GAME_MODE_PLAYING])
    redraw_mask |= REDRAW_FIELD;

  if (global.fps_slowdown && game_status == GAME_MODE_PLAYING)
  {
    static boolean last_frame_skipped = FALSE;
    boolean skip_even_when_not_scrolling = TRUE;
    boolean just_scrolling = (ScreenMovDir != 0);
    boolean verbose = FALSE;

    if (global.fps_slowdown_factor > 1 &&
	(FrameCounter % global.fps_slowdown_factor) &&
	(just_scrolling || skip_even_when_not_scrolling))
    {
      redraw_mask &= ~REDRAW_MAIN;

      last_frame_skipped = TRUE;

      if (verbose)
	printf("FRAME SKIPPED\n");
    }
    else
    {
      if (last_frame_skipped)
	redraw_mask |= REDRAW_FIELD;

      last_frame_skipped = FALSE;

      if (verbose)
	printf("frame not skipped\n");
    }
  }

  /* synchronize X11 graphics at this point; if we would synchronize the
     display immediately after the buffer switching (after the XFlush),
     this could mean that we have to wait for the graphics to complete,
     although we could go on doing calculations for the next frame */

  SyncDisplay();

  /* never draw masked border to backbuffer when using playfield buffer */
  if (game_status != GAME_MODE_PLAYING ||
      redraw_mask & REDRAW_FROM_BACKBUFFER ||
      buffer == backbuffer)
    DrawMaskedBorder(redraw_mask);
  else
    DrawMaskedBorder(redraw_mask & REDRAW_DOORS);

  if (redraw_mask & REDRAW_ALL)
  {
    BlitBitmap(backbuffer, window, 0, 0, WIN_XSIZE, WIN_YSIZE, 0, 0);

    redraw_mask = REDRAW_NONE;
  }

  if (redraw_mask & REDRAW_FIELD)
  {
#if 0
    printf("::: REDRAW_FIELD\n");
#endif

    if (game_status != GAME_MODE_PLAYING ||
	redraw_mask & REDRAW_FROM_BACKBUFFER)
    {
      BlitBitmap(backbuffer, window,
		 REAL_SX, REAL_SY, FULL_SXSIZE, FULL_SYSIZE, REAL_SX, REAL_SY);
    }
    else
    {
#if 1
      BlitScreenToBitmap(window);
#else
      int fx = FX, fy = FY;

#if NEW_TILESIZE
      int dx = (ScreenMovDir & (MV_LEFT | MV_RIGHT) ? ScreenGfxPos : 0);
      int dy = (ScreenMovDir & (MV_UP | MV_DOWN)    ? ScreenGfxPos : 0);
      int dx_var = dx * TILESIZE_VAR / TILESIZE;
      int dy_var = dy * TILESIZE_VAR / TILESIZE;
      int ffx, ffy;

      // fx += dx * TILESIZE_VAR / TILESIZE;
      // fy += dy * TILESIZE_VAR / TILESIZE;
#else
      fx += (ScreenMovDir & (MV_LEFT | MV_RIGHT) ? ScreenGfxPos : 0);
      fy += (ScreenMovDir & (MV_UP | MV_DOWN)    ? ScreenGfxPos : 0);
#endif

      /* !!! THIS WORKS !!! */

      printf("::: %d, %d\n", scroll_x, scroll_y);

      ffx = (scroll_x - SBX_Left)  * TILEX_VAR + dx_var;
      ffy = (scroll_y - SBY_Upper) * TILEY_VAR + dy_var;

      if (EVEN(SCR_FIELDX))
      {
	if (ffx < SBX_Right * TILEX_VAR + TILEX_VAR / 2 + TILEX_VAR)
	  fx += dx_var - MIN(ffx, TILEX_VAR / 2) + TILEX_VAR;
	else
	  fx += (dx > 0 ? TILEX_VAR : 0);
      }
      else
      {
	fx += dx;
      }

      if (EVEN(SCR_FIELDY))
      {
	if (ffy < SBY_Lower * TILEY_VAR + TILEY_VAR / 2 + TILEY_VAR)
	  fy += dy_var - MIN(ffy, TILEY_VAR / 2) + TILEY_VAR;
	else
	  fy += (dy > 0 ? TILEY_VAR : 0);
      }
      else
      {
	fy += dy;
      }

      if (border.draw_masked[GAME_MODE_PLAYING])
      {
	if (buffer != backbuffer)
	{
	  /* copy playfield buffer to backbuffer to add masked border */
	  BlitBitmap(buffer, backbuffer, fx, fy, SXSIZE, SYSIZE, SX, SY);
	  DrawMaskedBorder(REDRAW_FIELD);
	}

	BlitBitmap(backbuffer, window,
		   REAL_SX, REAL_SY, FULL_SXSIZE, FULL_SYSIZE,
		   REAL_SX, REAL_SY);
      }
      else
      {
	BlitBitmap(buffer, window, fx, fy, SXSIZE, SYSIZE, SX, SY);
      }
#endif

#if 0
#ifdef DEBUG
      printf("redrawing all (ScreenGfxPos == %d) because %s\n",
	     ScreenGfxPos,
	     (setup.soft_scrolling ?
	      "setup.soft_scrolling" :
	      ABS(ScreenGfxPos) + ScrollStepSize == TILEX ?
	      "ABS(ScreenGfxPos) + ScrollStepSize == TILEX" :
	      ABS(ScreenGfxPos) == ScrollStepSize ?
	      "ABS(ScreenGfxPos) == ScrollStepSize" :
	      "redraw_tiles > REDRAWTILES_THRESHOLD"));
#endif
#endif
    }

    redraw_mask &= ~REDRAW_MAIN;
  }

  if (redraw_mask & REDRAW_DOORS)
  {
    if (redraw_mask & REDRAW_DOOR_1)
      BlitBitmap(backbuffer, window, DX, DY, DXSIZE, DYSIZE, DX, DY);

    if (redraw_mask & REDRAW_DOOR_2)
      BlitBitmap(backbuffer, window, VX, VY, VXSIZE, VYSIZE, VX, VY);

    if (redraw_mask & REDRAW_DOOR_3)
      BlitBitmap(backbuffer, window, EX, EY, EXSIZE, EYSIZE, EX, EY);

    redraw_mask &= ~REDRAW_DOORS;
  }

  if (redraw_mask & REDRAW_MICROLEVEL)
  {
    BlitBitmap(backbuffer, window, SX, SY + 10 * TILEY, SXSIZE, 7 * TILEY,
	       SX, SY + 10 * TILEY);

    redraw_mask &= ~REDRAW_MICROLEVEL;
  }

  if (redraw_mask & REDRAW_TILES)
  {
#if 0
    printf("::: REDRAW_TILES\n");
#endif

#if NEW_TILESIZE

#if 1
    InitGfxClipRegion(TRUE, SX, SY, SXSIZE, SYSIZE);

    {
      int sx = SX; // - (EVEN(SCR_FIELDX) ? TILEX_VAR / 2 : 0);
      int sy = SY; // + (EVEN(SCR_FIELDY) ? TILEY_VAR / 2 : 0);

      int dx = 0, dy = 0;
      int dx_var = dx * TILESIZE_VAR / TILESIZE;
      int dy_var = dy * TILESIZE_VAR / TILESIZE;
      int ffx, ffy;
      int fx = FX, fy = FY;

      int scr_fieldx = SCR_FIELDX + (EVEN(SCR_FIELDX) ? 2 : 0);
      int scr_fieldy = SCR_FIELDY + (EVEN(SCR_FIELDY) ? 2 : 0);

      ffx = (scroll_x - SBX_Left)  * TILEX_VAR + dx_var;
      ffy = (scroll_y - SBY_Upper) * TILEY_VAR + dy_var;

      if (EVEN(SCR_FIELDX))
      {
	if (ffx < SBX_Right * TILEX_VAR + TILEX_VAR / 2 + TILEX_VAR)
	{
	  fx += dx_var - MIN(ffx, TILEX_VAR / 2) + TILEX_VAR;

	  if (fx % TILEX_VAR)
	    sx -= TILEX_VAR / 2;
	  else
	    sx -= TILEX_VAR;
	}
	else
	{
	  fx += (dx_var > 0 ? TILEX_VAR : 0);
	}
      }

      if (EVEN(SCR_FIELDY))
      {
	if (ffy < SBY_Lower * TILEY_VAR + TILEY_VAR / 2 + TILEY_VAR)
	{
	  fy += dy_var - MIN(ffy, TILEY_VAR / 2) + TILEY_VAR;

	  if (fy % TILEY_VAR)
	    sy -= TILEY_VAR / 2;
	  else
	    sy -= TILEY_VAR;
	}
	else
	{
	  fy += (dy_var > 0 ? TILEY_VAR : 0);
	}
      }

#if 0
      printf("::: %d, %d, %d, %d\n", sx, sy, SCR_FIELDX, SCR_FIELDY);
#endif

      for (x = 0; x < scr_fieldx; x++)
	for (y = 0 ; y < scr_fieldy; y++)
	  if (redraw[redraw_x1 + x][redraw_y1 + y])
	    BlitBitmap(buffer, window,
		       FX + x * TILEX_VAR, FY + y * TILEY_VAR,
		       TILEX_VAR, TILEY_VAR,
		       sx + x * TILEX_VAR, sy + y * TILEY_VAR);
    }

    InitGfxClipRegion(FALSE, -1, -1, -1, -1);
#else
    for (x = 0; x < SCR_FIELDX; x++)
      for (y = 0 ; y < SCR_FIELDY; y++)
	if (redraw[redraw_x1 + x][redraw_y1 + y])
	  BlitBitmap(buffer, window,
		     FX + x * TILEX_VAR, FY + y * TILEY_VAR,
		     TILEX_VAR, TILEY_VAR,
		     SX + x * TILEX_VAR, SY + y * TILEY_VAR);
#endif

#else
    for (x = 0; x < SCR_FIELDX; x++)
      for (y = 0 ; y < SCR_FIELDY; y++)
	if (redraw[redraw_x1 + x][redraw_y1 + y])
	  BlitBitmap(buffer, window,
		     FX + x * TILEX, FY + y * TILEY, TILEX, TILEY,
		     SX + x * TILEX, SY + y * TILEY);
#endif
  }

  if (redraw_mask & REDRAW_FPS)		/* display frames per second */
  {
    char text[100];
    char info1[100];

    sprintf(info1, " (only every %d. frame)", global.fps_slowdown_factor);
    if (!global.fps_slowdown)
      info1[0] = '\0';

    sprintf(text, "%04.1f fps%s", global.frames_per_second, info1);
#if 1
    DrawTextExt(window, SX + SXSIZE + SX, 0, text, FONT_TEXT_2, BLIT_OPAQUE);
#else
    DrawTextExt(window, SX, SY, text, FONT_TEXT_2, BLIT_OPAQUE);
#endif
  }

  FlushDisplay();

  for (x = 0; x < MAX_BUF_XSIZE; x++)
    for (y = 0; y < MAX_BUF_YSIZE; y++)
      redraw[x][y] = 0;
  redraw_tiles = 0;
  redraw_mask = REDRAW_NONE;
}

static void FadeCrossSaveBackbuffer()
{
  BlitBitmap(backbuffer, bitmap_db_cross, 0, 0, WIN_XSIZE, WIN_YSIZE, 0, 0);
}

static void FadeExt(int fade_mask, int fade_mode, int fade_type)
{
  static int fade_type_skip = FADE_TYPE_NONE;
  void (*draw_border_function)(void) = NULL;
  Bitmap *bitmap = (fade_mode & FADE_TYPE_TRANSFORM ? bitmap_db_cross : NULL);
  int x, y, width, height;
  int fade_delay, post_delay;

  if (fade_type == FADE_TYPE_FADE_OUT)
  {
    if (fade_type_skip != FADE_TYPE_NONE)
    {
#if 0
      printf("::: skipping %d ... [%d] (X)\n", fade_mode, fade_type_skip);
#endif

      /* skip all fade operations until specified fade operation */
      if (fade_type & fade_type_skip)
	fade_type_skip = FADE_TYPE_NONE;

      return;
    }

    if (fading.fade_mode & FADE_TYPE_TRANSFORM)
    {
      FadeCrossSaveBackbuffer();

      return;
    }
  }

  redraw_mask |= fade_mask;

  if (fade_type == FADE_TYPE_SKIP)
  {
#if 0
    printf("::: will skip %d ... [%d]\n", fade_mode, fade_type_skip);
#endif

    fade_type_skip = fade_mode;

    return;
  }

#if 0
  printf("::: !!! FADING %d ... [%d] [%d]\n", fade_mode, fade_type,
	 fade_type_skip);
#endif

#if 1
  fade_delay = fading.fade_delay;
  post_delay = (fade_mode == FADE_MODE_FADE_OUT ? fading.post_delay : 0);
#endif

  if (fade_type_skip != FADE_TYPE_NONE)
  {
#if 0
    printf("::: skipping %d ... [%d]\n", fade_mode, fade_type_skip);
#endif

    /* skip all fade operations until specified fade operation */
    if (fade_type & fade_type_skip)
      fade_type_skip = FADE_TYPE_NONE;

#if 1
    fade_delay = 0;
#else
    return;
#endif
  }

#if 1
  if (global.autoplay_leveldir)
  {
    // fading.fade_mode = FADE_MODE_NONE;

    return;
  }
#endif

#if 0
  if (fading.fade_mode == FADE_MODE_NONE)
  {
    BackToFront();

    return;
  }
#endif

  /* !!! what about fade_mask == REDRAW_FIELD | REDRAW_ALL ??? !!! */

#if 0
  printf("::: NOW FADING %d ... [%d]\n", fade_mode, fade_type);
#endif

#if 0
  if (fade_mask == REDRAW_NONE)
    fade_mask = REDRAW_FIELD;
#endif

  // if (fade_mask & REDRAW_FIELD)
  if (fade_mask == REDRAW_FIELD)
  {
    x = REAL_SX;
    y = REAL_SY;
    width  = FULL_SXSIZE;
    height = FULL_SYSIZE;

#if 0
    fade_delay = fading.fade_delay;
    post_delay = (fade_mode == FADE_MODE_FADE_OUT ? fading.post_delay : 0);
#endif

    if (border.draw_masked_when_fading)
      draw_border_function = DrawMaskedBorder_FIELD;	/* update when fading */
    else
      DrawMaskedBorder_FIELD();				/* draw once */
  }
  else		/* REDRAW_ALL */
  {
    x = 0;
    y = 0;
    width  = WIN_XSIZE;
    height = WIN_YSIZE;

#if 0
    fade_delay = fading.fade_delay;
    post_delay = (fade_mode == FADE_MODE_FADE_OUT ? fading.post_delay : 0);
#endif
  }

#if 1
  if (!setup.fade_screens ||
      fade_delay == 0 ||
      fading.fade_mode == FADE_MODE_NONE)
#else
  if (!setup.fade_screens || fade_delay == 0)
#endif
  {
    if (fade_mode == FADE_MODE_FADE_OUT)
      return;

#if 0
    if (fade_mode == FADE_MODE_FADE_OUT &&
	fading.fade_mode != FADE_MODE_NONE)
      ClearRectangle(backbuffer, x, y, width, height);
#endif

#if 1
    BlitBitmap(backbuffer, window, x, y, width, height, x, y);
    redraw_mask = REDRAW_NONE;
#else
    BackToFront();
#endif

    return;
  }

  FadeRectangle(bitmap, x, y, width, height, fade_mode, fade_delay, post_delay,
		draw_border_function);

  redraw_mask &= ~fade_mask;
}

void FadeIn(int fade_mask)
{
  if (fading.fade_mode & FADE_TYPE_TRANSFORM)
    FadeExt(fade_mask, fading.fade_mode, FADE_TYPE_FADE_IN);
  else
    FadeExt(fade_mask, FADE_MODE_FADE_IN, FADE_TYPE_FADE_IN);
}

void FadeOut(int fade_mask)
{
  if (fading.fade_mode & FADE_TYPE_TRANSFORM)
    FadeExt(fade_mask, fading.fade_mode, FADE_TYPE_FADE_OUT);
  else
    FadeExt(fade_mask, FADE_MODE_FADE_OUT, FADE_TYPE_FADE_OUT);

  global.border_status = game_status;
}

static void FadeSetLeaveNext(struct TitleFadingInfo fading_leave, boolean set)
{
  static struct TitleFadingInfo fading_leave_stored;

  if (set)
    fading_leave_stored = fading_leave;
  else
    fading = fading_leave_stored;
}

void FadeSetEnterMenu()
{
  fading = menu.enter_menu;

#if 0
  printf("::: storing enter_menu\n");
#endif

  FadeSetLeaveNext(fading, TRUE);	/* (keep same fade mode) */
}

void FadeSetLeaveMenu()
{
  fading = menu.leave_menu;

#if 0
  printf("::: storing leave_menu\n");
#endif

  FadeSetLeaveNext(fading, TRUE);	/* (keep same fade mode) */
}

void FadeSetEnterScreen()
{
  fading = menu.enter_screen[game_status];

#if 0
  printf("::: storing leave_screen[%d]\n", game_status);
#endif

  FadeSetLeaveNext(menu.leave_screen[game_status], TRUE);	/* store */
}

void FadeSetNextScreen()
{
  fading = menu.next_screen;

#if 0
  printf("::: storing next_screen\n");
#endif

  // (do not overwrite fade mode set by FadeSetEnterScreen)
  // FadeSetLeaveNext(fading, TRUE);	/* (keep same fade mode) */
}

void FadeSetLeaveScreen()
{
#if 0
  printf("::: recalling last stored value\n");
#endif

  FadeSetLeaveNext(menu.leave_screen[game_status], FALSE);	/* recall */
}

void FadeSetFromType(int type)
{
  if (type & TYPE_ENTER_SCREEN)
    FadeSetEnterScreen();
  else if (type & TYPE_ENTER)
    FadeSetEnterMenu();
  else if (type & TYPE_LEAVE)
    FadeSetLeaveMenu();
}

void FadeSetDisabled()
{
  static struct TitleFadingInfo fading_none = { FADE_MODE_NONE, -1, -1, -1 };

  fading = fading_none;
}

void FadeSkipNextFadeIn()
{
  FadeExt(0, FADE_MODE_SKIP_FADE_IN, FADE_TYPE_SKIP);
}

void FadeSkipNextFadeOut()
{
  FadeExt(0, FADE_MODE_SKIP_FADE_OUT, FADE_TYPE_SKIP);
}

void SetWindowBackgroundImageIfDefined(int graphic)
{
  if (graphic_info[graphic].bitmap)
    SetWindowBackgroundBitmap(graphic_info[graphic].bitmap);
}

void SetMainBackgroundImageIfDefined(int graphic)
{
  if (graphic_info[graphic].bitmap)
    SetMainBackgroundBitmap(graphic_info[graphic].bitmap);
}

void SetDoorBackgroundImageIfDefined(int graphic)
{
  if (graphic_info[graphic].bitmap)
    SetDoorBackgroundBitmap(graphic_info[graphic].bitmap);
}

void SetWindowBackgroundImage(int graphic)
{
  SetWindowBackgroundBitmap(graphic == IMG_UNDEFINED ? NULL :
			    graphic_info[graphic].bitmap ?
			    graphic_info[graphic].bitmap :
			    graphic_info[IMG_BACKGROUND].bitmap);
}

void SetMainBackgroundImage(int graphic)
{
  SetMainBackgroundBitmap(graphic == IMG_UNDEFINED ? NULL :
			  graphic_info[graphic].bitmap ?
			  graphic_info[graphic].bitmap :
			  graphic_info[IMG_BACKGROUND].bitmap);
}

void SetDoorBackgroundImage(int graphic)
{
  SetDoorBackgroundBitmap(graphic == IMG_UNDEFINED ? NULL :
			  graphic_info[graphic].bitmap ?
			  graphic_info[graphic].bitmap :
			  graphic_info[IMG_BACKGROUND].bitmap);
}

void SetPanelBackground()
{
#if 1
  struct GraphicInfo *gfx = &graphic_info[IMG_BACKGROUND_PANEL];

#if 1
  BlitBitmapTiled(gfx->bitmap, bitmap_db_panel, gfx->src_x, gfx->src_y,
		  gfx->width, gfx->height, 0, 0, DXSIZE, DYSIZE);
#else
  /* (ClearRectangle() only needed if panel bitmap is smaller than panel) */
  ClearRectangle(bitmap_db_panel, DX, DY, DXSIZE, DYSIZE);
  BlitBitmap(gfx->bitmap, bitmap_db_panel, gfx->src_x, gfx->src_y,
	     MIN(gfx->width, DXSIZE), MIN(gfx->height, DYSIZE), 0, 0);
#endif
#else
  BlitBitmap(graphic_info[IMG_GLOBAL_DOOR].bitmap, bitmap_db_panel,
             DOOR_GFX_PAGEX5, DOOR_GFX_PAGEY1, DXSIZE, DYSIZE, 0, 0);
#endif

  SetDoorBackgroundBitmap(bitmap_db_panel);
}

void DrawBackground(int x, int y, int width, int height)
{
  /* !!! "drawto" might still point to playfield buffer here (see below) !!! */
  /* (when entering hall of fame after playing) */
#if 0
  ClearRectangleOnBackground(drawto, x, y, width, height);
#else
  ClearRectangleOnBackground(backbuffer, x, y, width, height);
#endif

#if 1
  /* (this only works for the current arrangement of playfield and panels) */
  if (x < gfx.dx)
    redraw_mask |= REDRAW_FIELD;
  else if (y < gfx.vy)
    redraw_mask |= REDRAW_DOOR_1;
  else
    redraw_mask |= REDRAW_DOOR_2;
#else
  /* (this is just wrong (when drawing to one of the two door panel areas)) */
  redraw_mask |= REDRAW_FIELD;
#endif
}

void DrawBackgroundForFont(int x, int y, int width, int height, int font_nr)
{
  struct FontBitmapInfo *font = getFontBitmapInfo(font_nr);

  if (font->bitmap == NULL)
    return;

  DrawBackground(x, y, width, height);
}

void DrawBackgroundForGraphic(int x, int y, int width, int height, int graphic)
{
  struct GraphicInfo *g = &graphic_info[graphic];

  if (g->bitmap == NULL)
    return;

  DrawBackground(x, y, width, height);
}

void ClearField()
{
  /* !!! "drawto" might still point to playfield buffer here (see above) !!! */
  /* (when entering hall of fame after playing) */
  DrawBackground(REAL_SX, REAL_SY, FULL_SXSIZE, FULL_SYSIZE);

  /* !!! maybe this should be done before clearing the background !!! */
  if (setup.soft_scrolling && game_status == GAME_MODE_PLAYING)
  {
    ClearRectangle(fieldbuffer, 0, 0, FXSIZE, FYSIZE);
    SetDrawtoField(DRAW_BUFFERED);
  }
  else
    SetDrawtoField(DRAW_BACKBUFFER);
}

void MarkTileDirty(int x, int y)
{
  int xx = redraw_x1 + x;
  int yy = redraw_y1 + y;

  if (!redraw[xx][yy])
    redraw_tiles++;

  redraw[xx][yy] = TRUE;
  redraw_mask |= REDRAW_TILES;
}

void SetBorderElement()
{
  int x, y;

  BorderElement = EL_EMPTY;

  for (y = 0; y < lev_fieldy && BorderElement == EL_EMPTY; y++)
  {
    for (x = 0; x < lev_fieldx; x++)
    {
      if (!IS_INDESTRUCTIBLE(Feld[x][y]))
	BorderElement = EL_STEELWALL;

      if (y != 0 && y != lev_fieldy - 1 && x != lev_fieldx - 1)
	x = lev_fieldx - 2;
    }
  }
}

void FloodFillLevel(int from_x, int from_y, int fill_element,
		    short field[MAX_LEV_FIELDX][MAX_LEV_FIELDY],
		    int max_fieldx, int max_fieldy)
{
  int i,x,y;
  int old_element;
  static int check[4][2] = { { -1, 0 }, { 0, -1 }, { 1, 0 }, { 0, 1 } };
  static int safety = 0;

  /* check if starting field still has the desired content */
  if (field[from_x][from_y] == fill_element)
    return;

  safety++;

  if (safety > max_fieldx * max_fieldy)
    Error(ERR_EXIT, "Something went wrong in 'FloodFill()'. Please debug.");

  old_element = field[from_x][from_y];
  field[from_x][from_y] = fill_element;

  for (i = 0; i < 4; i++)
  {
    x = from_x + check[i][0];
    y = from_y + check[i][1];

    if (IN_FIELD(x, y, max_fieldx, max_fieldy) && field[x][y] == old_element)
      FloodFillLevel(x, y, fill_element, field, max_fieldx, max_fieldy);
  }

  safety--;
}

void SetRandomAnimationValue(int x, int y)
{
  gfx.anim_random_frame = GfxRandom[x][y];
}

inline int getGraphicAnimationFrame(int graphic, int sync_frame)
{
  /* animation synchronized with global frame counter, not move position */
  if (graphic_info[graphic].anim_global_sync || sync_frame < 0)
    sync_frame = FrameCounter;

  return getAnimationFrame(graphic_info[graphic].anim_frames,
			   graphic_info[graphic].anim_delay,
			   graphic_info[graphic].anim_mode,
			   graphic_info[graphic].anim_start_frame,
			   sync_frame);
}

void getSizedGraphicSourceExt(int graphic, int frame, int tilesize_raw,
			      Bitmap **bitmap, int *x, int *y,
			      boolean get_backside)
{
  struct
  {
    int width_mult, width_div;
    int height_mult, height_div;
  }
  offset_calc[6] =
  {
    { 15, 16,	2, 3	},	/* 1 x 1 */
    { 7, 8,	2, 3	},	/* 2 x 2 */
    { 3, 4,	2, 3	},	/* 4 x 4 */
    { 1, 2,	2, 3	},	/* 8 x 8 */
    { 0, 1,	2, 3	},	/* 16 x 16 */
    { 0, 1,	0, 1	},	/* 32 x 32 */
  };
  struct GraphicInfo *g = &graphic_info[graphic];
  Bitmap *src_bitmap = g->bitmap;
  int tilesize = MIN(MAX(1, tilesize_raw), TILESIZE);
  int offset_calc_pos = log_2(tilesize);
  int width_mult  = offset_calc[offset_calc_pos].width_mult;
  int width_div   = offset_calc[offset_calc_pos].width_div;
  int height_mult = offset_calc[offset_calc_pos].height_mult;
  int height_div  = offset_calc[offset_calc_pos].height_div;
  int startx = src_bitmap->width * width_mult / width_div;
  int starty = src_bitmap->height * height_mult / height_div;
#if NEW_TILESIZE
  int src_x = (g->src_x + (get_backside ? g->offset2_x : 0)) *
    tilesize / TILESIZE;
  int src_y = (g->src_y + (get_backside ? g->offset2_y : 0)) *
    tilesize / TILESIZE;
#else
  int src_x = g->src_x * tilesize / TILESIZE;
  int src_y = g->src_y * tilesize / TILESIZE;
#endif
  int width = g->width * tilesize / TILESIZE;
  int height = g->height * tilesize / TILESIZE;
  int offset_x = g->offset_x * tilesize / TILESIZE;
  int offset_y = g->offset_y * tilesize / TILESIZE;

  if (g->offset_y == 0)		/* frames are ordered horizontally */
  {
    int max_width = g->anim_frames_per_line * width;
    int pos = (src_y / height) * max_width + src_x + frame * offset_x;

    src_x = pos % max_width;
    src_y = src_y % height + pos / max_width * height;
  }
  else if (g->offset_x == 0)	/* frames are ordered vertically */
  {
    int max_height = g->anim_frames_per_line * height;
    int pos = (src_x / width) * max_height + src_y + frame * offset_y;

    src_x = src_x % width + pos / max_height * width;
    src_y = pos % max_height;
  }
  else				/* frames are ordered diagonally */
  {
    src_x = src_x + frame * offset_x;
    src_y = src_y + frame * offset_y;
  }

  *bitmap = src_bitmap;
  *x = startx + src_x;
  *y = starty + src_y;
}

void getFixedGraphicSourceExt(int graphic, int frame, Bitmap **bitmap,
			      int *x, int *y, boolean get_backside)
{
  getSizedGraphicSourceExt(graphic, frame, TILESIZE, bitmap, x, y,
			   get_backside);
}

void getSizedGraphicSource(int graphic, int frame, int tilesize_raw,
			   Bitmap **bitmap, int *x, int *y)
{
  getSizedGraphicSourceExt(graphic, frame, tilesize_raw, bitmap, x, y, FALSE);
}

void getFixedGraphicSource(int graphic, int frame,
			   Bitmap **bitmap, int *x, int *y)
{
  getSizedGraphicSourceExt(graphic, frame, TILESIZE, bitmap, x, y, FALSE);
}

void getMiniGraphicSource(int graphic, Bitmap **bitmap, int *x, int *y)
{
#if 1
  getSizedGraphicSource(graphic, 0, MINI_TILESIZE, bitmap, x, y);
#else
  struct GraphicInfo *g = &graphic_info[graphic];
  int mini_startx = 0;
  int mini_starty = g->bitmap->height * 2 / 3;

  *bitmap = g->bitmap;
  *x = mini_startx + g->src_x / 2;
  *y = mini_starty + g->src_y / 2;
#endif
}

inline void getGraphicSourceExt(int graphic, int frame, Bitmap **bitmap,
				int *x, int *y, boolean get_backside)
{
  struct GraphicInfo *g = &graphic_info[graphic];
  int src_x = g->src_x + (get_backside ? g->offset2_x : 0);
  int src_y = g->src_y + (get_backside ? g->offset2_y : 0);

#if NEW_TILESIZE
  if (TILESIZE_VAR != TILESIZE)
    return getSizedGraphicSourceExt(graphic, frame, TILESIZE_VAR, bitmap, x, y,
				    get_backside);
#endif

  *bitmap = g->bitmap;

  if (g->offset_y == 0)		/* frames are ordered horizontally */
  {
    int max_width = g->anim_frames_per_line * g->width;
    int pos = (src_y / g->height) * max_width + src_x + frame * g->offset_x;

    *x = pos % max_width;
    *y = src_y % g->height + pos / max_width * g->height;
  }
  else if (g->offset_x == 0)	/* frames are ordered vertically */
  {
    int max_height = g->anim_frames_per_line * g->height;
    int pos = (src_x / g->width) * max_height + src_y + frame * g->offset_y;

    *x = src_x % g->width + pos / max_height * g->width;
    *y = pos % max_height;
  }
  else				/* frames are ordered diagonally */
  {
    *x = src_x + frame * g->offset_x;
    *y = src_y + frame * g->offset_y;
  }
}

void getGraphicSource(int graphic, int frame, Bitmap **bitmap, int *x, int *y)
{
  getGraphicSourceExt(graphic, frame, bitmap, x, y, FALSE);
}

void DrawGraphic(int x, int y, int graphic, int frame)
{
#if DEBUG
  if (!IN_SCR_FIELD(x, y))
  {
    printf("DrawGraphic(): x = %d, y = %d, graphic = %d\n", x, y, graphic);
    printf("DrawGraphic(): This should never happen!\n");
    return;
  }
#endif

#if NEW_TILESIZE
  DrawGraphicExt(drawto_field, FX + x * TILEX_VAR, FY + y * TILEY_VAR, graphic,
		 frame);
#else
  DrawGraphicExt(drawto_field, FX + x * TILEX, FY + y * TILEY, graphic, frame);
#endif
  MarkTileDirty(x, y);
}

void DrawFixedGraphic(int x, int y, int graphic, int frame)
{
#if DEBUG
  if (!IN_SCR_FIELD(x, y))
  {
    printf("DrawGraphic(): x = %d, y = %d, graphic = %d\n", x, y, graphic);
    printf("DrawGraphic(): This should never happen!\n");
    return;
  }
#endif

  DrawFixedGraphicExt(drawto_field, FX + x * TILEX, FY + y * TILEY, graphic,
		      frame);
  MarkTileDirty(x, y);
}

void DrawGraphicExt(DrawBuffer *dst_bitmap, int x, int y, int graphic,
		    int frame)
{
  Bitmap *src_bitmap;
  int src_x, src_y;

  getGraphicSource(graphic, frame, &src_bitmap, &src_x, &src_y);
#if NEW_TILESIZE
  BlitBitmap(src_bitmap, dst_bitmap, src_x, src_y, TILEX_VAR, TILEY_VAR, x, y);
#else
  BlitBitmap(src_bitmap, dst_bitmap, src_x, src_y, TILEX, TILEY, x, y);
#endif
}

void DrawFixedGraphicExt(DrawBuffer *dst_bitmap, int x, int y, int graphic,
			 int frame)
{
  Bitmap *src_bitmap;
  int src_x, src_y;

  getFixedGraphicSource(graphic, frame, &src_bitmap, &src_x, &src_y);
  BlitBitmap(src_bitmap, dst_bitmap, src_x, src_y, TILEX, TILEY, x, y);
}

void DrawGraphicThruMask(int x, int y, int graphic, int frame)
{
#if DEBUG
  if (!IN_SCR_FIELD(x, y))
  {
    printf("DrawGraphicThruMask(): x = %d,y = %d, graphic = %d\n",x,y,graphic);
    printf("DrawGraphicThruMask(): This should never happen!\n");
    return;
  }
#endif

#if NEW_TILESIZE
  DrawGraphicThruMaskExt(drawto_field, FX + x * TILEX_VAR, FY + y * TILEY_VAR,
			 graphic, frame);
#else
  DrawGraphicThruMaskExt(drawto_field, FX + x * TILEX, FY + y * TILEY, graphic,
			 frame);
#endif
  MarkTileDirty(x, y);
}

void DrawFixedGraphicThruMask(int x, int y, int graphic, int frame)
{
#if DEBUG
  if (!IN_SCR_FIELD(x, y))
  {
    printf("DrawGraphicThruMask(): x = %d,y = %d, graphic = %d\n",x,y,graphic);
    printf("DrawGraphicThruMask(): This should never happen!\n");
    return;
  }
#endif

  DrawFixedGraphicThruMaskExt(drawto_field, FX + x * TILEX, FY + y * TILEY,
			      graphic, frame);
  MarkTileDirty(x, y);
}

void DrawGraphicThruMaskExt(DrawBuffer *d, int dst_x, int dst_y, int graphic,
			    int frame)
{
  Bitmap *src_bitmap;
  int src_x, src_y;

  getGraphicSource(graphic, frame, &src_bitmap, &src_x, &src_y);

  SetClipOrigin(src_bitmap, src_bitmap->stored_clip_gc,
		dst_x - src_x, dst_y - src_y);
#if NEW_TILESIZE
  BlitBitmapMasked(src_bitmap, d, src_x, src_y, TILEX_VAR, TILEY_VAR,
		   dst_x, dst_y);
#else
  BlitBitmapMasked(src_bitmap, d, src_x, src_y, TILEX, TILEY, dst_x, dst_y);
#endif
}

void DrawFixedGraphicThruMaskExt(DrawBuffer *d, int dst_x, int dst_y,
				 int graphic, int frame)
{
  Bitmap *src_bitmap;
  int src_x, src_y;

  getFixedGraphicSource(graphic, frame, &src_bitmap, &src_x, &src_y);

  SetClipOrigin(src_bitmap, src_bitmap->stored_clip_gc,
		dst_x - src_x, dst_y - src_y);
  BlitBitmapMasked(src_bitmap, d, src_x, src_y, TILEX, TILEY, dst_x, dst_y);
}

void DrawSizedGraphic(int x, int y, int graphic, int frame, int tilesize)
{
  DrawSizedGraphicExt(drawto, SX + x * tilesize, SY + y * tilesize, graphic,
		      frame, tilesize);
  MarkTileDirty(x / tilesize, y / tilesize);
}

void DrawSizedGraphicExt(DrawBuffer *d, int x, int y, int graphic, int frame,
			 int tilesize)
{
  Bitmap *src_bitmap;
  int src_x, src_y;

  getSizedGraphicSource(graphic, frame, tilesize, &src_bitmap, &src_x, &src_y);
  BlitBitmap(src_bitmap, d, src_x, src_y, tilesize, tilesize, x, y);
}

void DrawMiniGraphic(int x, int y, int graphic)
{
  DrawMiniGraphicExt(drawto, SX + x * MINI_TILEX,SY + y * MINI_TILEY, graphic);
  MarkTileDirty(x / 2, y / 2);
}

void DrawMiniGraphicExt(DrawBuffer *d, int x, int y, int graphic)
{
  Bitmap *src_bitmap;
  int src_x, src_y;

  getMiniGraphicSource(graphic, &src_bitmap, &src_x, &src_y);
  BlitBitmap(src_bitmap, d, src_x, src_y, MINI_TILEX, MINI_TILEY, x, y);
}

inline static void DrawGraphicShiftedNormal(int x, int y, int dx, int dy,
					    int graphic, int frame,
					    int cut_mode, int mask_mode)
{
  Bitmap *src_bitmap;
  int src_x, src_y;
  int dst_x, dst_y;
  int width = TILEX, height = TILEY;
  int cx = 0, cy = 0;

  if (dx || dy)			/* shifted graphic */
  {
    if (x < BX1)		/* object enters playfield from the left */
    {
      x = BX1;
      width = dx;
      cx = TILEX - dx;
      dx = 0;
    }
    else if (x > BX2)		/* object enters playfield from the right */
    {
      x = BX2;
      width = -dx;
      dx = TILEX + dx;
    }
    else if (x==BX1 && dx < 0)	/* object leaves playfield to the left */
    {
      width += dx;
      cx = -dx;
      dx = 0;
    }
    else if (x==BX2 && dx > 0)	/* object leaves playfield to the right */
      width -= dx;
    else if (dx)		/* general horizontal movement */
      MarkTileDirty(x + SIGN(dx), y);

    if (y < BY1)		/* object enters playfield from the top */
    {
      if (cut_mode==CUT_BELOW)	/* object completely above top border */
	return;

      y = BY1;
      height = dy;
      cy = TILEY - dy;
      dy = 0;
    }
    else if (y > BY2)		/* object enters playfield from the bottom */
    {
      y = BY2;
      height = -dy;
      dy = TILEY + dy;
    }
    else if (y==BY1 && dy < 0)	/* object leaves playfield to the top */
    {
      height += dy;
      cy = -dy;
      dy = 0;
    }
    else if (dy > 0 && cut_mode == CUT_ABOVE)
    {
      if (y == BY2)		/* object completely above bottom border */
	return;

      height = dy;
      cy = TILEY - dy;
      dy = TILEY;
      MarkTileDirty(x, y + 1);
    }				/* object leaves playfield to the bottom */
    else if (dy > 0 && (y == BY2 || cut_mode == CUT_BELOW))
      height -= dy;
    else if (dy)		/* general vertical movement */
      MarkTileDirty(x, y + SIGN(dy));
  }

#if DEBUG
  if (!IN_SCR_FIELD(x, y))
  {
    printf("DrawGraphicShifted(): x = %d, y = %d, graphic = %d\n",x,y,graphic);
    printf("DrawGraphicShifted(): This should never happen!\n");
    return;
  }
#endif

#if NEW_TILESIZE
  width = width * TILESIZE_VAR / TILESIZE;
  height = height * TILESIZE_VAR / TILESIZE;
  cx = cx * TILESIZE_VAR / TILESIZE;
  cy = cy * TILESIZE_VAR / TILESIZE;
  dx = dx * TILESIZE_VAR / TILESIZE;
  dy = dy * TILESIZE_VAR / TILESIZE;
#endif

  if (width > 0 && height > 0)
  {
    getGraphicSource(graphic, frame, &src_bitmap, &src_x, &src_y);

    src_x += cx;
    src_y += cy;

#if NEW_TILESIZE
    dst_x = FX + x * TILEX_VAR + dx;
    dst_y = FY + y * TILEY_VAR + dy;
#else
    dst_x = FX + x * TILEX + dx;
    dst_y = FY + y * TILEY + dy;
#endif

    if (mask_mode == USE_MASKING)
    {
      SetClipOrigin(src_bitmap, src_bitmap->stored_clip_gc,
		    dst_x - src_x, dst_y - src_y);
      BlitBitmapMasked(src_bitmap, drawto_field, src_x, src_y, width, height,
		       dst_x, dst_y);
    }
    else
      BlitBitmap(src_bitmap, drawto_field, src_x, src_y, width, height,
		 dst_x, dst_y);

    MarkTileDirty(x, y);
  }
}

inline static void DrawGraphicShiftedDouble(int x, int y, int dx, int dy,
					    int graphic, int frame,
					    int cut_mode, int mask_mode)
{
  Bitmap *src_bitmap;
  int src_x, src_y;
  int dst_x, dst_y;
#if NEW_TILESIZE
  int width = TILEX_VAR, height = TILEY_VAR;
#else
  int width = TILEX, height = TILEY;
#endif
  int x1 = x;
  int y1 = y;
  int x2 = x + SIGN(dx);
  int y2 = y + SIGN(dy);
#if 0
  /* !!! DOES NOT WORK FOR SLOW MOVEMENT !!! */
  int sync_frame = GfxFrame[LEVELX(x)][LEVELY(y)];
#else
  /* movement with two-tile animations must be sync'ed with movement position,
     not with current GfxFrame (which can be higher when using slow movement) */
  int anim_pos = (dx ? ABS(dx) : ABS(dy));
  int anim_frames = graphic_info[graphic].anim_frames;
#if 1
  /* (we also need anim_delay here for movement animations with less frames) */
  int anim_delay = graphic_info[graphic].anim_delay;
  int sync_frame = anim_pos * anim_frames * anim_delay / TILESIZE;
#else
  int sync_frame = anim_pos * anim_frames / TILESIZE;
#endif
#endif
  boolean draw_start_tile = (cut_mode != CUT_ABOVE);	/* only for falling! */
  boolean draw_end_tile   = (cut_mode != CUT_BELOW);	/* only for falling! */

  /* re-calculate animation frame for two-tile movement animation */
  frame = getGraphicAnimationFrame(graphic, sync_frame);

#if 0
#if 0
  printf("::: %d, %d, %d => %d [%d]\n",
	 anim_pos, anim_frames, anim_delay, sync_frame, graphic);
#else
  printf("::: %d, %d => %d\n",
	 anim_pos, anim_frames, sync_frame);
#endif
#endif

#if 0
  printf("::: %d [%d, %d] [%d] [%d]\n", frame, sync_frame, dy,
	 GfxFrame[LEVELX(x)][LEVELY(y)], mask_mode);
#endif

  /* check if movement start graphic inside screen area and should be drawn */
  if (draw_start_tile && IN_SCR_FIELD(x1, y1))
  {
    getGraphicSourceExt(graphic, frame, &src_bitmap, &src_x, &src_y, TRUE);

#if NEW_TILESIZE
    dst_x = FX + x1 * TILEX_VAR;
    dst_y = FY + y1 * TILEY_VAR;
#else
    dst_x = FX + x1 * TILEX;
    dst_y = FY + y1 * TILEY;
#endif

    if (mask_mode == USE_MASKING)
    {
      SetClipOrigin(src_bitmap, src_bitmap->stored_clip_gc,
		    dst_x - src_x, dst_y - src_y);
      BlitBitmapMasked(src_bitmap, drawto_field, src_x, src_y, width, height,
		       dst_x, dst_y);
    }
    else
      BlitBitmap(src_bitmap, drawto_field, src_x, src_y, width, height,
		 dst_x, dst_y);

    MarkTileDirty(x1, y1);
  }

  /* check if movement end graphic inside screen area and should be drawn */
  if (draw_end_tile && IN_SCR_FIELD(x2, y2))
  {
    getGraphicSourceExt(graphic, frame, &src_bitmap, &src_x, &src_y, FALSE);

#if NEW_TILESIZE
    dst_x = FX + x2 * TILEX_VAR;
    dst_y = FY + y2 * TILEY_VAR;
#else
    dst_x = FX + x2 * TILEX;
    dst_y = FY + y2 * TILEY;
#endif

    if (mask_mode == USE_MASKING)
    {
      SetClipOrigin(src_bitmap, src_bitmap->stored_clip_gc,
		    dst_x - src_x, dst_y - src_y);
      BlitBitmapMasked(src_bitmap, drawto_field, src_x, src_y, width, height,
		       dst_x, dst_y);
    }
    else
      BlitBitmap(src_bitmap, drawto_field, src_x, src_y, width, height,
		 dst_x, dst_y);

    MarkTileDirty(x2, y2);
  }
}

static void DrawGraphicShifted(int x, int y, int dx, int dy,
			       int graphic, int frame,
			       int cut_mode, int mask_mode)
{
  if (graphic < 0)
  {
    DrawGraphic(x, y, graphic, frame);

    return;
  }

  if (graphic_info[graphic].double_movement)	/* EM style movement images */
    DrawGraphicShiftedDouble(x, y, dx, dy, graphic, frame, cut_mode,mask_mode);
  else
    DrawGraphicShiftedNormal(x, y, dx, dy, graphic, frame, cut_mode,mask_mode);
}

void DrawGraphicShiftedThruMask(int x, int y, int dx, int dy, int graphic,
				int frame, int cut_mode)
{
  DrawGraphicShifted(x, y, dx, dy, graphic, frame, cut_mode, USE_MASKING);
}

void DrawScreenElementExt(int x, int y, int dx, int dy, int element,
			  int cut_mode, int mask_mode)
{
  int lx = LEVELX(x), ly = LEVELY(y);
  int graphic;
  int frame;

  if (IN_LEV_FIELD(lx, ly))
  {
    SetRandomAnimationValue(lx, ly);

    graphic = el_act_dir2img(element, GfxAction[lx][ly], GfxDir[lx][ly]);
    frame = getGraphicAnimationFrame(graphic, GfxFrame[lx][ly]);

    /* do not use double (EM style) movement graphic when not moving */
    if (graphic_info[graphic].double_movement && !dx && !dy)
    {
      graphic = el_act_dir2img(element, ACTION_DEFAULT, GfxDir[lx][ly]);
      frame = getGraphicAnimationFrame(graphic, GfxFrame[lx][ly]);
    }
  }
  else	/* border element */
  {
    graphic = el2img(element);
    frame = getGraphicAnimationFrame(graphic, -1);
  }

  if (element == EL_EXPANDABLE_WALL)
  {
    boolean left_stopped = FALSE, right_stopped = FALSE;

    if (!IN_LEV_FIELD(lx - 1, ly) || IS_WALL(Feld[lx - 1][ly]))
      left_stopped = TRUE;
    if (!IN_LEV_FIELD(lx + 1, ly) || IS_WALL(Feld[lx + 1][ly]))
      right_stopped = TRUE;

    if (left_stopped && right_stopped)
      graphic = IMG_WALL;
    else if (left_stopped)
    {
      graphic = IMG_EXPANDABLE_WALL_GROWING_RIGHT;
      frame = graphic_info[graphic].anim_frames - 1;
    }
    else if (right_stopped)
    {
      graphic = IMG_EXPANDABLE_WALL_GROWING_LEFT;
      frame = graphic_info[graphic].anim_frames - 1;
    }
  }

  if (dx || dy)
    DrawGraphicShifted(x, y, dx, dy, graphic, frame, cut_mode, mask_mode);
  else if (mask_mode == USE_MASKING)
    DrawGraphicThruMask(x, y, graphic, frame);
  else
    DrawGraphic(x, y, graphic, frame);
}

void DrawLevelElementExt(int x, int y, int dx, int dy, int element,
			 int cut_mode, int mask_mode)
{
  if (IN_LEV_FIELD(x, y) && IN_SCR_FIELD(SCREENX(x), SCREENY(y)))
    DrawScreenElementExt(SCREENX(x), SCREENY(y), dx, dy, element,
			 cut_mode, mask_mode);
}

void DrawScreenElementShifted(int x, int y, int dx, int dy, int element,
			      int cut_mode)
{
  DrawScreenElementExt(x, y, dx, dy, element, cut_mode, NO_MASKING);
}

void DrawLevelElementShifted(int x, int y, int dx, int dy, int element,
			     int cut_mode)
{
  DrawLevelElementExt(x, y, dx, dy, element, cut_mode, NO_MASKING);
}

void DrawLevelElementThruMask(int x, int y, int element)
{
  DrawLevelElementExt(x, y, 0, 0, element, NO_CUTTING, USE_MASKING);
}

void DrawLevelFieldThruMask(int x, int y)
{
  DrawLevelElementExt(x, y, 0, 0, Feld[x][y], NO_CUTTING, USE_MASKING);
}

/* !!! implementation of quicksand is totally broken !!! */
#define IS_CRUMBLED_TILE(x, y, e)					\
	(GFX_CRUMBLED(e) && (!IN_LEV_FIELD(x, y) ||			\
			     !IS_MOVING(x, y) ||			\
			     (e) == EL_QUICKSAND_EMPTYING ||		\
			     (e) == EL_QUICKSAND_FAST_EMPTYING))

static void DrawLevelFieldCrumbledInnerCorners(int x, int y, int dx, int dy,
					       int graphic)
{
  Bitmap *src_bitmap;
  int src_x, src_y;
  int width, height, cx, cy;
  int sx = SCREENX(x), sy = SCREENY(y);
  int crumbled_border_size = graphic_info[graphic].border_size;
  int i;

  getGraphicSource(graphic, 0, &src_bitmap, &src_x, &src_y);

  for (i = 1; i < 4; i++)
  {
    int dxx = (i & 1 ? dx : 0);
    int dyy = (i & 2 ? dy : 0);
    int xx = x + dxx;
    int yy = y + dyy;
    int element = (IN_LEV_FIELD(xx, yy) ? TILE_GFX_ELEMENT(xx, yy) :
		   BorderElement);

    /* check if neighbour field is of same crumble type */
    boolean same = (IS_CRUMBLED_TILE(xx, yy, element) &&
		    graphic_info[graphic].class ==
		    graphic_info[el_act2crm(element, ACTION_DEFAULT)].class);

    /* return if check prevents inner corner */
    if (same == (dxx == dx && dyy == dy))
      return;
  }

  /* if we reach this point, we have an inner corner */

  getGraphicSource(graphic, 1, &src_bitmap, &src_x, &src_y);

#if NEW_TILESIZE
  width  = crumbled_border_size * TILESIZE_VAR / TILESIZE;
  height = crumbled_border_size * TILESIZE_VAR / TILESIZE;
  cx = (dx > 0 ? TILEX - crumbled_border_size : 0) * TILESIZE_VAR / TILESIZE;
  cy = (dy > 0 ? TILEY - crumbled_border_size : 0) * TILESIZE_VAR / TILESIZE;

  BlitBitmap(src_bitmap, drawto_field, src_x + cx, src_y + cy,
	     width, height, FX + sx * TILEX_VAR + cx, FY + sy * TILEY_VAR + cy);
#else
  width  = crumbled_border_size;
  height = crumbled_border_size;
  cx = (dx > 0 ? TILEX - crumbled_border_size : 0);
  cy = (dy > 0 ? TILEY - crumbled_border_size : 0);

  BlitBitmap(src_bitmap, drawto_field, src_x + cx, src_y + cy,
	     width, height, FX + sx * TILEX + cx, FY + sy * TILEY + cy);
#endif
}

static void DrawLevelFieldCrumbledBorders(int x, int y, int graphic, int frame,
					  int dir)
{
  Bitmap *src_bitmap;
  int src_x, src_y;
  int width, height, bx, by, cx, cy;
  int sx = SCREENX(x), sy = SCREENY(y);
  int crumbled_border_size = graphic_info[graphic].border_size;
  int i;

  getGraphicSource(graphic, frame, &src_bitmap, &src_x, &src_y);

  /* draw simple, sloppy, non-corner-accurate crumbled border */

#if 1
  width  = (dir == 1 || dir == 2 ? crumbled_border_size : TILEX);
  height = (dir == 0 || dir == 3 ? crumbled_border_size : TILEY);
  cx = (dir == 2 ? TILEX - crumbled_border_size : 0);
  cy = (dir == 3 ? TILEY - crumbled_border_size : 0);
#else
  if (dir == 1 || dir == 2)		/* left or right crumbled border */
  {
    width = crumbled_border_size;
    height = TILEY;
    cx = (dir == 2 ? TILEX - crumbled_border_size : 0);
    cy = 0;
  }
  else					/* top or bottom crumbled border */
  {
    width = TILEX;
    height = crumbled_border_size;
    cx = 0;
    cy = (dir == 3 ? TILEY - crumbled_border_size : 0);
  }
#endif

#if NEW_TILESIZE
  BlitBitmap(src_bitmap, drawto_field,
	     src_x + cx * TILESIZE_VAR / TILESIZE,
	     src_y + cy * TILESIZE_VAR / TILESIZE,
	     width * TILESIZE_VAR / TILESIZE,
	     height * TILESIZE_VAR / TILESIZE,
	     FX + sx * TILEX_VAR + cx * TILESIZE_VAR / TILESIZE,
	     FY + sy * TILEY_VAR + cy * TILESIZE_VAR / TILESIZE);
#else
  BlitBitmap(src_bitmap, drawto_field, src_x + cx, src_y + cy,
	     width, height, FX + sx * TILEX + cx, FY + sy * TILEY + cy);
#endif

  /* (remaining middle border part must be at least as big as corner part) */
  if (!(graphic_info[graphic].style & STYLE_ACCURATE_BORDERS) ||
      crumbled_border_size >= TILESIZE / 3)
    return;

  /* correct corners of crumbled border, if needed */

#if 1
  for (i = -1; i <= 1; i+=2)
  {
    int xx = x + (dir == 0 || dir == 3 ? i : 0);
    int yy = y + (dir == 1 || dir == 2 ? i : 0);
    int element = (IN_LEV_FIELD(xx, yy) ? TILE_GFX_ELEMENT(xx, yy) :
		   BorderElement);

    /* check if neighbour field is of same crumble type */
    if (IS_CRUMBLED_TILE(xx, yy, element) &&
	graphic_info[graphic].class ==
	graphic_info[el_act2crm(element, ACTION_DEFAULT)].class)
    {
      /* no crumbled corner, but continued crumbled border */

      int c1 = (dir == 2 || dir == 3 ? TILESIZE - crumbled_border_size : 0);
      int c2 = (i == 1 ? TILESIZE - crumbled_border_size : 0);
      int b1 = (i == 1 ? crumbled_border_size :
		TILESIZE - 2 * crumbled_border_size);

      width  = crumbled_border_size;
      height = crumbled_border_size;

      if (dir == 1 || dir == 2)
      {
	cx = c1;
	cy = c2;
	bx = cx;
	by = b1;
      }
      else
      {
	cx = c2;
	cy = c1;
	bx = b1;
	by = cy;
      }

#if NEW_TILESIZE
      BlitBitmap(src_bitmap, drawto_field,
		 src_x + bx * TILESIZE_VAR / TILESIZE,
		 src_y + by * TILESIZE_VAR / TILESIZE,
		 width * TILESIZE_VAR / TILESIZE,
		 height * TILESIZE_VAR / TILESIZE,
		 FX + sx * TILEX_VAR + cx * TILESIZE_VAR / TILESIZE,
		 FY + sy * TILEY_VAR + cy * TILESIZE_VAR / TILESIZE);
#else
      BlitBitmap(src_bitmap, drawto_field, src_x + bx, src_y + by,
		 width, height, FX + sx * TILEX + cx, FY + sy * TILEY + cy);
#endif
    }
  }
#else
  if (dir == 1 || dir == 2)		/* left or right crumbled border */
  {
    for (i = -1; i <= 1; i+=2)
    {
      int xx = x;
      int yy = y + i;
      int element = (IN_LEV_FIELD(xx, yy) ? TILE_GFX_ELEMENT(xx, yy) :
		     BorderElement);

      /* check if neighbour field is of same crumble type */
      if (IS_CRUMBLED_TILE(xx, yy, element) &&
	  graphic_info[graphic].class ==
	  graphic_info[el_act2crm(element, ACTION_DEFAULT)].class)
      {
	/* no crumbled corner, but continued crumbled border */

	width  = crumbled_border_size;
	height = crumbled_border_size;
	cx = (dir == 2 ? TILEX - crumbled_border_size : 0);
	cy = (i == 1 ? TILEY - crumbled_border_size : 0);
	bx = cx;
	by = (i == 1 ? crumbled_border_size :
	      TILEY - 2 * crumbled_border_size);

	BlitBitmap(src_bitmap, drawto_field, src_x + bx, src_y + by,
		   width, height, FX + sx * TILEX + cx, FY + sy * TILEY + cy);
      }
    }
  }
  else				/* top or bottom crumbled border */
  {
    for (i = -1; i <= 1; i+=2)
    {
      int xx = x + i;
      int yy = y;
      int element = (IN_LEV_FIELD(xx, yy) ? TILE_GFX_ELEMENT(xx, yy) :
		     BorderElement);

      /* check if neighbour field is of same crumble type */
      if (IS_CRUMBLED_TILE(xx, yy, element) &&
	  graphic_info[graphic].class ==
	  graphic_info[el_act2crm(element, ACTION_DEFAULT)].class)
      {
	/* no crumbled corner, but continued crumbled border */

	width  = crumbled_border_size;
	height = crumbled_border_size;
	cx = (i == 1 ? TILEX - crumbled_border_size : 0);
	cy = (dir == 3 ? TILEY - crumbled_border_size : 0);
	bx = (i == 1 ? crumbled_border_size :
	      TILEX - 2 * crumbled_border_size);
	by = cy;

	BlitBitmap(src_bitmap, drawto_field, src_x + bx, src_y + by,
		   width, height, FX + sx * TILEX + cx, FY + sy * TILEY + cy);
      }
    }
  }
#endif
}

static void DrawLevelFieldCrumbledExt(int x, int y, int graphic, int frame)
{
  int sx = SCREENX(x), sy = SCREENY(y);
  int element;
  int i;
  static int xy[4][2] =
  {
    { 0, -1 },
    { -1, 0 },
    { +1, 0 },
    { 0, +1 }
  };

  if (!IN_LEV_FIELD(x, y))
    return;

  element = TILE_GFX_ELEMENT(x, y);

  /* crumble field itself */
  if (IS_CRUMBLED_TILE(x, y, element))
  {
    if (!IN_SCR_FIELD(sx, sy))
      return;

    for (i = 0; i < 4; i++)
    {
      int xx = x + xy[i][0];
      int yy = y + xy[i][1];

      element = (IN_LEV_FIELD(xx, yy) ? TILE_GFX_ELEMENT(xx, yy) :
		 BorderElement);

      /* check if neighbour field is of same crumble type */
#if 1
      if (IS_CRUMBLED_TILE(xx, yy, element) &&
	  graphic_info[graphic].class ==
	  graphic_info[el_act2crm(element, ACTION_DEFAULT)].class)
	continue;
#else
      if (IS_CRUMBLED_TILE(xx, yy, element))
	continue;
#endif

      DrawLevelFieldCrumbledBorders(x, y, graphic, frame, i);
    }

    if ((graphic_info[graphic].style & STYLE_INNER_CORNERS) &&
	graphic_info[graphic].anim_frames == 2)
    {
      for (i = 0; i < 4; i++)
      {
	int dx = (i & 1 ? +1 : -1);
	int dy = (i & 2 ? +1 : -1);

	DrawLevelFieldCrumbledInnerCorners(x, y, dx, dy, graphic);
      }
    }

    MarkTileDirty(sx, sy);
  }
  else		/* center field not crumbled -- crumble neighbour fields */
  {
    for (i = 0; i < 4; i++)
    {
      int xx = x + xy[i][0];
      int yy = y + xy[i][1];
      int sxx = sx + xy[i][0];
      int syy = sy + xy[i][1];

      if (!IN_LEV_FIELD(xx, yy) ||
	  !IN_SCR_FIELD(sxx, syy))
	continue;

      if (Feld[xx][yy] == EL_ELEMENT_SNAPPING)
	continue;

      element = TILE_GFX_ELEMENT(xx, yy);

      if (!IS_CRUMBLED_TILE(xx, yy, element))
	continue;

      graphic = el_act2crm(element, ACTION_DEFAULT);

      DrawLevelFieldCrumbledBorders(xx, yy, graphic, 0, 3 - i);

      MarkTileDirty(sxx, syy);
    }
  }
}

void DrawLevelFieldCrumbled(int x, int y)
{
  int graphic;

  if (!IN_LEV_FIELD(x, y))
    return;

#if 1
  /* !!! CHECK THIS !!! */

  /*
  if (Feld[x][y] == EL_ELEMENT_SNAPPING &&
      GFX_CRUMBLED(GfxElement[x][y]))
  */

  if (Feld[x][y] == EL_ELEMENT_SNAPPING &&
      GfxElement[x][y] != EL_UNDEFINED &&
      GFX_CRUMBLED(GfxElement[x][y]))
  {
    DrawLevelFieldCrumbledDigging(x, y, GfxDir[x][y], GfxFrame[x][y]);

    return;
  }
#endif

#if 1
  graphic = el_act2crm(TILE_GFX_ELEMENT(x, y), ACTION_DEFAULT);
#else
  graphic = el_act2crm(Feld[x][y], ACTION_DEFAULT);
#endif

  DrawLevelFieldCrumbledExt(x, y, graphic, 0);
}

void DrawLevelFieldCrumbledDigging(int x, int y, int direction,
				   int step_frame)
{
  int graphic1 = el_act_dir2img(GfxElement[x][y], ACTION_DIGGING, direction);
  int graphic2 = el_act_dir2crm(GfxElement[x][y], ACTION_DIGGING, direction);
  int frame1 = getGraphicAnimationFrame(graphic1, step_frame);
  int frame2 = getGraphicAnimationFrame(graphic2, step_frame);
  int sx = SCREENX(x), sy = SCREENY(y);

  DrawGraphic(sx, sy, graphic1, frame1);
  DrawLevelFieldCrumbledExt(x, y, graphic2, frame2);
}

void DrawLevelFieldCrumbledNeighbours(int x, int y)
{
  int sx = SCREENX(x), sy = SCREENY(y);
  static int xy[4][2] =
  {
    { 0, -1 },
    { -1, 0 },
    { +1, 0 },
    { 0, +1 }
  };
  int i;

  for (i = 0; i < 4; i++)
  {
    int xx = x + xy[i][0];
    int yy = y + xy[i][1];
    int sxx = sx + xy[i][0];
    int syy = sy + xy[i][1];

    if (!IN_LEV_FIELD(xx, yy) ||
	!IN_SCR_FIELD(sxx, syy) ||
	!GFX_CRUMBLED(Feld[xx][yy]) ||
	IS_MOVING(xx, yy))
      continue;

    DrawLevelField(xx, yy);
  }
}

static int getBorderElement(int x, int y)
{
  int border[7][2] =
  {
    { EL_STEELWALL_TOPLEFT,		EL_INVISIBLE_STEELWALL_TOPLEFT     },
    { EL_STEELWALL_TOPRIGHT,		EL_INVISIBLE_STEELWALL_TOPRIGHT    },
    { EL_STEELWALL_BOTTOMLEFT,		EL_INVISIBLE_STEELWALL_BOTTOMLEFT  },
    { EL_STEELWALL_BOTTOMRIGHT,		EL_INVISIBLE_STEELWALL_BOTTOMRIGHT },
    { EL_STEELWALL_VERTICAL,		EL_INVISIBLE_STEELWALL_VERTICAL    },
    { EL_STEELWALL_HORIZONTAL,		EL_INVISIBLE_STEELWALL_HORIZONTAL  },
    { EL_STEELWALL,			EL_INVISIBLE_STEELWALL		   }
  };
  int steel_type = (BorderElement == EL_STEELWALL ? 0 : 1);
  int steel_position = (x == -1		&& y == -1		? 0 :
			x == lev_fieldx	&& y == -1		? 1 :
			x == -1		&& y == lev_fieldy	? 2 :
			x == lev_fieldx	&& y == lev_fieldy	? 3 :
			x == -1		|| x == lev_fieldx	? 4 :
			y == -1		|| y == lev_fieldy	? 5 : 6);

  return border[steel_position][steel_type];
}

void DrawScreenElement(int x, int y, int element)
{
  DrawScreenElementExt(x, y, 0, 0, element, NO_CUTTING, NO_MASKING);
  DrawLevelFieldCrumbled(LEVELX(x), LEVELY(y));
}

void DrawLevelElement(int x, int y, int element)
{
  if (IN_LEV_FIELD(x, y) && IN_SCR_FIELD(SCREENX(x), SCREENY(y)))
    DrawScreenElement(SCREENX(x), SCREENY(y), element);
}

void DrawScreenField(int x, int y)
{
  int lx = LEVELX(x), ly = LEVELY(y);
  int element, content;

  if (!IN_LEV_FIELD(lx, ly))
  {
    if (lx < -1 || lx > lev_fieldx || ly < -1 || ly > lev_fieldy)
      element = EL_EMPTY;
    else
      element = getBorderElement(lx, ly);

    DrawScreenElement(x, y, element);

    return;
  }

  element = Feld[lx][ly];
  content = Store[lx][ly];

  if (IS_MOVING(lx, ly))
  {
    int horiz_move = (MovDir[lx][ly] == MV_LEFT || MovDir[lx][ly] == MV_RIGHT);
    boolean cut_mode = NO_CUTTING;

    if (element == EL_QUICKSAND_EMPTYING ||
	element == EL_QUICKSAND_FAST_EMPTYING ||
	element == EL_MAGIC_WALL_EMPTYING ||
	element == EL_BD_MAGIC_WALL_EMPTYING ||
	element == EL_DC_MAGIC_WALL_EMPTYING ||
	element == EL_AMOEBA_DROPPING)
      cut_mode = CUT_ABOVE;
    else if (element == EL_QUICKSAND_FILLING ||
	     element == EL_QUICKSAND_FAST_FILLING ||
	     element == EL_MAGIC_WALL_FILLING ||
	     element == EL_BD_MAGIC_WALL_FILLING ||
	     element == EL_DC_MAGIC_WALL_FILLING)
      cut_mode = CUT_BELOW;

#if 0
    if (lx == 9 && ly == 1)
      printf("::: %s [%d] [%d, %d] [%d]\n",
	     EL_NAME(TILE_GFX_ELEMENT(lx, ly)),
	     el_act2crm(TILE_GFX_ELEMENT(lx, ly), ACTION_DEFAULT),
	     element_info[EL_QUICKSAND_EMPTYING].graphic[ACTION_DEFAULT],
	     element_info[EL_QUICKSAND_EMPTYING].crumbled[ACTION_DEFAULT],
	     GFX_CRUMBLED(TILE_GFX_ELEMENT(lx, ly)));
#endif

    if (cut_mode == CUT_ABOVE)
#if 1
      DrawScreenElement(x, y, element);
#else
      DrawScreenElementShifted(x, y, 0, 0, element, NO_CUTTING);
#endif
    else
      DrawScreenElement(x, y, EL_EMPTY);

    if (horiz_move)
      DrawScreenElementShifted(x, y, MovPos[lx][ly], 0, element, NO_CUTTING);
    else if (cut_mode == NO_CUTTING)
      DrawScreenElementShifted(x, y, 0, MovPos[lx][ly], element, cut_mode);
    else
    {
      DrawScreenElementShifted(x, y, 0, MovPos[lx][ly], content, cut_mode);

#if 1
      if (cut_mode == CUT_BELOW &&
	  IN_LEV_FIELD(lx, ly + 1) && IN_SCR_FIELD(x, y + 1))
	DrawLevelElement(lx, ly + 1, element);
#endif
    }

    if (content == EL_ACID)
    {
      int dir = MovDir[lx][ly];
      int newlx = lx + (dir == MV_LEFT ? -1 : dir == MV_RIGHT ? +1 : 0);
      int newly = ly + (dir == MV_UP   ? -1 : dir == MV_DOWN  ? +1 : 0);

      DrawLevelElementThruMask(newlx, newly, EL_ACID);
    }
  }
  else if (IS_BLOCKED(lx, ly))
  {
    int oldx, oldy;
    int sx, sy;
    int horiz_move;
    boolean cut_mode = NO_CUTTING;
    int element_old, content_old;

    Blocked2Moving(lx, ly, &oldx, &oldy);
    sx = SCREENX(oldx);
    sy = SCREENY(oldy);
    horiz_move = (MovDir[oldx][oldy] == MV_LEFT ||
		  MovDir[oldx][oldy] == MV_RIGHT);

    element_old = Feld[oldx][oldy];
    content_old = Store[oldx][oldy];

    if (element_old == EL_QUICKSAND_EMPTYING ||
	element_old == EL_QUICKSAND_FAST_EMPTYING ||
	element_old == EL_MAGIC_WALL_EMPTYING ||
	element_old == EL_BD_MAGIC_WALL_EMPTYING ||
	element_old == EL_DC_MAGIC_WALL_EMPTYING ||
	element_old == EL_AMOEBA_DROPPING)
      cut_mode = CUT_ABOVE;

    DrawScreenElement(x, y, EL_EMPTY);

    if (horiz_move)
      DrawScreenElementShifted(sx, sy, MovPos[oldx][oldy], 0, element_old,
			       NO_CUTTING);
    else if (cut_mode == NO_CUTTING)
      DrawScreenElementShifted(sx, sy, 0, MovPos[oldx][oldy], element_old,
			       cut_mode);
    else
      DrawScreenElementShifted(sx, sy, 0, MovPos[oldx][oldy], content_old,
			       cut_mode);
  }
  else if (IS_DRAWABLE(element))
    DrawScreenElement(x, y, element);
  else
    DrawScreenElement(x, y, EL_EMPTY);
}

void DrawLevelField(int x, int y)
{
  if (IN_SCR_FIELD(SCREENX(x), SCREENY(y)))
    DrawScreenField(SCREENX(x), SCREENY(y));
  else if (IS_MOVING(x, y))
  {
    int newx,newy;

    Moving2Blocked(x, y, &newx, &newy);
    if (IN_SCR_FIELD(SCREENX(newx), SCREENY(newy)))
      DrawScreenField(SCREENX(newx), SCREENY(newy));
  }
  else if (IS_BLOCKED(x, y))
  {
    int oldx, oldy;

    Blocked2Moving(x, y, &oldx, &oldy);
    if (IN_SCR_FIELD(SCREENX(oldx), SCREENY(oldy)))
      DrawScreenField(SCREENX(oldx), SCREENY(oldy));
  }
}

void DrawMiniElement(int x, int y, int element)
{
  int graphic;

  graphic = el2edimg(element);
  DrawMiniGraphic(x, y, graphic);
}

void DrawMiniElementOrWall(int sx, int sy, int scroll_x, int scroll_y)
{
  int x = sx + scroll_x, y = sy + scroll_y;

  if (x < -1 || x > lev_fieldx || y < -1 || y > lev_fieldy)
    DrawMiniElement(sx, sy, EL_EMPTY);
  else if (x > -1 && x < lev_fieldx && y > -1 && y < lev_fieldy)
    DrawMiniElement(sx, sy, Feld[x][y]);
  else
    DrawMiniGraphic(sx, sy, el2edimg(getBorderElement(x, y)));
}

void DrawEnvelopeBackground(int envelope_nr, int startx, int starty,
			    int x, int y, int xsize, int ysize, int font_nr)
{
  int font_width  = getFontWidth(font_nr);
  int font_height = getFontHeight(font_nr);
  int graphic = IMG_BACKGROUND_ENVELOPE_1 + envelope_nr;
  Bitmap *src_bitmap;
  int src_x, src_y;
  int dst_x = SX + startx + x * font_width;
  int dst_y = SY + starty + y * font_height;
  int width  = graphic_info[graphic].width;
  int height = graphic_info[graphic].height;
  int inner_width  = MAX(width  - 2 * font_width,  font_width);
  int inner_height = MAX(height - 2 * font_height, font_height);
  int inner_sx = (width >= 3 * font_width ? font_width : 0);
  int inner_sy = (height >= 3 * font_height ? font_height : 0);
  boolean draw_masked = graphic_info[graphic].draw_masked;

  getFixedGraphicSource(graphic, 0, &src_bitmap, &src_x, &src_y);

  if (src_bitmap == NULL || width < font_width || height < font_height)
  {
    ClearRectangle(drawto, dst_x, dst_y, font_width, font_height);
    return;
  }

  src_x += (x == 0 ? 0 : x == xsize - 1 ? width  - font_width  :
	    inner_sx + (x - 1) * font_width  % inner_width);
  src_y += (y == 0 ? 0 : y == ysize - 1 ? height - font_height :
	    inner_sy + (y - 1) * font_height % inner_height);

  if (draw_masked)
  {
    SetClipOrigin(src_bitmap, src_bitmap->stored_clip_gc,
		  dst_x - src_x, dst_y - src_y);
    BlitBitmapMasked(src_bitmap, drawto, src_x, src_y, font_width, font_height,
		     dst_x, dst_y);
  }
  else
    BlitBitmap(src_bitmap, drawto, src_x, src_y, font_width, font_height,
	       dst_x, dst_y);
}

void AnimateEnvelope(int envelope_nr, int anim_mode, int action)
{
  int graphic = IMG_BACKGROUND_ENVELOPE_1 + envelope_nr;
  Bitmap *src_bitmap = graphic_info[graphic].bitmap;
  int mask_mode = (src_bitmap != NULL ? BLIT_MASKED : BLIT_ON_BACKGROUND);
  boolean ffwd_delay = (tape.playing && tape.fast_forward);
  boolean no_delay = (tape.warp_forward);
  unsigned int anim_delay = 0;
  int frame_delay_value = (ffwd_delay ? FfwdFrameDelay : GameFrameDelay);
  int anim_delay_value = (no_delay ? 0 : frame_delay_value);
  int font_nr = FONT_ENVELOPE_1 + envelope_nr;
  int font_width = getFontWidth(font_nr);
  int font_height = getFontHeight(font_nr);
  int max_xsize = level.envelope[envelope_nr].xsize;
  int max_ysize = level.envelope[envelope_nr].ysize;
  int xstart = (anim_mode & ANIM_VERTICAL ? max_xsize : 0);
  int ystart = (anim_mode & ANIM_HORIZONTAL ? max_ysize : 0);
  int xend = max_xsize;
  int yend = (anim_mode != ANIM_DEFAULT ? max_ysize : 0);
  int xstep = (xstart < xend ? 1 : 0);
  int ystep = (ystart < yend || xstep == 0 ? 1 : 0);
  int x, y;

  for (x = xstart, y = ystart; x <= xend && y <= yend; x += xstep, y += ystep)
  {
    int xsize = (action == ACTION_CLOSING ? xend - (x - xstart) : x) + 2;
    int ysize = (action == ACTION_CLOSING ? yend - (y - ystart) : y) + 2;
    int sx = (SXSIZE - xsize * font_width)  / 2;
    int sy = (SYSIZE - ysize * font_height) / 2;
    int xx, yy;

    SetDrawtoField(DRAW_BUFFERED);

    BlitBitmap(fieldbuffer, backbuffer, FX, FY, SXSIZE, SYSIZE, SX, SY);

    SetDrawtoField(DRAW_BACKBUFFER);

    for (yy = 0; yy < ysize; yy++) for (xx = 0; xx < xsize; xx++)
      DrawEnvelopeBackground(envelope_nr, sx,sy, xx,yy, xsize, ysize, font_nr);

#if 1
    DrawTextBuffer(SX + sx + font_width, SY + sy + font_height,
		   level.envelope[envelope_nr].text, font_nr, max_xsize,
		   xsize - 2, ysize - 2, 0, mask_mode,
		   level.envelope[envelope_nr].autowrap,
		   level.envelope[envelope_nr].centered, FALSE);
#else
    DrawTextToTextArea(SX + sx + font_width, SY + sy + font_height,
		       level.envelope[envelope_nr].text, font_nr, max_xsize,
		       xsize - 2, ysize - 2, mask_mode);
#endif

    redraw_mask |= REDRAW_FIELD | REDRAW_FROM_BACKBUFFER;
    BackToFront();

    WaitUntilDelayReached(&anim_delay, anim_delay_value / 2);
  }
}

void AnimateEnvelopeDoor(char *text, int anim_mode, int action)
{
#if 1
  int envelope_nr = 0;
#endif
  int graphic = IMG_BACKGROUND_ENVELOPE_1 + envelope_nr;
  Bitmap *src_bitmap = graphic_info[graphic].bitmap;
  int mask_mode = (src_bitmap != NULL ? BLIT_MASKED : BLIT_ON_BACKGROUND);
  boolean ffwd_delay = (tape.playing && tape.fast_forward);
  boolean no_delay = (tape.warp_forward);
  unsigned int anim_delay = 0;
  int frame_delay_value = (ffwd_delay ? FfwdFrameDelay : GameFrameDelay);
  int anim_delay_value = (no_delay ? 0 : frame_delay_value);
#if 1
  int max_word_len = maxWordLengthInString(text);
  int font_nr = (max_word_len > 7 ? FONT_TEXT_1 : FONT_TEXT_2);
#else
  int font_nr = FONT_ENVELOPE_1 + envelope_nr;
#endif
  int font_width = getFontWidth(font_nr);
  int font_height = getFontHeight(font_nr);
#if 1

#if 1
  int max_xsize = DXSIZE / font_width;
  int max_ysize = DYSIZE / font_height;
#else
  int max_xsize = 7;	/* tools.c: MAX_REQUEST_LINE_FONT1_LEN == 7 */
  int max_ysize = 13;	/* tools.c: MAX_REQUEST_LINES == 13 */
#endif

#else
  int max_xsize = level.envelope[envelope_nr].xsize;
  int max_ysize = level.envelope[envelope_nr].ysize;
#endif
  int xstart = (anim_mode & ANIM_VERTICAL ? max_xsize : 0);
  int ystart = (anim_mode & ANIM_HORIZONTAL ? max_ysize : 0);
  int xend = max_xsize;
  int yend = (anim_mode != ANIM_DEFAULT ? max_ysize : 0);
  int xstep = (xstart < xend ? 1 : 0);
  int ystep = (ystart < yend || xstep == 0 ? 1 : 0);
  int x, y;

#if 1
  char *text_ptr;
  char *text_copy = getStringCopy(text);
#else
#if 1
  font_nr = FONT_TEXT_2;

  if (maxWordLengthInString(text) > 7)	/* MAX_REQUEST_LINE_FONT1_LEN == 7 */
  {
    max_xsize = 10;	/* tools.c: MAX_REQUEST_LINE_FONT2_LEN == 10 */
    font_nr = FONT_TEXT_1;
  }
#else
  int max_word_len = 0;
  char *text_ptr;
  char *text_copy = getStringCopy(text);

  font_nr = FONT_TEXT_2;

  for (text_ptr = text; *text_ptr; text_ptr++)
  {
    max_word_len = (*text_ptr != ' ' ? max_word_len + 1 : 0);

    if (max_word_len > 7)	/* tools.c: MAX_REQUEST_LINE_FONT1_LEN == 7 */
    {
      max_xsize = 10;	/* tools.c: MAX_REQUEST_LINE_FONT2_LEN == 10 */
      font_nr = FONT_TEXT_1;

      break;
    }
  }
#endif
#endif

#if 1
  for (text_ptr = text_copy; *text_ptr; text_ptr++)
    if (*text_ptr == ' ')
      *text_ptr = '\n';
#endif

#if 1
  dDX = SX + (SXSIZE - DXSIZE) / 2 - DX;
  dDY = SY + (SYSIZE - DYSIZE) / 2 - DY;
#else
  dDX = SX + SXSIZE / 2 - max_xsize * font_width  / 2 - DX;
  dDY = SY + SYSIZE / 2 - max_ysize * font_height / 2 - DY;
#endif

  for (x = xstart, y = ystart; x <= xend && y <= yend; x += xstep, y += ystep)
  {
    int xsize = (action == ACTION_CLOSING ? xend - (x - xstart) : x) + 2;
    int ysize = (action == ACTION_CLOSING ? yend - (y - ystart) : y) + 2;
    int sx = (SXSIZE - xsize * font_width)  / 2;
    int sy = (SYSIZE - ysize * font_height) / 2;
    int xx, yy;

#if 1
    BlitBitmap(bitmap_db_store, backbuffer, 0, 0, WIN_XSIZE, WIN_YSIZE, 0, 0);
#else
    SetDrawtoField(DRAW_BUFFERED);

    BlitBitmap(fieldbuffer, backbuffer, FX, FY, SXSIZE, SYSIZE, SX, SY);

    SetDrawtoField(DRAW_BACKBUFFER);
#endif

    for (yy = 0; yy < ysize; yy++) for (xx = 0; xx < xsize; xx++)
      DrawEnvelopeBackground(envelope_nr, sx,sy, xx,yy, xsize, ysize, font_nr);

#if 1

#if 1
    DrawTextBuffer(SX + sx + font_width, SY + sy + font_height + 8,
		   text_copy, font_nr, max_xsize,
		   xsize - 2, ysize - 2, 2, mask_mode,
		   FALSE, TRUE, FALSE);
#else
    DrawTextBuffer(SX + sx + font_width, SY + sy + font_height,
		   level.envelope[envelope_nr].text, font_nr, max_xsize,
		   xsize - 2, ysize - 2, 0, mask_mode,
		   level.envelope[envelope_nr].autowrap,
		   level.envelope[envelope_nr].centered, FALSE);
#endif

#else
    DrawTextToTextArea(SX + sx + font_width, SY + sy + font_height,
		       level.envelope[envelope_nr].text, font_nr, max_xsize,
		       xsize - 2, ysize - 2, mask_mode);
#endif

    /* copy request gadgets to door backbuffer */
#if 1
    if ((ysize - 2) > 13)
      BlitBitmap(bitmap_db_door, drawto,
		 DOOR_GFX_PAGEX1 + (DXSIZE - (xsize - 2) * font_width) / 2,
		 DOOR_GFX_PAGEY1 + 13 * font_height,
		 (xsize - 2) * font_width,
		 (ysize - 2 - 13) * font_height,
		 SX + sx + font_width,
		 SY + sy + font_height * (1 + 13));
#else
    if ((ysize - 2) > 13)
      BlitBitmap(bitmap_db_door, drawto,
		 DOOR_GFX_PAGEX1 + (DXSIZE - (xsize - 2) * font_width) / 2,
		 DOOR_GFX_PAGEY1 + 13 * font_height,
		 (xsize - 2) * font_width,
		 (ysize - 2 - 13) * font_height,
		 SX + sx + font_width,
		 SY + sy + font_height * (1 + 13));
#endif

#if 1
    redraw_mask = REDRAW_FIELD | REDRAW_FROM_BACKBUFFER;
    // redraw_mask |= REDRAW_ALL | REDRAW_FROM_BACKBUFFER;
#else
    redraw_mask |= REDRAW_FIELD | REDRAW_FROM_BACKBUFFER;
#endif

#if 1
    DoAnimation();
    BackToFront();
#else
    BackToFront();
#endif

    WaitUntilDelayReached(&anim_delay, anim_delay_value / 2);
  }

#if 1
  free(text_copy);
#endif
}

void ShowEnvelope(int envelope_nr)
{
  int element = EL_ENVELOPE_1 + envelope_nr;
  int graphic = IMG_BACKGROUND_ENVELOPE_1 + envelope_nr;
  int sound_opening = element_info[element].sound[ACTION_OPENING];
  int sound_closing = element_info[element].sound[ACTION_CLOSING];
  boolean ffwd_delay = (tape.playing && tape.fast_forward);
  boolean no_delay = (tape.warp_forward);
  int normal_delay_value = ONE_SECOND_DELAY / (ffwd_delay ? 2 : 1);
  int wait_delay_value = (no_delay ? 0 : normal_delay_value);
  int anim_mode = graphic_info[graphic].anim_mode;
  int main_anim_mode = (anim_mode == ANIM_NONE ? ANIM_VERTICAL|ANIM_HORIZONTAL:
			anim_mode == ANIM_DEFAULT ? ANIM_VERTICAL : anim_mode);

  game.envelope_active = TRUE;	/* needed for RedrawPlayfield() events */

  PlayMenuSoundStereo(sound_opening, SOUND_MIDDLE);

  if (anim_mode == ANIM_DEFAULT)
    AnimateEnvelope(envelope_nr, ANIM_DEFAULT, ACTION_OPENING);

  AnimateEnvelope(envelope_nr, main_anim_mode, ACTION_OPENING);

  if (tape.playing)
    Delay(wait_delay_value);
  else
    WaitForEventToContinue();

  PlayMenuSoundStereo(sound_closing, SOUND_MIDDLE);

  if (anim_mode != ANIM_NONE)
    AnimateEnvelope(envelope_nr, main_anim_mode, ACTION_CLOSING);

  if (anim_mode == ANIM_DEFAULT)
    AnimateEnvelope(envelope_nr, ANIM_DEFAULT, ACTION_CLOSING);

  game.envelope_active = FALSE;

  SetDrawtoField(DRAW_BUFFERED);

  redraw_mask |= REDRAW_FIELD;
  BackToFront();
}

void ShowEnvelopeDoor(char *text, int action)
{
#if 1
  int last_game_status = game_status;	/* save current game status */
  // int last_draw_background_mask = gfx.draw_background_mask;
  int envelope_nr = 0;
#endif
  int element = EL_ENVELOPE_1 + envelope_nr;
  int graphic = IMG_BACKGROUND_ENVELOPE_1 + envelope_nr;
  int sound_opening = element_info[element].sound[ACTION_OPENING];
  int sound_closing = element_info[element].sound[ACTION_CLOSING];
#if 0
  boolean ffwd_delay = (tape.playing && tape.fast_forward);
  boolean no_delay = (tape.warp_forward);
  int normal_delay_value = ONE_SECOND_DELAY / (ffwd_delay ? 2 : 1);
  int wait_delay_value = (no_delay ? 0 : normal_delay_value);
#endif
  int anim_mode = graphic_info[graphic].anim_mode;
  int main_anim_mode = (anim_mode == ANIM_NONE ? ANIM_VERTICAL|ANIM_HORIZONTAL:
			anim_mode == ANIM_DEFAULT ? ANIM_VERTICAL : anim_mode);

#if 1
  if (game_status == GAME_MODE_PLAYING)
  {
    if (level.game_engine_type == GAME_ENGINE_TYPE_EM)
      BlitScreenToBitmap_EM(backbuffer);
    else if (level.game_engine_type == GAME_ENGINE_TYPE_SP)
      BlitScreenToBitmap_SP(backbuffer);
    else
    {
      BlitBitmap(fieldbuffer, backbuffer, FX, FY, SXSIZE, SYSIZE, SX, SY);
    }
  }

  SetDrawtoField(DRAW_BACKBUFFER);

  // SetDrawBackgroundMask(REDRAW_NONE);

  if (action == ACTION_OPENING)
  {
    BlitBitmap(backbuffer, bitmap_db_store, 0, 0, WIN_XSIZE, WIN_YSIZE, 0, 0);

    if (game_status != GAME_MODE_MAIN)
      InitAnimation();
  }

  /* force DOOR font inside door area */
  game_status = GAME_MODE_PSEUDO_DOOR;
#endif

  game.envelope_active = TRUE;	/* needed for RedrawPlayfield() events */

  if (action == ACTION_OPENING)
  {
    PlayMenuSoundStereo(sound_opening, SOUND_MIDDLE);

    if (anim_mode == ANIM_DEFAULT)
      AnimateEnvelopeDoor(text, ANIM_DEFAULT, ACTION_OPENING);

    AnimateEnvelopeDoor(text, main_anim_mode, ACTION_OPENING);

#if 0
    if (tape.playing)
      Delay(wait_delay_value);
    else
      WaitForEventToContinue();
#endif
  }
  else
  {
    PlayMenuSoundStereo(sound_closing, SOUND_MIDDLE);

    if (anim_mode != ANIM_NONE)
      AnimateEnvelopeDoor(text, main_anim_mode, ACTION_CLOSING);

    if (anim_mode == ANIM_DEFAULT)
      AnimateEnvelopeDoor(text, ANIM_DEFAULT, ACTION_CLOSING);
  }

  game.envelope_active = FALSE;

#if 1
  // game_status = last_game_status;	/* restore current game status */

  if (action == ACTION_CLOSING)
  {
    if (game_status != GAME_MODE_MAIN)
      StopAnimation();

    BlitBitmap(bitmap_db_store, backbuffer, 0, 0, WIN_XSIZE, WIN_YSIZE, 0, 0);
  }
#else
  SetDrawtoField(DRAW_BUFFERED);
#endif

  // SetDrawBackgroundMask(last_draw_background_mask);

#if 1
  redraw_mask = REDRAW_FIELD;
  // redraw_mask |= REDRAW_ALL;
#else
  redraw_mask |= REDRAW_FIELD;
#endif

#if 1
  if (game_status == GAME_MODE_MAIN)
    DoAnimation();

  BackToFront();

  /* (important: after "BackToFront()", but before "SetDrawtoField()") */
  game_status = last_game_status;	/* restore current game status */

  if (game_status == GAME_MODE_PLAYING &&
      level.game_engine_type == GAME_ENGINE_TYPE_RND)
    SetDrawtoField(DRAW_BUFFERED);
#else
  BackToFront();
#endif
}

void DrawPreviewElement(int dst_x, int dst_y, int element, int tilesize)
{
  Bitmap *src_bitmap;
  int src_x, src_y;
  int graphic = el2preimg(element);

  getSizedGraphicSource(graphic, 0, tilesize, &src_bitmap, &src_x, &src_y);
  BlitBitmap(src_bitmap, drawto, src_x, src_y, tilesize, tilesize, dst_x,dst_y);
}

void DrawLevel()
{
  int x,y;

#if 1
  SetMainBackgroundImage(IMG_BACKGROUND_PLAYING);
  SetDrawBackgroundMask(REDRAW_FIELD);
#else
  SetDrawBackgroundMask(REDRAW_NONE);
#endif

  ClearField();

  for (x = BX1; x <= BX2; x++)
    for (y = BY1; y <= BY2; y++)
      DrawScreenField(x, y);

  redraw_mask |= REDRAW_FIELD;
}

void DrawMiniLevel(int size_x, int size_y, int scroll_x, int scroll_y)
{
  int x,y;

  for (x = 0; x < size_x; x++)
    for (y = 0; y < size_y; y++)
      DrawMiniElementOrWall(x, y, scroll_x, scroll_y);

  redraw_mask |= REDRAW_FIELD;
}

static void DrawPreviewLevelExt(int from_x, int from_y)
{
  boolean show_level_border = (BorderElement != EL_EMPTY);
  int level_xsize = lev_fieldx + (show_level_border ? 2 : 0);
  int level_ysize = lev_fieldy + (show_level_border ? 2 : 0);
  int tile_size = preview.tile_size;
  int preview_width  = preview.xsize * tile_size;
  int preview_height = preview.ysize * tile_size;
  int real_preview_xsize = MIN(level_xsize, preview.xsize);
  int real_preview_ysize = MIN(level_ysize, preview.ysize);
  int dst_x = SX + ALIGNED_XPOS(preview.x, preview_width, preview.align);
  int dst_y = SY + ALIGNED_YPOS(preview.y, preview_height, preview.valign);
  int x, y;

  DrawBackground(dst_x, dst_y, preview_width, preview_height);

  dst_x += (preview_width  - real_preview_xsize * tile_size) / 2;
  dst_y += (preview_height - real_preview_ysize * tile_size) / 2;

  for (x = 0; x < real_preview_xsize; x++)
  {
    for (y = 0; y < real_preview_ysize; y++)
    {
      int lx = from_x + x + (show_level_border ? -1 : 0);
      int ly = from_y + y + (show_level_border ? -1 : 0);
      int element = (IN_LEV_FIELD(lx, ly) ? level.field[lx][ly] :
		     getBorderElement(lx, ly));

      DrawPreviewElement(dst_x + x * tile_size, dst_y + y * tile_size,
			 element, tile_size);
    }
  }

  redraw_mask |= REDRAW_MICROLEVEL;
}

#define MICROLABEL_EMPTY		0
#define MICROLABEL_LEVEL_NAME		1
#define MICROLABEL_LEVEL_AUTHOR_HEAD	2
#define MICROLABEL_LEVEL_AUTHOR		3
#define MICROLABEL_IMPORTED_FROM_HEAD	4
#define MICROLABEL_IMPORTED_FROM	5
#define MICROLABEL_IMPORTED_BY_HEAD	6
#define MICROLABEL_IMPORTED_BY		7

static int getMaxTextLength(struct TextPosInfo *pos, int font_nr)
{
  int max_text_width = SXSIZE;
  int font_width = getFontWidth(font_nr);

  if (pos->align == ALIGN_CENTER)
    max_text_width = (pos->x < SXSIZE / 2 ? pos->x * 2 : (SXSIZE - pos->x) * 2);
  else if (pos->align == ALIGN_RIGHT)
    max_text_width = pos->x;
  else
    max_text_width = SXSIZE - pos->x;

  return max_text_width / font_width;
}

static void DrawPreviewLevelLabelExt(int mode)
{
  struct TextPosInfo *pos = &menu.main.text.level_info_2;
  char label_text[MAX_OUTPUT_LINESIZE + 1];
  int max_len_label_text;
#if 1
  int font_nr = pos->font;
  int i;

  if (mode == MICROLABEL_LEVEL_AUTHOR_HEAD ||
      mode == MICROLABEL_IMPORTED_FROM_HEAD ||
      mode == MICROLABEL_IMPORTED_BY_HEAD)
    font_nr = pos->font_alt;
#else
  int font_nr = FONT_TEXT_2;
  int i;

  if (mode == MICROLABEL_LEVEL_AUTHOR_HEAD ||
      mode == MICROLABEL_IMPORTED_FROM_HEAD ||
      mode == MICROLABEL_IMPORTED_BY_HEAD)
    font_nr = FONT_TEXT_3;
#endif

#if 1
  max_len_label_text = getMaxTextLength(pos, font_nr);
#else
  max_len_label_text = SXSIZE / getFontWidth(font_nr);
#endif

#if 1
  if (pos->size != -1)
    max_len_label_text = pos->size;
#endif

  for (i = 0; i < max_len_label_text; i++)
    label_text[i] = ' ';
  label_text[max_len_label_text] = '\0';

  if (strlen(label_text) > 0)
  {
#if 1
    DrawTextSAligned(pos->x, pos->y, label_text, font_nr, pos->align);
#else
    int lxpos = SX + (SXSIZE - getTextWidth(label_text, font_nr)) / 2;
    int lypos = MICROLABEL2_YPOS;

    DrawText(lxpos, lypos, label_text, font_nr);
#endif
  }

  strncpy(label_text,
	  (mode == MICROLABEL_LEVEL_NAME ? level.name :
	   mode == MICROLABEL_LEVEL_AUTHOR_HEAD ? "created by" :
	   mode == MICROLABEL_LEVEL_AUTHOR ? level.author :
	   mode == MICROLABEL_IMPORTED_FROM_HEAD ? "imported from" :
	   mode == MICROLABEL_IMPORTED_FROM ? leveldir_current->imported_from :
	   mode == MICROLABEL_IMPORTED_BY_HEAD ? "imported by" :
	   mode == MICROLABEL_IMPORTED_BY ? leveldir_current->imported_by :""),
	  max_len_label_text);
  label_text[max_len_label_text] = '\0';

  if (strlen(label_text) > 0)
  {
#if 1
    DrawTextSAligned(pos->x, pos->y, label_text, font_nr, pos->align);
#else
    int lxpos = SX + (SXSIZE - getTextWidth(label_text, font_nr)) / 2;
    int lypos = MICROLABEL2_YPOS;

    DrawText(lxpos, lypos, label_text, font_nr);
#endif
  }

  redraw_mask |= REDRAW_MICROLEVEL;
}

void DrawPreviewLevel(boolean restart)
{
  static unsigned int scroll_delay = 0;
  static unsigned int label_delay = 0;
  static int from_x, from_y, scroll_direction;
  static int label_state, label_counter;
  unsigned int scroll_delay_value = preview.step_delay;
  boolean show_level_border = (BorderElement != EL_EMPTY);
  int level_xsize = lev_fieldx + (show_level_border ? 2 : 0);
  int level_ysize = lev_fieldy + (show_level_border ? 2 : 0);
  int last_game_status = game_status;		/* save current game status */

#if 0
  /* force PREVIEW font on preview level */
  game_status = GAME_MODE_PSEUDO_PREVIEW;
#endif

  if (restart)
  {
    from_x = 0;
    from_y = 0;

    if (preview.anim_mode == ANIM_CENTERED)
    {
      if (level_xsize > preview.xsize)
	from_x = (level_xsize - preview.xsize) / 2;
      if (level_ysize > preview.ysize)
	from_y = (level_ysize - preview.ysize) / 2;
    }

    from_x += preview.xoffset;
    from_y += preview.yoffset;

    scroll_direction = MV_RIGHT;
    label_state = 1;
    label_counter = 0;

    DrawPreviewLevelExt(from_x, from_y);
    DrawPreviewLevelLabelExt(label_state);

    /* initialize delay counters */
    DelayReached(&scroll_delay, 0);
    DelayReached(&label_delay, 0);

    if (leveldir_current->name)
    {
      struct TextPosInfo *pos = &menu.main.text.level_info_1;
      char label_text[MAX_OUTPUT_LINESIZE + 1];
#if 1
      int font_nr = pos->font;
#else
      int font_nr = FONT_TEXT_1;
#endif
#if 1
      int max_len_label_text = getMaxTextLength(pos, font_nr);
#else
      int max_len_label_text = SXSIZE / getFontWidth(font_nr);
#endif
#if 0
      int text_width;
      int lxpos, lypos;
#endif

#if 1
      if (pos->size != -1)
	max_len_label_text = pos->size;
#endif

      strncpy(label_text, leveldir_current->name, max_len_label_text);
      label_text[max_len_label_text] = '\0';

#if 1
      DrawTextSAligned(pos->x, pos->y, label_text, font_nr, pos->align);
#else
      lxpos = SX + (SXSIZE - getTextWidth(label_text, font_nr)) / 2;
      lypos = SY + MICROLABEL1_YPOS;

      DrawText(lxpos, lypos, label_text, font_nr);
#endif
    }

    game_status = last_game_status;	/* restore current game status */

    return;
  }

  /* scroll preview level, if needed */
  if (preview.anim_mode != ANIM_NONE &&
      (level_xsize > preview.xsize || level_ysize > preview.ysize) &&
      DelayReached(&scroll_delay, scroll_delay_value))
  {
    switch (scroll_direction)
    {
      case MV_LEFT:
	if (from_x > 0)
	{
	  from_x -= preview.step_offset;
	  from_x = (from_x < 0 ? 0 : from_x);
	}
	else
	  scroll_direction = MV_UP;
	break;

      case MV_RIGHT:
	if (from_x < level_xsize - preview.xsize)
	{
	  from_x += preview.step_offset;
	  from_x = (from_x > level_xsize - preview.xsize ?
		    level_xsize - preview.xsize : from_x);
	}
	else
	  scroll_direction = MV_DOWN;
	break;

      case MV_UP:
	if (from_y > 0)
	{
	  from_y -= preview.step_offset;
	  from_y = (from_y < 0 ? 0 : from_y);
	}
	else
	  scroll_direction = MV_RIGHT;
	break;

      case MV_DOWN:
	if (from_y < level_ysize - preview.ysize)
	{
	  from_y += preview.step_offset;
	  from_y = (from_y > level_ysize - preview.ysize ?
		    level_ysize - preview.ysize : from_y);
	}
	else
	  scroll_direction = MV_LEFT;
	break;

      default:
	break;
    }

    DrawPreviewLevelExt(from_x, from_y);
  }

  /* !!! THIS ALL SUCKS -- SHOULD BE CLEANLY REWRITTEN !!! */
  /* redraw micro level label, if needed */
  if (!strEqual(level.name, NAMELESS_LEVEL_NAME) &&
      !strEqual(level.author, ANONYMOUS_NAME) &&
      !strEqual(level.author, leveldir_current->name) &&
      DelayReached(&label_delay, MICROLEVEL_LABEL_DELAY))
  {
    int max_label_counter = 23;

    if (leveldir_current->imported_from != NULL &&
	strlen(leveldir_current->imported_from) > 0)
      max_label_counter += 14;
    if (leveldir_current->imported_by != NULL &&
	strlen(leveldir_current->imported_by) > 0)
      max_label_counter += 14;

    label_counter = (label_counter + 1) % max_label_counter;
    label_state = (label_counter >= 0 && label_counter <= 7 ?
		   MICROLABEL_LEVEL_NAME :
		   label_counter >= 9 && label_counter <= 12 ?
		   MICROLABEL_LEVEL_AUTHOR_HEAD :
		   label_counter >= 14 && label_counter <= 21 ?
		   MICROLABEL_LEVEL_AUTHOR :
		   label_counter >= 23 && label_counter <= 26 ?
		   MICROLABEL_IMPORTED_FROM_HEAD :
		   label_counter >= 28 && label_counter <= 35 ?
		   MICROLABEL_IMPORTED_FROM :
		   label_counter >= 37 && label_counter <= 40 ?
		   MICROLABEL_IMPORTED_BY_HEAD :
		   label_counter >= 42 && label_counter <= 49 ?
		   MICROLABEL_IMPORTED_BY : MICROLABEL_EMPTY);

    if (leveldir_current->imported_from == NULL &&
	(label_state == MICROLABEL_IMPORTED_FROM_HEAD ||
	 label_state == MICROLABEL_IMPORTED_FROM))
      label_state = (label_state == MICROLABEL_IMPORTED_FROM_HEAD ?
		     MICROLABEL_IMPORTED_BY_HEAD : MICROLABEL_IMPORTED_BY);

    DrawPreviewLevelLabelExt(label_state);
  }

  game_status = last_game_status;	/* restore current game status */
}

inline void DrawGraphicAnimationExt(DrawBuffer *dst_bitmap, int x, int y,
				    int graphic, int sync_frame, int mask_mode)
{
  int frame = getGraphicAnimationFrame(graphic, sync_frame);

  if (mask_mode == USE_MASKING)
    DrawGraphicThruMaskExt(dst_bitmap, x, y, graphic, frame);
  else
    DrawGraphicExt(dst_bitmap, x, y, graphic, frame);
}

inline void DrawFixedGraphicAnimationExt(DrawBuffer *dst_bitmap, int x, int y,
					 int graphic, int sync_frame,
					 int mask_mode)
{
  int frame = getGraphicAnimationFrame(graphic, sync_frame);

  if (mask_mode == USE_MASKING)
    DrawFixedGraphicThruMaskExt(dst_bitmap, x, y, graphic, frame);
  else
    DrawFixedGraphicExt(dst_bitmap, x, y, graphic, frame);
}

inline void DrawGraphicAnimation(int x, int y, int graphic)
{
  int lx = LEVELX(x), ly = LEVELY(y);

  if (!IN_SCR_FIELD(x, y))
    return;

#if NEW_TILESIZE
  DrawGraphicAnimationExt(drawto_field, FX + x * TILEX_VAR, FY + y * TILEY_VAR,
			  graphic, GfxFrame[lx][ly], NO_MASKING);
#else
  DrawGraphicAnimationExt(drawto_field, FX + x * TILEX, FY + y * TILEY,
			  graphic, GfxFrame[lx][ly], NO_MASKING);
#endif
  MarkTileDirty(x, y);
}

inline void DrawFixedGraphicAnimation(int x, int y, int graphic)
{
  int lx = LEVELX(x), ly = LEVELY(y);

  if (!IN_SCR_FIELD(x, y))
    return;

  DrawGraphicAnimationExt(drawto_field, FX + x * TILEX, FY + y * TILEY,
			  graphic, GfxFrame[lx][ly], NO_MASKING);
  MarkTileDirty(x, y);
}

void DrawLevelGraphicAnimation(int x, int y, int graphic)
{
  DrawGraphicAnimation(SCREENX(x), SCREENY(y), graphic);
}

void DrawLevelElementAnimation(int x, int y, int element)
{
  int graphic = el_act_dir2img(element, GfxAction[x][y], GfxDir[x][y]);

  DrawGraphicAnimation(SCREENX(x), SCREENY(y), graphic);
}

inline void DrawLevelGraphicAnimationIfNeeded(int x, int y, int graphic)
{
  int sx = SCREENX(x), sy = SCREENY(y);

  if (!IN_LEV_FIELD(x, y) || !IN_SCR_FIELD(sx, sy))
    return;

  if (!IS_NEW_FRAME(GfxFrame[x][y], graphic))
    return;

  DrawGraphicAnimation(sx, sy, graphic);

#if 1
  if (GFX_CRUMBLED(TILE_GFX_ELEMENT(x, y)))
    DrawLevelFieldCrumbled(x, y);
#else
  if (GFX_CRUMBLED(Feld[x][y]))
    DrawLevelFieldCrumbled(x, y);
#endif
}

void DrawLevelElementAnimationIfNeeded(int x, int y, int element)
{
  int sx = SCREENX(x), sy = SCREENY(y);
  int graphic;

  if (!IN_LEV_FIELD(x, y) || !IN_SCR_FIELD(sx, sy))
    return;

  graphic = el_act_dir2img(element, GfxAction[x][y], GfxDir[x][y]);

  if (!IS_NEW_FRAME(GfxFrame[x][y], graphic))
    return;

  DrawGraphicAnimation(sx, sy, graphic);

  if (GFX_CRUMBLED(element))
    DrawLevelFieldCrumbled(x, y);
}

static int getPlayerGraphic(struct PlayerInfo *player, int move_dir)
{
  if (player->use_murphy)
  {
    /* this works only because currently only one player can be "murphy" ... */
    static int last_horizontal_dir = MV_LEFT;
    int graphic = el_act_dir2img(EL_SP_MURPHY, player->GfxAction, move_dir);

    if (move_dir == MV_LEFT || move_dir == MV_RIGHT)
      last_horizontal_dir = move_dir;

    if (graphic == IMG_SP_MURPHY)	/* undefined => use special graphic */
    {
      int direction = (player->is_snapping ? move_dir : last_horizontal_dir);

      graphic = el_act_dir2img(EL_SP_MURPHY, player->GfxAction, direction);
    }

    return graphic;
  }
  else
    return el_act_dir2img(player->artwork_element, player->GfxAction,move_dir);
}

static boolean equalGraphics(int graphic1, int graphic2)
{
  struct GraphicInfo *g1 = &graphic_info[graphic1];
  struct GraphicInfo *g2 = &graphic_info[graphic2];

  return (g1->bitmap      == g2->bitmap &&
	  g1->src_x       == g2->src_x &&
	  g1->src_y       == g2->src_y &&
	  g1->anim_frames == g2->anim_frames &&
	  g1->anim_delay  == g2->anim_delay &&
	  g1->anim_mode   == g2->anim_mode);
}

void DrawAllPlayers()
{
  int i;

  for (i = 0; i < MAX_PLAYERS; i++)
    if (stored_player[i].active)
      DrawPlayer(&stored_player[i]);
}

void DrawPlayerField(int x, int y)
{
  if (!IS_PLAYER(x, y))
    return;

  DrawPlayer(PLAYERINFO(x, y));
}

#define DRAW_PLAYER_OVER_PUSHED_ELEMENT	1

void DrawPlayer(struct PlayerInfo *player)
{
  int jx = player->jx;
  int jy = player->jy;
  int move_dir = player->MovDir;
  int dx = (move_dir == MV_LEFT ? -1 : move_dir == MV_RIGHT ? +1 : 0);
  int dy = (move_dir == MV_UP   ? -1 : move_dir == MV_DOWN  ? +1 : 0);
  int last_jx = (player->is_moving ? jx - dx : jx);
  int last_jy = (player->is_moving ? jy - dy : jy);
  int next_jx = jx + dx;
  int next_jy = jy + dy;
  boolean player_is_moving = (player->MovPos ? TRUE : FALSE);
  boolean player_is_opaque = FALSE;
  int sx = SCREENX(jx), sy = SCREENY(jy);
  int sxx = 0, syy = 0;
  int element = Feld[jx][jy], last_element = Feld[last_jx][last_jy];
  int graphic;
  int action = ACTION_DEFAULT;
  int last_player_graphic = getPlayerGraphic(player, move_dir);
  int last_player_frame = player->Frame;
  int frame = 0;

  /* GfxElement[][] is set to the element the player is digging or collecting;
     remove also for off-screen player if the player is not moving anymore */
  if (IN_LEV_FIELD(jx, jy) && !player_is_moving)
    GfxElement[jx][jy] = EL_UNDEFINED;

  if (!player->active || !IN_SCR_FIELD(SCREENX(last_jx), SCREENY(last_jy)))
    return;

#if DEBUG
  if (!IN_LEV_FIELD(jx, jy))
  {
    printf("DrawPlayerField(): x = %d, y = %d\n",jx,jy);
    printf("DrawPlayerField(): sx = %d, sy = %d\n",sx,sy);
    printf("DrawPlayerField(): This should never happen!\n");
    return;
  }
#endif

  if (element == EL_EXPLOSION)
    return;

  action = (player->is_pushing    ? ACTION_PUSHING         :
	    player->is_digging    ? ACTION_DIGGING         :
	    player->is_collecting ? ACTION_COLLECTING      :
	    player->is_moving     ? ACTION_MOVING          :
	    player->is_snapping   ? ACTION_SNAPPING        :
	    player->is_dropping   ? ACTION_DROPPING        :
	    player->is_waiting    ? player->action_waiting : ACTION_DEFAULT);

  if (player->is_waiting)
    move_dir = player->dir_waiting;

  InitPlayerGfxAnimation(player, action, move_dir);

  /* ----------------------------------------------------------------------- */
  /* draw things in the field the player is leaving, if needed               */
  /* ----------------------------------------------------------------------- */

  if (player->is_moving)
  {
    if (Back[last_jx][last_jy] && IS_DRAWABLE(last_element))
    {
      DrawLevelElement(last_jx, last_jy, Back[last_jx][last_jy]);

      if (last_element == EL_DYNAMITE_ACTIVE ||
	  last_element == EL_EM_DYNAMITE_ACTIVE ||
	  last_element == EL_SP_DISK_RED_ACTIVE)
	DrawDynamite(last_jx, last_jy);
      else
	DrawLevelFieldThruMask(last_jx, last_jy);
    }
    else if (last_element == EL_DYNAMITE_ACTIVE ||
	     last_element == EL_EM_DYNAMITE_ACTIVE ||
	     last_element == EL_SP_DISK_RED_ACTIVE)
      DrawDynamite(last_jx, last_jy);
#if 0
    /* !!! this is not enough to prevent flickering of players which are
       moving next to each others without a free tile between them -- this
       can only be solved by drawing all players layer by layer (first the
       background, then the foreground etc.) !!! => TODO */
    else if (!IS_PLAYER(last_jx, last_jy))
      DrawLevelField(last_jx, last_jy);
#else
    else
      DrawLevelField(last_jx, last_jy);
#endif

    if (player->is_pushing && IN_SCR_FIELD(SCREENX(next_jx), SCREENY(next_jy)))
      DrawLevelElement(next_jx, next_jy, EL_EMPTY);
  }

  if (!IN_SCR_FIELD(sx, sy))
    return;

  /* ----------------------------------------------------------------------- */
  /* draw things behind the player, if needed                                */
  /* ----------------------------------------------------------------------- */

  if (Back[jx][jy])
    DrawLevelElement(jx, jy, Back[jx][jy]);
  else if (IS_ACTIVE_BOMB(element))
    DrawLevelElement(jx, jy, EL_EMPTY);
  else
  {
    if (player_is_moving && GfxElement[jx][jy] != EL_UNDEFINED)
    {
      int old_element = GfxElement[jx][jy];
      int old_graphic = el_act_dir2img(old_element, action, move_dir);
      int frame = getGraphicAnimationFrame(old_graphic, player->StepFrame);

      if (GFX_CRUMBLED(old_element))
	DrawLevelFieldCrumbledDigging(jx, jy, move_dir, player->StepFrame);
      else
	DrawGraphic(sx, sy, old_graphic, frame);

      if (graphic_info[old_graphic].anim_mode & ANIM_OPAQUE_PLAYER)
	player_is_opaque = TRUE;
    }
    else
    {
      GfxElement[jx][jy] = EL_UNDEFINED;

      /* make sure that pushed elements are drawn with correct frame rate */
#if 1
      graphic = el_act_dir2img(element, ACTION_PUSHING, move_dir);

      if (player->is_pushing && player->is_moving && !IS_ANIM_MODE_CE(graphic))
	GfxFrame[jx][jy] = player->StepFrame;
#else
      if (player->is_pushing && player->is_moving)
	GfxFrame[jx][jy] = player->StepFrame;
#endif

      DrawLevelField(jx, jy);
    }
  }

#if !DRAW_PLAYER_OVER_PUSHED_ELEMENT
  /* ----------------------------------------------------------------------- */
  /* draw player himself                                                     */
  /* ----------------------------------------------------------------------- */

  graphic = getPlayerGraphic(player, move_dir);

  /* in the case of changed player action or direction, prevent the current
     animation frame from being restarted for identical animations */
  if (player->Frame == 0 && equalGraphics(graphic, last_player_graphic))
    player->Frame = last_player_frame;

  frame = getGraphicAnimationFrame(graphic, player->Frame);

  if (player->GfxPos)
  {
    if (move_dir == MV_LEFT || move_dir == MV_RIGHT)
      sxx = player->GfxPos;
    else
      syy = player->GfxPos;
  }

  if (!setup.soft_scrolling && ScreenMovPos)
    sxx = syy = 0;

  if (player_is_opaque)
    DrawGraphicShifted(sx, sy, sxx, syy, graphic, frame,NO_CUTTING,NO_MASKING);
  else
    DrawGraphicShiftedThruMask(sx, sy, sxx, syy, graphic, frame, NO_CUTTING);

  if (SHIELD_ON(player))
  {
    int graphic = (player->shield_deadly_time_left ? IMG_SHIELD_DEADLY_ACTIVE :
		   IMG_SHIELD_NORMAL_ACTIVE);
    int frame = getGraphicAnimationFrame(graphic, -1);

    DrawGraphicShiftedThruMask(sx, sy, sxx, syy, graphic, frame, NO_CUTTING);
  }
#endif

#if DRAW_PLAYER_OVER_PUSHED_ELEMENT
  if (player->GfxPos)
  {
    if (move_dir == MV_LEFT || move_dir == MV_RIGHT)
      sxx = player->GfxPos;
    else
      syy = player->GfxPos;
  }
#endif

  /* ----------------------------------------------------------------------- */
  /* draw things the player is pushing, if needed                            */
  /* ----------------------------------------------------------------------- */

#if 0
  printf("::: %d, %d [%d, %d] [%d]\n",
	 player->is_pushing, player_is_moving, player->GfxAction,
	 player->is_moving, player_is_moving);
#endif

#if 1
  if (player->is_pushing && player->is_moving)
  {
    int px = SCREENX(jx), py = SCREENY(jy);
    int pxx = (TILEX - ABS(sxx)) * dx;
    int pyy = (TILEY - ABS(syy)) * dy;
    int gfx_frame = GfxFrame[jx][jy];

    int graphic;
    int sync_frame;
    int frame;

    if (!IS_MOVING(jx, jy))		/* push movement already finished */
    {
      element = Feld[next_jx][next_jy];
      gfx_frame = GfxFrame[next_jx][next_jy];
    }

    graphic = el_act_dir2img(element, ACTION_PUSHING, move_dir);

#if 1
    sync_frame = (IS_ANIM_MODE_CE(graphic) ? gfx_frame : player->StepFrame);
    frame = getGraphicAnimationFrame(graphic, sync_frame);
#else
    frame = getGraphicAnimationFrame(graphic, player->StepFrame);
#endif

    /* draw background element under pushed element (like the Sokoban field) */
#if 1
    if (game.use_masked_pushing && IS_MOVING(jx, jy))
    {
      /* this allows transparent pushing animation over non-black background */

      if (Back[jx][jy])
	DrawLevelElement(jx, jy, Back[jx][jy]);
      else
	DrawLevelElement(jx, jy, EL_EMPTY);

      if (Back[next_jx][next_jy])
	DrawLevelElement(next_jx, next_jy, Back[next_jx][next_jy]);
      else
	DrawLevelElement(next_jx, next_jy, EL_EMPTY);
    }
    else if (Back[next_jx][next_jy])
      DrawLevelElement(next_jx, next_jy, Back[next_jx][next_jy]);
#else
    if (Back[next_jx][next_jy])
      DrawLevelElement(next_jx, next_jy, Back[next_jx][next_jy]);
#endif

#if 0
    printf("::: %d, %d, %d, %d [%d] [%d, %d, %d] [%d] [%d, %d] [%d, %d]\n",
	   jx, px, player->GfxPos, player->StepFrame,
	   player->is_pushing,
	   dx, sxx, pxx,
	   IS_MOVING(jx, jy),
	   graphic, frame,
	   GfxFrame[jx][jy], GfxFrame[next_jx][next_jy]);
#endif

#if 1
    /* do not draw (EM style) pushing animation when pushing is finished */
    /* (two-tile animations usually do not contain start and end frame) */
    if (graphic_info[graphic].double_movement && !IS_MOVING(jx, jy))
      DrawLevelElement(next_jx, next_jy, Feld[next_jx][next_jy]);
    else
      DrawGraphicShiftedThruMask(px, py, pxx, pyy, graphic, frame, NO_CUTTING);
#else
    /* masked drawing is needed for EMC style (double) movement graphics */
    /* !!! (ONLY WHEN DRAWING PUSHED ELEMENT OVER THE PLAYER) !!! */
    DrawGraphicShiftedThruMask(px, py, pxx, pyy, graphic, frame, NO_CUTTING);
#endif
  }
#endif

#if DRAW_PLAYER_OVER_PUSHED_ELEMENT
  /* ----------------------------------------------------------------------- */
  /* draw player himself                                                     */
  /* ----------------------------------------------------------------------- */

  graphic = getPlayerGraphic(player, move_dir);

  /* in the case of changed player action or direction, prevent the current
     animation frame from being restarted for identical animations */
  if (player->Frame == 0 && equalGraphics(graphic, last_player_graphic))
    player->Frame = last_player_frame;

  frame = getGraphicAnimationFrame(graphic, player->Frame);

  if (player->GfxPos)
  {
    if (move_dir == MV_LEFT || move_dir == MV_RIGHT)
      sxx = player->GfxPos;
    else
      syy = player->GfxPos;
  }

  if (!setup.soft_scrolling && ScreenMovPos)
    sxx = syy = 0;

  if (player_is_opaque)
    DrawGraphicShifted(sx, sy, sxx, syy, graphic, frame,NO_CUTTING,NO_MASKING);
  else
    DrawGraphicShiftedThruMask(sx, sy, sxx, syy, graphic, frame, NO_CUTTING);

  if (SHIELD_ON(player))
  {
    int graphic = (player->shield_deadly_time_left ? IMG_SHIELD_DEADLY_ACTIVE :
		   IMG_SHIELD_NORMAL_ACTIVE);
    int frame = getGraphicAnimationFrame(graphic, -1);

    DrawGraphicShiftedThruMask(sx, sy, sxx, syy, graphic, frame, NO_CUTTING);
  }
#endif

  /* ----------------------------------------------------------------------- */
  /* draw things in front of player (active dynamite or dynabombs)           */
  /* ----------------------------------------------------------------------- */

  if (IS_ACTIVE_BOMB(element))
  {
    graphic = el2img(element);
    frame = getGraphicAnimationFrame(graphic, GfxFrame[jx][jy]);

    if (game.emulation == EMU_SUPAPLEX)
      DrawGraphic(sx, sy, IMG_SP_DISK_RED, frame);
    else
      DrawGraphicThruMask(sx, sy, graphic, frame);
  }

  if (player_is_moving && last_element == EL_EXPLOSION)
  {
    int element = (GfxElement[last_jx][last_jy] != EL_UNDEFINED ?
		   GfxElement[last_jx][last_jy] :  EL_EMPTY);
    int graphic = el_act2img(element, ACTION_EXPLODING);
    int delay = (game.emulation == EMU_SUPAPLEX ? 3 : 2);
    int phase = ExplodePhase[last_jx][last_jy] - 1;
    int frame = getGraphicAnimationFrame(graphic, phase - delay);

    if (phase >= delay)
      DrawGraphicThruMask(SCREENX(last_jx), SCREENY(last_jy), graphic, frame);
  }

  /* ----------------------------------------------------------------------- */
  /* draw elements the player is just walking/passing through/under          */
  /* ----------------------------------------------------------------------- */

  if (player_is_moving)
  {
    /* handle the field the player is leaving ... */
    if (IS_ACCESSIBLE_INSIDE(last_element))
      DrawLevelField(last_jx, last_jy);
    else if (IS_ACCESSIBLE_UNDER(last_element))
      DrawLevelFieldThruMask(last_jx, last_jy);
  }

  /* do not redraw accessible elements if the player is just pushing them */
  if (!player_is_moving || !player->is_pushing)
  {
    /* ... and the field the player is entering */
    if (IS_ACCESSIBLE_INSIDE(element))
      DrawLevelField(jx, jy);
    else if (IS_ACCESSIBLE_UNDER(element))
      DrawLevelFieldThruMask(jx, jy);
  }

  MarkTileDirty(sx, sy);
}

/* ------------------------------------------------------------------------- */

void WaitForEventToContinue()
{
  boolean still_wait = TRUE;

  /* simulate releasing mouse button over last gadget, if still pressed */
  if (button_status)
    HandleGadgets(-1, -1, 0);

  button_status = MB_RELEASED;

#if 1
  ClearEventQueue();
#endif

  while (still_wait)
  {
    if (PendingEvent())
    {
      Event event;

      NextEvent(&event);

      switch (event.type)
      {
	case EVENT_BUTTONPRESS:
	case EVENT_KEYPRESS:
	  still_wait = FALSE;
	  break;

	case EVENT_KEYRELEASE:
	  ClearPlayerAction();
	  break;

	default:
	  HandleOtherEvents(&event);
	  break;
      }
    }
    else if (AnyJoystickButton() == JOY_BUTTON_NEW_PRESSED)
    {
      still_wait = FALSE;
    }

    DoAnimation();

    /* don't eat all CPU time */
    Delay(10);
  }
}

#define MAX_REQUEST_LINES		13
#define MAX_REQUEST_LINE_FONT1_LEN	7
#define MAX_REQUEST_LINE_FONT2_LEN	10

boolean Request(char *text, unsigned int req_state)
{
  int mx, my, ty, result = -1;
  unsigned int old_door_state;
  int last_game_status = game_status;	/* save current game status */
  int max_request_line_len = MAX_REQUEST_LINE_FONT1_LEN;
  int font_nr = FONT_TEXT_2;
#if 0
  int max_word_len = 0;
#endif
  char *text_ptr;
  int i;

#if 1
  global.use_envelope_request = 0;
#endif

#if 1
  if (maxWordLengthInString(text) > MAX_REQUEST_LINE_FONT1_LEN)
  {
    max_request_line_len = MAX_REQUEST_LINE_FONT2_LEN;
    font_nr = FONT_TEXT_1;
  }
#else
  for (text_ptr = text; *text_ptr; text_ptr++)
  {
    max_word_len = (*text_ptr != ' ' ? max_word_len + 1 : 0);

    if (max_word_len > MAX_REQUEST_LINE_FONT1_LEN)
    {
      max_request_line_len = MAX_REQUEST_LINE_FONT2_LEN;
#if 1
      font_nr = FONT_TEXT_1;
#else
      font_nr = FONT_LEVEL_NUMBER;
#endif

      break;
    }
  }
#endif

  if (game_status == GAME_MODE_PLAYING)
  {
    if (level.game_engine_type == GAME_ENGINE_TYPE_EM)
      BlitScreenToBitmap_EM(backbuffer);
    else if (level.game_engine_type == GAME_ENGINE_TYPE_SP)
      BlitScreenToBitmap_SP(backbuffer);
  }

  /* disable deactivated drawing when quick-loading level tape recording */
  if (tape.playing && tape.deactivate_display)
    TapeDeactivateDisplayOff(TRUE);

  SetMouseCursor(CURSOR_DEFAULT);

#if defined(NETWORK_AVALIABLE)
  /* pause network game while waiting for request to answer */
  if (options.network &&
      game_status == GAME_MODE_PLAYING &&
      req_state & REQUEST_WAIT_FOR_INPUT)
    SendToServer_PausePlaying();
#endif

  old_door_state = GetDoorState();

  /* simulate releasing mouse button over last gadget, if still pressed */
  if (button_status)
    HandleGadgets(-1, -1, 0);

  UnmapAllGadgets();

  /* draw released gadget before proceeding */
  // BackToFront();

#if 0
  if (old_door_state & DOOR_OPEN_1 && !global.use_envelope_request)
#else
  if (old_door_state & DOOR_OPEN_1)
#endif
  {
#if 1
    if (!global.use_envelope_request)
      CloseDoor(DOOR_CLOSE_1);
#else
    CloseDoor(DOOR_CLOSE_1);
#endif

    /* save old door content */
    BlitBitmap(bitmap_db_door, bitmap_db_door,
	       DOOR_GFX_PAGEX1, DOOR_GFX_PAGEY1, DXSIZE, DYSIZE,
	       DOOR_GFX_PAGEX2, DOOR_GFX_PAGEY1);
  }

#if 1
  SetDoorBackgroundImage(IMG_BACKGROUND_DOOR);
#endif

  SetDrawBackgroundMask(REDRAW_FIELD | REDRAW_DOOR_1);

  /* clear door drawing field */
  DrawBackground(DX, DY, DXSIZE, DYSIZE);

  /* force DOOR font inside door area */
  game_status = GAME_MODE_PSEUDO_DOOR;

  /* write text for request */
  for (text_ptr = text, ty = 0; ty < MAX_REQUEST_LINES; ty++)
  {
    char text_line[max_request_line_len + 1];
    int tx, tl, tc = 0;

    if (!*text_ptr)
      break;

    for (tl = 0, tx = 0; tx < max_request_line_len; tl++, tx++)
    {
      tc = *(text_ptr + tx);
      if (!tc || tc == ' ')
	break;
    }

    if (!tl)
    { 
      text_ptr++; 
      ty--; 
      continue; 
    }

    strncpy(text_line, text_ptr, tl);
    text_line[tl] = 0;

    DrawText(DX + (DXSIZE - tl * getFontWidth(font_nr)) / 2,
	     DY + 8 + ty * (getFontHeight(font_nr) + 2),
	     text_line, font_nr);

    text_ptr += tl + (tc == ' ' ? 1 : 0);
  }

  game_status = last_game_status;	/* restore current game status */

#if 1
  if (global.use_envelope_request)
  {
    /* !!! TMP !!! */
    FreeToolButtons();
    CreateToolButtons();
  }
#endif

  if (req_state & REQ_ASK)
  {
    MapGadget(tool_gadget[TOOL_CTRL_ID_YES]);
    MapGadget(tool_gadget[TOOL_CTRL_ID_NO]);
  }
  else if (req_state & REQ_CONFIRM)
  {
    MapGadget(tool_gadget[TOOL_CTRL_ID_CONFIRM]);
  }
  else if (req_state & REQ_PLAYER)
  {
    MapGadget(tool_gadget[TOOL_CTRL_ID_PLAYER_1]);
    MapGadget(tool_gadget[TOOL_CTRL_ID_PLAYER_2]);
    MapGadget(tool_gadget[TOOL_CTRL_ID_PLAYER_3]);
    MapGadget(tool_gadget[TOOL_CTRL_ID_PLAYER_4]);
  }

  /* copy request gadgets to door backbuffer */
  BlitBitmap(drawto, bitmap_db_door,
	     DX, DY, DXSIZE, DYSIZE,
	     DOOR_GFX_PAGEX1, DOOR_GFX_PAGEY1);

#if 1
  if (global.use_envelope_request)
  {
    ShowEnvelopeDoor(text, ACTION_OPENING);

    for (i = 0; i < NUM_TOOL_BUTTONS; i++)
    {
      if ((req_state & REQ_ASK && (i == TOOL_CTRL_ID_YES ||
				   i == TOOL_CTRL_ID_NO)) ||
	  (req_state & REQ_CONFIRM && i == TOOL_CTRL_ID_CONFIRM) ||
	  (req_state & REQ_PLAYER && (i == TOOL_CTRL_ID_PLAYER_1 &&
				      i == TOOL_CTRL_ID_PLAYER_2 &&
				      i == TOOL_CTRL_ID_PLAYER_3 &&
				      i == TOOL_CTRL_ID_PLAYER_4)))
      {
	int x = tool_gadget[i]->x + dDX;
	int y = tool_gadget[i]->y + dDY;

	ModifyGadget(tool_gadget[i], GDI_X, x, GDI_Y, y, GDI_END);
      }
    }
  }
#endif

#if 1
  if (!global.use_envelope_request)
    OpenDoor(DOOR_OPEN_1);
#else
  OpenDoor(DOOR_OPEN_1);
#endif

  if (!(req_state & REQUEST_WAIT_FOR_INPUT))
  {
    if (game_status == GAME_MODE_PLAYING)
    {
      SetPanelBackground();
      SetDrawBackgroundMask(REDRAW_DOOR_1);
    }
    else
    {
      SetDrawBackgroundMask(REDRAW_FIELD);
    }

    return FALSE;
  }

#if 1
  if (game_status != GAME_MODE_MAIN && !global.use_envelope_request)
    InitAnimation();
#else
  if (game_status != GAME_MODE_MAIN)
    InitAnimation();
#endif

  button_status = MB_RELEASED;

  request_gadget_id = -1;

  SetDrawBackgroundMask(REDRAW_FIELD | REDRAW_DOOR_1);

  while (result < 0)
  {
    if (PendingEvent())
    {
      Event event;

      NextEvent(&event);

      switch (event.type)
      {
	case EVENT_BUTTONPRESS:
	case EVENT_BUTTONRELEASE:
	case EVENT_MOTIONNOTIFY:
	{
	  if (event.type == EVENT_MOTIONNOTIFY)
	  {
	    if (!PointerInWindow(window))
	      continue;	/* window and pointer are on different screens */

	    if (!button_status)
	      continue;

	    motion_status = TRUE;
	    mx = ((MotionEvent *) &event)->x;
	    my = ((MotionEvent *) &event)->y;
	  }
	  else
	  {
	    motion_status = FALSE;
	    mx = ((ButtonEvent *) &event)->x;
	    my = ((ButtonEvent *) &event)->y;
	    if (event.type == EVENT_BUTTONPRESS)
	      button_status = ((ButtonEvent *) &event)->button;
	    else
	      button_status = MB_RELEASED;
	  }

	  /* this sets 'request_gadget_id' */
	  HandleGadgets(mx, my, button_status);

	  switch (request_gadget_id)
	  {
	    case TOOL_CTRL_ID_YES:
	      result = TRUE;
	      break;
	    case TOOL_CTRL_ID_NO:
	      result = FALSE;
	      break;
	    case TOOL_CTRL_ID_CONFIRM:
	      result = TRUE | FALSE;
	      break;

	    case TOOL_CTRL_ID_PLAYER_1:
	      result = 1;
	      break;
	    case TOOL_CTRL_ID_PLAYER_2:
	      result = 2;
	      break;
	    case TOOL_CTRL_ID_PLAYER_3:
	      result = 3;
	      break;
	    case TOOL_CTRL_ID_PLAYER_4:
	      result = 4;
	      break;

	    default:
	      break;
	  }

	  break;
	}

	case EVENT_KEYPRESS:
	  switch (GetEventKey((KeyEvent *)&event, TRUE))
	  {
	    case KSYM_space:
	      if (req_state & REQ_CONFIRM)
		result = 1;
	      break;

	    case KSYM_Return:
	      result = 1;
	      break;

	    case KSYM_Escape:
	      result = 0;
	      break;

	    default:
	      break;
	  }

	  if (req_state & REQ_PLAYER)
	    result = 0;
	  break;

	case EVENT_KEYRELEASE:
	  ClearPlayerAction();
	  break;

	default:
	  HandleOtherEvents(&event);
	  break;
      }
    }
    else if (AnyJoystickButton() == JOY_BUTTON_NEW_PRESSED)
    {
      int joy = AnyJoystick();

      if (joy & JOY_BUTTON_1)
	result = 1;
      else if (joy & JOY_BUTTON_2)
	result = 0;
    }

#if 1

    if (game_status == GAME_MODE_PLAYING && local_player->LevelSolved_GameEnd)
    {
      HandleGameActions();
    }
    else
    {
      DoAnimation();

      if (!PendingEvent())	/* delay only if no pending events */
	Delay(10);
    }

#if 1
    game_status = GAME_MODE_PSEUDO_DOOR;
#endif

    BackToFront();

#if 1
    game_status = last_game_status;	/* restore current game status */
#endif

#else

    DoAnimation();

#if 1
    if (!PendingEvent())	/* delay only if no pending events */
      Delay(10);
#else
    /* don't eat all CPU time */
    Delay(10);
#endif

#endif
  }

  if (game_status != GAME_MODE_MAIN)
    StopAnimation();

  UnmapToolButtons();

#if 1
  if (global.use_envelope_request)
    ShowEnvelopeDoor(text, ACTION_CLOSING);
#endif

#if 1
  if (!(req_state & REQ_STAY_OPEN) && !global.use_envelope_request)
#else
  if (!(req_state & REQ_STAY_OPEN))
#endif
  {
    CloseDoor(DOOR_CLOSE_1);

    if (((old_door_state & DOOR_OPEN_1) && !(req_state & REQ_STAY_CLOSED)) ||
	(req_state & REQ_REOPEN))
      OpenDoor(DOOR_OPEN_1 | DOOR_COPY_BACK);
  }

  RemapAllGadgets();

  if (game_status == GAME_MODE_PLAYING)
  {
    SetPanelBackground();
    SetDrawBackgroundMask(REDRAW_DOOR_1);
  }
  else
  {
    SetDrawBackgroundMask(REDRAW_FIELD);
  }

#if defined(NETWORK_AVALIABLE)
  /* continue network game after request */
  if (options.network &&
      game_status == GAME_MODE_PLAYING &&
      req_state & REQUEST_WAIT_FOR_INPUT)
    SendToServer_ContinuePlaying();
#endif

  /* restore deactivated drawing when quick-loading level tape recording */
  if (tape.playing && tape.deactivate_display)
    TapeDeactivateDisplayOn();

  return result;
}

unsigned int OpenDoor(unsigned int door_state)
{
  if (door_state & DOOR_COPY_BACK)
  {
    if (door_state & DOOR_OPEN_1)
      BlitBitmap(bitmap_db_door, bitmap_db_door,
		 DOOR_GFX_PAGEX2, DOOR_GFX_PAGEY1, DXSIZE, DYSIZE,
		 DOOR_GFX_PAGEX1, DOOR_GFX_PAGEY1);

    if (door_state & DOOR_OPEN_2)
      BlitBitmap(bitmap_db_door, bitmap_db_door,
		 DOOR_GFX_PAGEX2, DOOR_GFX_PAGEY2, VXSIZE, VYSIZE,
		 DOOR_GFX_PAGEX1, DOOR_GFX_PAGEY2);

    door_state &= ~DOOR_COPY_BACK;
  }

  return MoveDoor(door_state);
}

unsigned int CloseDoor(unsigned int door_state)
{
  unsigned int old_door_state = GetDoorState();

  if (!(door_state & DOOR_NO_COPY_BACK))
  {
    if (old_door_state & DOOR_OPEN_1)
      BlitBitmap(backbuffer, bitmap_db_door,
		 DX, DY, DXSIZE, DYSIZE, DOOR_GFX_PAGEX1, DOOR_GFX_PAGEY1);

    if (old_door_state & DOOR_OPEN_2)
      BlitBitmap(backbuffer, bitmap_db_door,
		 VX, VY, VXSIZE, VYSIZE, DOOR_GFX_PAGEX1, DOOR_GFX_PAGEY2);

    door_state &= ~DOOR_NO_COPY_BACK;
  }

  return MoveDoor(door_state);
}

unsigned int GetDoorState()
{
  return MoveDoor(DOOR_GET_STATE);
}

unsigned int SetDoorState(unsigned int door_state)
{
  return MoveDoor(door_state | DOOR_SET_STATE);
}

unsigned int MoveDoor(unsigned int door_state)
{
  static int door1 = DOOR_OPEN_1;
  static int door2 = DOOR_CLOSE_2;
  unsigned int door_delay = 0;
  unsigned int door_delay_value;
  int stepsize = 1;

  if (door_1.width < 0 || door_1.width > DXSIZE)
    door_1.width = DXSIZE;
  if (door_1.height < 0 || door_1.height > DYSIZE)
    door_1.height = DYSIZE;
  if (door_2.width < 0 || door_2.width > VXSIZE)
    door_2.width = VXSIZE;
  if (door_2.height < 0 || door_2.height > VYSIZE)
    door_2.height = VYSIZE;

  if (door_state == DOOR_GET_STATE)
    return (door1 | door2);

  if (door_state & DOOR_SET_STATE)
  {
    if (door_state & DOOR_ACTION_1)
      door1 = door_state & DOOR_ACTION_1;
    if (door_state & DOOR_ACTION_2)
      door2 = door_state & DOOR_ACTION_2;

    return (door1 | door2);
  }

  if (!(door_state & DOOR_FORCE_REDRAW))
  {
    if (door1 == DOOR_OPEN_1 && door_state & DOOR_OPEN_1)
      door_state &= ~DOOR_OPEN_1;
    else if (door1 == DOOR_CLOSE_1 && door_state & DOOR_CLOSE_1)
      door_state &= ~DOOR_CLOSE_1;
    if (door2 == DOOR_OPEN_2 && door_state & DOOR_OPEN_2)
      door_state &= ~DOOR_OPEN_2;
    else if (door2 == DOOR_CLOSE_2 && door_state & DOOR_CLOSE_2)
      door_state &= ~DOOR_CLOSE_2;
  }

  door_delay_value = (door_state & DOOR_ACTION_1 ? door_1.step_delay :
		      door_2.step_delay);

  if (setup.quick_doors)
  {
    stepsize = 20;		/* must be chosen to always draw last frame */
    door_delay_value = 0;
  }

  if (global.autoplay_leveldir)
  {
    door_state |= DOOR_NO_DELAY;
    door_state &= ~DOOR_CLOSE_ALL;
  }

#if 1
  if (game_status == GAME_MODE_EDITOR)
    door_state |= DOOR_NO_DELAY;
#endif

  if (door_state & DOOR_ACTION)
  {
    boolean handle_door_1 = (door_state & DOOR_ACTION_1);
    boolean handle_door_2 = (door_state & DOOR_ACTION_2);
    boolean door_1_done = (!handle_door_1);
    boolean door_2_done = (!handle_door_2);
    boolean door_1_vertical = (door_1.anim_mode & ANIM_VERTICAL);
    boolean door_2_vertical = (door_2.anim_mode & ANIM_VERTICAL);
    int door_size_1 = (door_1_vertical ? door_1.height : door_1.width);
    int door_size_2 = (door_2_vertical ? door_2.height : door_2.width);
    int max_door_size_1 = (door_1_vertical ? DYSIZE : DXSIZE);
    int max_door_size_2 = (door_2_vertical ? VYSIZE : VXSIZE);
    int door_size     = (handle_door_1 ? door_size_1     : door_size_2);
    int max_door_size = (handle_door_1 ? max_door_size_1 : max_door_size_2);
    int door_skip = max_door_size - door_size;
    int end = door_size;
    int start = ((door_state & DOOR_NO_DELAY) ? end : 0);
    int k;

    if (!(door_state & DOOR_NO_DELAY) && !setup.quick_doors)
    {
      /* opening door sound has priority over simultaneously closing door */
      if (door_state & (DOOR_OPEN_1 | DOOR_OPEN_2))
	PlayMenuSoundStereo(SND_DOOR_OPENING, SOUND_MIDDLE);
      else if (door_state & (DOOR_CLOSE_1 | DOOR_CLOSE_2))
	PlayMenuSoundStereo(SND_DOOR_CLOSING, SOUND_MIDDLE);
    }

    for (k = start; k <= end && !(door_1_done && door_2_done); k += stepsize)
    {
      int x = k;
      Bitmap *bitmap = graphic_info[IMG_GLOBAL_DOOR].bitmap;
      GC gc = bitmap->stored_clip_gc;

      if (door_state & DOOR_ACTION_1)
      {
	int a = MIN(x * door_1.step_offset, end);
	int p = (door_state & DOOR_OPEN_1 ? end - a : a);
	int i = p + door_skip;

	if (door_1.anim_mode & ANIM_STATIC_PANEL)
	{
	  BlitBitmap(bitmap_db_door, drawto,
		     DOOR_GFX_PAGEX1, DOOR_GFX_PAGEY1,
		     DXSIZE, DYSIZE, DX, DY);
	}
	else if (x <= a)
	{
	  BlitBitmap(bitmap_db_door, drawto,
		     DOOR_GFX_PAGEX1, DOOR_GFX_PAGEY1 + p / 2,
		     DXSIZE, DYSIZE - p / 2, DX, DY);

	  ClearRectangle(drawto, DX, DY + DYSIZE - p / 2, DXSIZE, p / 2);
	}

	if (door_1.anim_mode & ANIM_HORIZONTAL && x <= DXSIZE)
	{
	  int src1_x = DXSIZE,		src1_y = DOOR_GFX_PAGEY1;
	  int dst1_x = DX + DXSIZE - i,	dst1_y = DY;
	  int src2_x = DXSIZE - i,	src2_y = DOOR_GFX_PAGEY1;
	  int dst2_x = DX,		dst2_y = DY;
	  int width = i, height = DYSIZE;

	  SetClipOrigin(bitmap, gc, dst1_x - src1_x, dst1_y - src1_y);
	  BlitBitmapMasked(bitmap, drawto, src1_x, src1_y, width, height,
			   dst1_x, dst1_y);

	  SetClipOrigin(bitmap, gc, dst2_x - src2_x, dst2_y - src2_y);
	  BlitBitmapMasked(bitmap, drawto, src2_x, src2_y, width, height,
			   dst2_x, dst2_y);
	}
	else if (door_1.anim_mode & ANIM_VERTICAL && x <= DYSIZE)
	{
	  int src1_x = DXSIZE,		src1_y = DOOR_GFX_PAGEY1;
	  int dst1_x = DX,		dst1_y = DY + DYSIZE - i;
	  int src2_x = 0,		src2_y = DOOR_GFX_PAGEY1 + DYSIZE - i;
	  int dst2_x = DX,		dst2_y = DY;
	  int width = DXSIZE, height = i;

	  SetClipOrigin(bitmap, gc, dst1_x - src1_x, dst1_y - src1_y);
	  BlitBitmapMasked(bitmap, drawto, src1_x, src1_y, width, height,
			   dst1_x, dst1_y);

	  SetClipOrigin(bitmap, gc, dst2_x - src2_x, dst2_y - src2_y);
	  BlitBitmapMasked(bitmap, drawto, src2_x, src2_y, width, height,
			   dst2_x, dst2_y);
	}
	else if (x <= DXSIZE)	/* ANIM_DEFAULT */
	{
	  int j = (door_1.anim_mode == ANIM_DEFAULT ? (DXSIZE - i) / 3 : 0);

	  SetClipOrigin(bitmap, gc, DX - i, (DY + j) - DOOR_GFX_PAGEY1);
	  BlitBitmapMasked(bitmap, drawto,
			   DXSIZE, DOOR_GFX_PAGEY1, i, 77,
			   DX + DXSIZE - i, DY + j);
	  BlitBitmapMasked(bitmap, drawto,
			   DXSIZE, DOOR_GFX_PAGEY1 + 140, i, 63,
			   DX + DXSIZE - i, DY + 140 + j);
	  SetClipOrigin(bitmap, gc, DX - DXSIZE + i,
			DY - (DOOR_GFX_PAGEY1 + j));
	  BlitBitmapMasked(bitmap, drawto,
			   DXSIZE - i, DOOR_GFX_PAGEY1 + j, i, 77 - j,
			   DX, DY);
	  BlitBitmapMasked(bitmap, drawto,
			   DXSIZE-i, DOOR_GFX_PAGEY1 + 140, i, 63,
			   DX, DY + 140 - j);

	  BlitBitmapMasked(bitmap, drawto,
			   DXSIZE - i, DOOR_GFX_PAGEY1 + 77, i, 63,
			   DX, DY + 77 - j);
	  BlitBitmapMasked(bitmap, drawto,
			   DXSIZE - i, DOOR_GFX_PAGEY1 + 203, i, 77,
			   DX, DY + 203 - j);
	  SetClipOrigin(bitmap, gc, DX - i, (DY + j) - DOOR_GFX_PAGEY1);
	  BlitBitmapMasked(bitmap, drawto,
			   DXSIZE, DOOR_GFX_PAGEY1 + 77, i, 63,
			   DX + DXSIZE - i, DY + 77 + j);
	  BlitBitmapMasked(bitmap, drawto,
			   DXSIZE, DOOR_GFX_PAGEY1 + 203, i, 77 - j,
			   DX + DXSIZE - i, DY + 203 + j);
	}

	redraw_mask |= REDRAW_DOOR_1;
	door_1_done = (a == end);
      }

      if (door_state & DOOR_ACTION_2)
      {
	int a = MIN(x * door_2.step_offset, door_size);
	int p = (door_state & DOOR_OPEN_2 ? door_size - a : a);
	int i = p + door_skip;

	if (door_2.anim_mode & ANIM_STATIC_PANEL)
	{
	  BlitBitmap(bitmap_db_door, drawto,
		     DOOR_GFX_PAGEX1, DOOR_GFX_PAGEY2,
		     VXSIZE, VYSIZE, VX, VY);
	}
	else if (x <= VYSIZE)
	{
	  BlitBitmap(bitmap_db_door, drawto,
		     DOOR_GFX_PAGEX1, DOOR_GFX_PAGEY2 + p / 2,
		     VXSIZE, VYSIZE - p / 2, VX, VY);

	  ClearRectangle(drawto, VX, VY + VYSIZE - p / 2, VXSIZE, p / 2);
	}

	if (door_2.anim_mode & ANIM_HORIZONTAL && x <= VXSIZE)
	{
	  int src1_x = VXSIZE,		src1_y = DOOR_GFX_PAGEY2;
	  int dst1_x = VX + VXSIZE - i,	dst1_y = VY;
	  int src2_x = VXSIZE - i,	src2_y = DOOR_GFX_PAGEY2;
	  int dst2_x = VX,		dst2_y = VY;
	  int width = i, height = VYSIZE;

	  SetClipOrigin(bitmap, gc, dst1_x - src1_x, dst1_y - src1_y);
	  BlitBitmapMasked(bitmap, drawto, src1_x, src1_y, width, height,
			   dst1_x, dst1_y);

	  SetClipOrigin(bitmap, gc, dst2_x - src2_x, dst2_y - src2_y);
	  BlitBitmapMasked(bitmap, drawto, src2_x, src2_y, width, height,
			   dst2_x, dst2_y);
	}
	else if (door_2.anim_mode & ANIM_VERTICAL && x <= VYSIZE)
	{
	  int src1_x = VXSIZE,		src1_y = DOOR_GFX_PAGEY2;
	  int dst1_x = VX,		dst1_y = VY + VYSIZE - i;
	  int src2_x = 0,		src2_y = DOOR_GFX_PAGEY2 + VYSIZE - i;
	  int dst2_x = VX,		dst2_y = VY;
	  int width = VXSIZE, height = i;

	  SetClipOrigin(bitmap, gc, dst1_x - src1_x, dst1_y - src1_y);
	  BlitBitmapMasked(bitmap, drawto, src1_x, src1_y, width, height,
			   dst1_x, dst1_y);

	  SetClipOrigin(bitmap, gc, dst2_x - src2_x, dst2_y - src2_y);
	  BlitBitmapMasked(bitmap, drawto, src2_x, src2_y, width, height,
			   dst2_x, dst2_y);
	}
	else if (x <= VXSIZE)	/* ANIM_DEFAULT */
	{
	  int j = (door_2.anim_mode == ANIM_DEFAULT ? (VXSIZE - i) / 3 : 0);

	  SetClipOrigin(bitmap, gc, VX - i, (VY + j) - DOOR_GFX_PAGEY2);
	  BlitBitmapMasked(bitmap, drawto,
			   VXSIZE, DOOR_GFX_PAGEY2, i, VYSIZE / 2,
			   VX + VXSIZE - i, VY + j);
	  SetClipOrigin(bitmap, gc,
			VX - VXSIZE + i, VY - (DOOR_GFX_PAGEY2 + j));
	  BlitBitmapMasked(bitmap, drawto,
			   VXSIZE - i, DOOR_GFX_PAGEY2 + j, i, VYSIZE / 2 - j,
			   VX, VY);

	  BlitBitmapMasked(bitmap, drawto,
			   VXSIZE - i, DOOR_GFX_PAGEY2 + VYSIZE / 2,
			   i, VYSIZE / 2, VX, VY + VYSIZE / 2 - j);
	  SetClipOrigin(bitmap, gc, VX - i, (VY + j) - DOOR_GFX_PAGEY2);
	  BlitBitmapMasked(bitmap, drawto,
			   VXSIZE, DOOR_GFX_PAGEY2 + VYSIZE / 2,
			   i, VYSIZE / 2 - j,
			   VX + VXSIZE - i, VY + VYSIZE / 2 + j);
	}

	redraw_mask |= REDRAW_DOOR_2;
	door_2_done = (a == VXSIZE);
      }

      if (!(door_state & DOOR_NO_DELAY))
      {
	BackToFront();

	if (game_status == GAME_MODE_MAIN)
	  DoAnimation();

	WaitUntilDelayReached(&door_delay, door_delay_value);
      }
    }
  }

  if (door_state & DOOR_ACTION_1)
    door1 = door_state & DOOR_ACTION_1;
  if (door_state & DOOR_ACTION_2)
    door2 = door_state & DOOR_ACTION_2;

  return (door1 | door2);
}

void DrawSpecialEditorDoor()
{
  /* draw bigger toolbox window */
  BlitBitmap(graphic_info[IMG_GLOBAL_DOOR].bitmap, drawto,
	     DOOR_GFX_PAGEX7, 0, EXSIZE + 8, 8,
	     EX - 4, EY - 12);
  BlitBitmap(graphic_info[IMG_GLOBAL_BORDER].bitmap, drawto,
	     EX - 6, VY - 4, EXSIZE + 12, EYSIZE - VYSIZE + 4,
	     EX - 6, EY - 4);

  redraw_mask |= REDRAW_ALL;
}

void UndrawSpecialEditorDoor()
{
  /* draw normal tape recorder window */
  BlitBitmap(graphic_info[IMG_GLOBAL_BORDER].bitmap, drawto,
	     EX - 6, EY - 12, EXSIZE + 12, EYSIZE - VYSIZE + 12,
	     EX - 6, EY - 12);

  redraw_mask |= REDRAW_ALL;
}


/* ---------- new tool button stuff ---------------------------------------- */

/* graphic position values for tool buttons */
#define TOOL_BUTTON_YES_XPOS		2
#define TOOL_BUTTON_YES_YPOS		250
#define TOOL_BUTTON_YES_GFX_YPOS	0
#define TOOL_BUTTON_YES_XSIZE		46
#define TOOL_BUTTON_YES_YSIZE		28
#define TOOL_BUTTON_NO_XPOS		52
#define TOOL_BUTTON_NO_YPOS		TOOL_BUTTON_YES_YPOS
#define TOOL_BUTTON_NO_GFX_YPOS		TOOL_BUTTON_YES_GFX_YPOS
#define TOOL_BUTTON_NO_XSIZE		TOOL_BUTTON_YES_XSIZE
#define TOOL_BUTTON_NO_YSIZE		TOOL_BUTTON_YES_YSIZE
#define TOOL_BUTTON_CONFIRM_XPOS	TOOL_BUTTON_YES_XPOS
#define TOOL_BUTTON_CONFIRM_YPOS	TOOL_BUTTON_YES_YPOS
#define TOOL_BUTTON_CONFIRM_GFX_YPOS	30
#define TOOL_BUTTON_CONFIRM_XSIZE	96
#define TOOL_BUTTON_CONFIRM_YSIZE	TOOL_BUTTON_YES_YSIZE
#define TOOL_BUTTON_PLAYER_XSIZE	30
#define TOOL_BUTTON_PLAYER_YSIZE	30
#define TOOL_BUTTON_PLAYER_GFX_XPOS	5
#define TOOL_BUTTON_PLAYER_GFX_YPOS	185
#define TOOL_BUTTON_PLAYER_XPOS		(5 + TOOL_BUTTON_PLAYER_XSIZE / 2)
#define TOOL_BUTTON_PLAYER_YPOS		(215 - TOOL_BUTTON_PLAYER_YSIZE / 2)
#define TOOL_BUTTON_PLAYER1_XPOS	(TOOL_BUTTON_PLAYER_XPOS \
					 + 0 * TOOL_BUTTON_PLAYER_XSIZE)
#define TOOL_BUTTON_PLAYER2_XPOS	(TOOL_BUTTON_PLAYER_XPOS \
					 + 1 * TOOL_BUTTON_PLAYER_XSIZE)
#define TOOL_BUTTON_PLAYER3_XPOS	(TOOL_BUTTON_PLAYER_XPOS \
					 + 0 * TOOL_BUTTON_PLAYER_XSIZE)
#define TOOL_BUTTON_PLAYER4_XPOS	(TOOL_BUTTON_PLAYER_XPOS \
					 + 1 * TOOL_BUTTON_PLAYER_XSIZE)
#define TOOL_BUTTON_PLAYER1_YPOS	(TOOL_BUTTON_PLAYER_YPOS \
					 + 0 * TOOL_BUTTON_PLAYER_YSIZE)
#define TOOL_BUTTON_PLAYER2_YPOS	(TOOL_BUTTON_PLAYER_YPOS \
					 + 0 * TOOL_BUTTON_PLAYER_YSIZE)
#define TOOL_BUTTON_PLAYER3_YPOS	(TOOL_BUTTON_PLAYER_YPOS \
					 + 1 * TOOL_BUTTON_PLAYER_YSIZE)
#define TOOL_BUTTON_PLAYER4_YPOS	(TOOL_BUTTON_PLAYER_YPOS \
					 + 1 * TOOL_BUTTON_PLAYER_YSIZE)

static struct
{
  int xpos, ypos;
  int x, y;
  int width, height;
  int gadget_id;
  char *infotext;
} toolbutton_info[NUM_TOOL_BUTTONS] =
{
  {
    TOOL_BUTTON_YES_XPOS,	TOOL_BUTTON_YES_GFX_YPOS,
    TOOL_BUTTON_YES_XPOS,	TOOL_BUTTON_YES_YPOS,
    TOOL_BUTTON_YES_XSIZE,	TOOL_BUTTON_YES_YSIZE,
    TOOL_CTRL_ID_YES,
    "yes"
  },
  {
    TOOL_BUTTON_NO_XPOS,	TOOL_BUTTON_NO_GFX_YPOS,
    TOOL_BUTTON_NO_XPOS,	TOOL_BUTTON_NO_YPOS,
    TOOL_BUTTON_NO_XSIZE,	TOOL_BUTTON_NO_YSIZE,
    TOOL_CTRL_ID_NO,
    "no"
  },
  {
    TOOL_BUTTON_CONFIRM_XPOS,	TOOL_BUTTON_CONFIRM_GFX_YPOS,
    TOOL_BUTTON_CONFIRM_XPOS,	TOOL_BUTTON_CONFIRM_YPOS,
    TOOL_BUTTON_CONFIRM_XSIZE,	TOOL_BUTTON_CONFIRM_YSIZE,
    TOOL_CTRL_ID_CONFIRM,
    "confirm"
  },
  {
    TOOL_BUTTON_PLAYER_GFX_XPOS,TOOL_BUTTON_PLAYER_GFX_YPOS,
    TOOL_BUTTON_PLAYER1_XPOS,	TOOL_BUTTON_PLAYER1_YPOS,
    TOOL_BUTTON_PLAYER_XSIZE,	TOOL_BUTTON_PLAYER_YSIZE,
    TOOL_CTRL_ID_PLAYER_1,
    "player 1"
  },
  {
    TOOL_BUTTON_PLAYER_GFX_XPOS,TOOL_BUTTON_PLAYER_GFX_YPOS,
    TOOL_BUTTON_PLAYER2_XPOS,	TOOL_BUTTON_PLAYER2_YPOS,
    TOOL_BUTTON_PLAYER_XSIZE,	TOOL_BUTTON_PLAYER_YSIZE,
    TOOL_CTRL_ID_PLAYER_2,
    "player 2"
  },
  {
    TOOL_BUTTON_PLAYER_GFX_XPOS,TOOL_BUTTON_PLAYER_GFX_YPOS,
    TOOL_BUTTON_PLAYER3_XPOS,	TOOL_BUTTON_PLAYER3_YPOS,
    TOOL_BUTTON_PLAYER_XSIZE,	TOOL_BUTTON_PLAYER_YSIZE,
    TOOL_CTRL_ID_PLAYER_3,
    "player 3"
  },
  {
    TOOL_BUTTON_PLAYER_GFX_XPOS,TOOL_BUTTON_PLAYER_GFX_YPOS,
    TOOL_BUTTON_PLAYER4_XPOS,	TOOL_BUTTON_PLAYER4_YPOS,
    TOOL_BUTTON_PLAYER_XSIZE,	TOOL_BUTTON_PLAYER_YSIZE,
    TOOL_CTRL_ID_PLAYER_4,
    "player 4"
  }
};

void CreateToolButtons()
{
  int i;

  for (i = 0; i < NUM_TOOL_BUTTONS; i++)
  {
    Bitmap *gd_bitmap = graphic_info[IMG_GLOBAL_DOOR].bitmap;
    Bitmap *deco_bitmap = None;
    int deco_x = 0, deco_y = 0, deco_xpos = 0, deco_ypos = 0;
    struct GadgetInfo *gi;
    unsigned int event_mask;
    int gd_xoffset, gd_yoffset;
    int gd_x1, gd_x2, gd_y;
    int id = i;

    event_mask = GD_EVENT_RELEASED;

    gd_xoffset = toolbutton_info[i].xpos;
    gd_yoffset = toolbutton_info[i].ypos;
    gd_x1 = DOOR_GFX_PAGEX4 + gd_xoffset;
    gd_x2 = DOOR_GFX_PAGEX3 + gd_xoffset;
    gd_y = DOOR_GFX_PAGEY1 + gd_yoffset;

    if (id >= TOOL_CTRL_ID_PLAYER_1 && id <= TOOL_CTRL_ID_PLAYER_4)
    {
      int player_nr = id - TOOL_CTRL_ID_PLAYER_1;

      getMiniGraphicSource(PLAYER_NR_GFX(IMG_PLAYER_1, player_nr),
			   &deco_bitmap, &deco_x, &deco_y);
      deco_xpos = (toolbutton_info[i].width - MINI_TILEX) / 2;
      deco_ypos = (toolbutton_info[i].height - MINI_TILEY) / 2;
    }

    gi = CreateGadget(GDI_CUSTOM_ID, id,
		      GDI_INFO_TEXT, toolbutton_info[i].infotext,
		      GDI_X, DX + toolbutton_info[i].x,
		      GDI_Y, DY + toolbutton_info[i].y,
		      GDI_WIDTH, toolbutton_info[i].width,
		      GDI_HEIGHT, toolbutton_info[i].height,
		      GDI_TYPE, GD_TYPE_NORMAL_BUTTON,
		      GDI_STATE, GD_BUTTON_UNPRESSED,
		      GDI_DESIGN_UNPRESSED, gd_bitmap, gd_x1, gd_y,
		      GDI_DESIGN_PRESSED, gd_bitmap, gd_x2, gd_y,
		      GDI_DECORATION_DESIGN, deco_bitmap, deco_x, deco_y,
		      GDI_DECORATION_POSITION, deco_xpos, deco_ypos,
		      GDI_DECORATION_SIZE, MINI_TILEX, MINI_TILEY,
		      GDI_DECORATION_SHIFTING, 1, 1,
		      GDI_DIRECT_DRAW, FALSE,
		      GDI_EVENT_MASK, event_mask,
		      GDI_CALLBACK_ACTION, HandleToolButtons,
		      GDI_END);

    if (gi == NULL)
      Error(ERR_EXIT, "cannot create gadget");

    tool_gadget[id] = gi;
  }
}

void FreeToolButtons()
{
  int i;

  for (i = 0; i < NUM_TOOL_BUTTONS; i++)
    FreeGadget(tool_gadget[i]);
}

static void UnmapToolButtons()
{
  int i;

  for (i = 0; i < NUM_TOOL_BUTTONS; i++)
    UnmapGadget(tool_gadget[i]);
}

static void HandleToolButtons(struct GadgetInfo *gi)
{
  request_gadget_id = gi->custom_id;
}

static struct Mapping_EM_to_RND_object
{
  int element_em;
  boolean is_rnd_to_em_mapping;		/* unique mapping EM <-> RND */
  boolean is_backside;			/* backside of moving element */

  int element_rnd;
  int action;
  int direction;
}
em_object_mapping_list[] =
{
  {
    Xblank,				TRUE,	FALSE,
    EL_EMPTY,				-1, -1
  },
  {
    Yacid_splash_eB,			FALSE,	FALSE,
    EL_ACID_SPLASH_RIGHT,		-1, -1
  },
  {
    Yacid_splash_wB,			FALSE,	FALSE,
    EL_ACID_SPLASH_LEFT,		-1, -1
  },

#ifdef EM_ENGINE_BAD_ROLL
  {
    Xstone_force_e,			FALSE,	FALSE,
    EL_ROCK,				-1, MV_BIT_RIGHT
  },
  {
    Xstone_force_w,			FALSE,	FALSE,
    EL_ROCK,				-1, MV_BIT_LEFT
  },
  {
    Xnut_force_e,			FALSE,	FALSE,
    EL_NUT,				-1, MV_BIT_RIGHT
  },
  {
    Xnut_force_w,			FALSE,	FALSE,
    EL_NUT,				-1, MV_BIT_LEFT
  },
  {
    Xspring_force_e,			FALSE,	FALSE,
    EL_SPRING,				-1, MV_BIT_RIGHT
  },
  {
    Xspring_force_w,			FALSE,	FALSE,
    EL_SPRING,				-1, MV_BIT_LEFT
  },
  {
    Xemerald_force_e,			FALSE,	FALSE,
    EL_EMERALD,				-1, MV_BIT_RIGHT
  },
  {
    Xemerald_force_w,			FALSE,	FALSE,
    EL_EMERALD,				-1, MV_BIT_LEFT
  },
  {
    Xdiamond_force_e,			FALSE,	FALSE,
    EL_DIAMOND,				-1, MV_BIT_RIGHT
  },
  {
    Xdiamond_force_w,			FALSE,	FALSE,
    EL_DIAMOND,				-1, MV_BIT_LEFT
  },
  {
    Xbomb_force_e,			FALSE,	FALSE,
    EL_BOMB,				-1, MV_BIT_RIGHT
  },
  {
    Xbomb_force_w,			FALSE,	FALSE,
    EL_BOMB,				-1, MV_BIT_LEFT
  },
#endif	/* EM_ENGINE_BAD_ROLL */

  {
    Xstone,				TRUE,	FALSE,
    EL_ROCK,				-1, -1
  },
  {
    Xstone_pause,			FALSE,	FALSE,
    EL_ROCK,				-1, -1
  },
  {
    Xstone_fall,			FALSE,	FALSE,
    EL_ROCK,				-1, -1
  },
  {
    Ystone_s,				FALSE,	FALSE,
    EL_ROCK,				ACTION_FALLING, -1
  },
  {
    Ystone_sB,				FALSE,	TRUE,
    EL_ROCK,				ACTION_FALLING, -1
  },
  {
    Ystone_e,				FALSE,	FALSE,
    EL_ROCK,				ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Ystone_eB,				FALSE,	TRUE,
    EL_ROCK,				ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Ystone_w,				FALSE,	FALSE,
    EL_ROCK,				ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Ystone_wB,				FALSE,	TRUE,
    EL_ROCK,				ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Xnut,				TRUE,	FALSE,
    EL_NUT,				-1, -1
  },
  {
    Xnut_pause,				FALSE,	FALSE,
    EL_NUT,				-1, -1
  },
  {
    Xnut_fall,				FALSE,	FALSE,
    EL_NUT,				-1, -1
  },
  {
    Ynut_s,				FALSE,	FALSE,
    EL_NUT,				ACTION_FALLING, -1
  },
  {
    Ynut_sB,				FALSE,	TRUE,
    EL_NUT,				ACTION_FALLING, -1
  },
  {
    Ynut_e,				FALSE,	FALSE,
    EL_NUT,				ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Ynut_eB,				FALSE,	TRUE,
    EL_NUT,				ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Ynut_w,				FALSE,	FALSE,
    EL_NUT,				ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Ynut_wB,				FALSE,	TRUE,
    EL_NUT,				ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Xbug_n,				TRUE,	FALSE,
    EL_BUG_UP,				-1, -1
  },
  {
    Xbug_e,				TRUE,	FALSE,
    EL_BUG_RIGHT,			-1, -1
  },
  {
    Xbug_s,				TRUE,	FALSE,
    EL_BUG_DOWN,			-1, -1
  },
  {
    Xbug_w,				TRUE,	FALSE,
    EL_BUG_LEFT,			-1, -1
  },
  {
    Xbug_gon,				FALSE,	FALSE,
    EL_BUG_UP,				-1, -1
  },
  {
    Xbug_goe,				FALSE,	FALSE,
    EL_BUG_RIGHT,			-1, -1
  },
  {
    Xbug_gos,				FALSE,	FALSE,
    EL_BUG_DOWN,			-1, -1
  },
  {
    Xbug_gow,				FALSE,	FALSE,
    EL_BUG_LEFT,			-1, -1
  },
  {
    Ybug_n,				FALSE,	FALSE,
    EL_BUG,				ACTION_MOVING, MV_BIT_UP
  },
  {
    Ybug_nB,				FALSE,	TRUE,
    EL_BUG,				ACTION_MOVING, MV_BIT_UP
  },
  {
    Ybug_e,				FALSE,	FALSE,
    EL_BUG,				ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Ybug_eB,				FALSE,	TRUE,
    EL_BUG,				ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Ybug_s,				FALSE,	FALSE,
    EL_BUG,				ACTION_MOVING, MV_BIT_DOWN
  },
  {
    Ybug_sB,				FALSE,	TRUE,
    EL_BUG,				ACTION_MOVING, MV_BIT_DOWN
  },
  {
    Ybug_w,				FALSE,	FALSE,
    EL_BUG,				ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Ybug_wB,				FALSE,	TRUE,
    EL_BUG,				ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Ybug_w_n,				FALSE,	FALSE,
    EL_BUG,				ACTION_TURNING_FROM_LEFT, MV_BIT_UP
  },
  {
    Ybug_n_e,				FALSE,	FALSE,
    EL_BUG,				ACTION_TURNING_FROM_UP, MV_BIT_RIGHT
  },
  {
    Ybug_e_s,				FALSE,	FALSE,
    EL_BUG,				ACTION_TURNING_FROM_RIGHT, MV_BIT_DOWN
  },
  {
    Ybug_s_w,				FALSE,	FALSE,
    EL_BUG,				ACTION_TURNING_FROM_DOWN, MV_BIT_LEFT
  },
  {
    Ybug_e_n,				FALSE,	FALSE,
    EL_BUG,				ACTION_TURNING_FROM_RIGHT, MV_BIT_UP
  },
  {
    Ybug_s_e,				FALSE,	FALSE,
    EL_BUG,				ACTION_TURNING_FROM_DOWN, MV_BIT_RIGHT
  },
  {
    Ybug_w_s,				FALSE,	FALSE,
    EL_BUG,				ACTION_TURNING_FROM_LEFT, MV_BIT_DOWN
  },
  {
    Ybug_n_w,				FALSE,	FALSE,
    EL_BUG,				ACTION_TURNING_FROM_UP, MV_BIT_LEFT
  },
  {
    Ybug_stone,				FALSE,	FALSE,
    EL_BUG,				ACTION_SMASHED_BY_ROCK, -1
  },
  {
    Ybug_spring,			FALSE,	FALSE,
    EL_BUG,				ACTION_SMASHED_BY_SPRING, -1
  },
  {
    Xtank_n,				TRUE,	FALSE,
    EL_SPACESHIP_UP,			-1, -1
  },
  {
    Xtank_e,				TRUE,	FALSE,
    EL_SPACESHIP_RIGHT,			-1, -1
  },
  {
    Xtank_s,				TRUE,	FALSE,
    EL_SPACESHIP_DOWN,			-1, -1
  },
  {
    Xtank_w,				TRUE,	FALSE,
    EL_SPACESHIP_LEFT,			-1, -1
  },
  {
    Xtank_gon,				FALSE,	FALSE,
    EL_SPACESHIP_UP,			-1, -1
  },
  {
    Xtank_goe,				FALSE,	FALSE,
    EL_SPACESHIP_RIGHT,			-1, -1
  },
  {
    Xtank_gos,				FALSE,	FALSE,
    EL_SPACESHIP_DOWN,			-1, -1
  },
  {
    Xtank_gow,				FALSE,	FALSE,
    EL_SPACESHIP_LEFT,			-1, -1
  },
  {
    Ytank_n,				FALSE,	FALSE,
    EL_SPACESHIP,			ACTION_MOVING, MV_BIT_UP
  },
  {
    Ytank_nB,				FALSE,	TRUE,
    EL_SPACESHIP,			ACTION_MOVING, MV_BIT_UP
  },
  {
    Ytank_e,				FALSE,	FALSE,
    EL_SPACESHIP,			ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Ytank_eB,				FALSE,	TRUE,
    EL_SPACESHIP,			ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Ytank_s,				FALSE,	FALSE,
    EL_SPACESHIP,			ACTION_MOVING, MV_BIT_DOWN
  },
  {
    Ytank_sB,				FALSE,	TRUE,
    EL_SPACESHIP,			ACTION_MOVING, MV_BIT_DOWN
  },
  {
    Ytank_w,				FALSE,	FALSE,
    EL_SPACESHIP,			ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Ytank_wB,				FALSE,	TRUE,
    EL_SPACESHIP,			ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Ytank_w_n,				FALSE,	FALSE,
    EL_SPACESHIP,			ACTION_TURNING_FROM_LEFT, MV_BIT_UP
  },
  {
    Ytank_n_e,				FALSE,	FALSE,
    EL_SPACESHIP,			ACTION_TURNING_FROM_UP, MV_BIT_RIGHT
  },
  {
    Ytank_e_s,				FALSE,	FALSE,
    EL_SPACESHIP,			ACTION_TURNING_FROM_RIGHT, MV_BIT_DOWN
  },
  {
    Ytank_s_w,				FALSE,	FALSE,
    EL_SPACESHIP,			ACTION_TURNING_FROM_DOWN, MV_BIT_LEFT
  },
  {
    Ytank_e_n,				FALSE,	FALSE,
    EL_SPACESHIP,			ACTION_TURNING_FROM_RIGHT, MV_BIT_UP
  },
  {
    Ytank_s_e,				FALSE,	FALSE,
    EL_SPACESHIP,			ACTION_TURNING_FROM_DOWN, MV_BIT_RIGHT
  },
  {
    Ytank_w_s,				FALSE,	FALSE,
    EL_SPACESHIP,			ACTION_TURNING_FROM_LEFT, MV_BIT_DOWN
  },
  {
    Ytank_n_w,				FALSE,	FALSE,
    EL_SPACESHIP,			ACTION_TURNING_FROM_UP, MV_BIT_LEFT
  },
  {
    Ytank_stone,			FALSE,	FALSE,
    EL_SPACESHIP,			ACTION_SMASHED_BY_ROCK, -1
  },
  {
    Ytank_spring,			FALSE,	FALSE,
    EL_SPACESHIP,			ACTION_SMASHED_BY_SPRING, -1
  },
  {
    Xandroid,				TRUE,	FALSE,
    EL_EMC_ANDROID,			ACTION_ACTIVE, -1
  },
  {
    Xandroid_1_n,			FALSE,	FALSE,
    EL_EMC_ANDROID,			ACTION_ACTIVE, MV_BIT_UP
  },
  {
    Xandroid_2_n,			FALSE,	FALSE,
    EL_EMC_ANDROID,			ACTION_ACTIVE, MV_BIT_UP
  },
  {
    Xandroid_1_e,			FALSE,	FALSE,
    EL_EMC_ANDROID,			ACTION_ACTIVE, MV_BIT_RIGHT
  },
  {
    Xandroid_2_e,			FALSE,	FALSE,
    EL_EMC_ANDROID,			ACTION_ACTIVE, MV_BIT_RIGHT
  },
  {
    Xandroid_1_w,			FALSE,	FALSE,
    EL_EMC_ANDROID,			ACTION_ACTIVE, MV_BIT_LEFT
  },
  {
    Xandroid_2_w,			FALSE,	FALSE,
    EL_EMC_ANDROID,			ACTION_ACTIVE, MV_BIT_LEFT
  },
  {
    Xandroid_1_s,			FALSE,	FALSE,
    EL_EMC_ANDROID,			ACTION_ACTIVE, MV_BIT_DOWN
  },
  {
    Xandroid_2_s,			FALSE,	FALSE,
    EL_EMC_ANDROID,			ACTION_ACTIVE, MV_BIT_DOWN
  },
  {
    Yandroid_n,				FALSE,	FALSE,
    EL_EMC_ANDROID,			ACTION_MOVING, MV_BIT_UP
  },
  {
    Yandroid_nB,			FALSE,	TRUE,
    EL_EMC_ANDROID,			ACTION_MOVING, MV_BIT_UP
  },
  {
    Yandroid_ne,			FALSE,	FALSE,
    EL_EMC_ANDROID,			ACTION_GROWING, MV_BIT_UPRIGHT
  },
  {
    Yandroid_neB,			FALSE,	TRUE,
    EL_EMC_ANDROID,			ACTION_SHRINKING, MV_BIT_UPRIGHT
  },
  {
    Yandroid_e,				FALSE,	FALSE,
    EL_EMC_ANDROID,			ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Yandroid_eB,			FALSE,	TRUE,
    EL_EMC_ANDROID,			ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Yandroid_se,			FALSE,	FALSE,
    EL_EMC_ANDROID,			ACTION_GROWING, MV_BIT_DOWNRIGHT
  },
  {
    Yandroid_seB,			FALSE,	TRUE,
    EL_EMC_ANDROID,			ACTION_SHRINKING, MV_BIT_DOWNRIGHT
  },
  {
    Yandroid_s,				FALSE,	FALSE,
    EL_EMC_ANDROID,			ACTION_MOVING, MV_BIT_DOWN
  },
  {
    Yandroid_sB,			FALSE,	TRUE,
    EL_EMC_ANDROID,			ACTION_MOVING, MV_BIT_DOWN
  },
  {
    Yandroid_sw,			FALSE,	FALSE,
    EL_EMC_ANDROID,			ACTION_GROWING, MV_BIT_DOWNLEFT
  },
  {
    Yandroid_swB,			FALSE,	TRUE,
    EL_EMC_ANDROID,			ACTION_SHRINKING, MV_BIT_DOWNLEFT
  },
  {
    Yandroid_w,				FALSE,	FALSE,
    EL_EMC_ANDROID,			ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Yandroid_wB,			FALSE,	TRUE,
    EL_EMC_ANDROID,			ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Yandroid_nw,			FALSE,	FALSE,
    EL_EMC_ANDROID,			ACTION_GROWING, MV_BIT_UPLEFT
  },
  {
    Yandroid_nwB,			FALSE,	TRUE,
    EL_EMC_ANDROID,			ACTION_SHRINKING, MV_BIT_UPLEFT
  },
  {
    Xspring,				TRUE,	FALSE,
    EL_SPRING,				-1, -1
  },
  {
    Xspring_pause,			FALSE,	FALSE,
    EL_SPRING,				-1, -1
  },
  {
    Xspring_e,				FALSE,	FALSE,
    EL_SPRING,				-1, -1
  },
  {
    Xspring_w,				FALSE,	FALSE,
    EL_SPRING,				-1, -1
  },
  {
    Xspring_fall,			FALSE,	FALSE,
    EL_SPRING,				-1, -1
  },
  {
    Yspring_s,				FALSE,	FALSE,
    EL_SPRING,				ACTION_FALLING, -1
  },
  {
    Yspring_sB,				FALSE,	TRUE,
    EL_SPRING,				ACTION_FALLING, -1
  },
  {
    Yspring_e,				FALSE,	FALSE,
    EL_SPRING,				ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Yspring_eB,				FALSE,	TRUE,
    EL_SPRING,				ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Yspring_w,				FALSE,	FALSE,
    EL_SPRING,				ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Yspring_wB,				FALSE,	TRUE,
    EL_SPRING,				ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Yspring_kill_e,			FALSE,	FALSE,
    EL_SPRING,				ACTION_EATING, MV_BIT_RIGHT
  },
  {
    Yspring_kill_eB,			FALSE,	TRUE,
    EL_SPRING,				ACTION_EATING, MV_BIT_RIGHT
  },
  {
    Yspring_kill_w,			FALSE,	FALSE,
    EL_SPRING,				ACTION_EATING, MV_BIT_LEFT
  },
  {
    Yspring_kill_wB,			FALSE,	TRUE,
    EL_SPRING,				ACTION_EATING, MV_BIT_LEFT
  },
  {
    Xeater_n,				TRUE,	FALSE,
    EL_YAMYAM_UP,			-1, -1
  },
  {
    Xeater_e,				TRUE,	FALSE,
    EL_YAMYAM_RIGHT,			-1, -1
  },
  {
    Xeater_w,				TRUE,	FALSE,
    EL_YAMYAM_LEFT,			-1, -1
  },
  {
    Xeater_s,				TRUE,	FALSE,
    EL_YAMYAM_DOWN,			-1, -1
  },
  {
    Yeater_n,				FALSE,	FALSE,
    EL_YAMYAM,				ACTION_MOVING, MV_BIT_UP
  },
  {
    Yeater_nB,				FALSE,	TRUE,
    EL_YAMYAM,				ACTION_MOVING, MV_BIT_UP
  },
  {
    Yeater_e,				FALSE,	FALSE,
    EL_YAMYAM,				ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Yeater_eB,				FALSE,	TRUE,
    EL_YAMYAM,				ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Yeater_s,				FALSE,	FALSE,
    EL_YAMYAM,				ACTION_MOVING, MV_BIT_DOWN
  },
  {
    Yeater_sB,				FALSE,	TRUE,
    EL_YAMYAM,				ACTION_MOVING, MV_BIT_DOWN
  },
  {
    Yeater_w,				FALSE,	FALSE,
    EL_YAMYAM,				ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Yeater_wB,				FALSE,	TRUE,
    EL_YAMYAM,				ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Yeater_stone,			FALSE,	FALSE,
    EL_YAMYAM,				ACTION_SMASHED_BY_ROCK, -1
  },
  {
    Yeater_spring,			FALSE,	FALSE,
    EL_YAMYAM,				ACTION_SMASHED_BY_SPRING, -1
  },
  {
    Xalien,				TRUE,	FALSE,
    EL_ROBOT,				-1, -1
  },
  {
    Xalien_pause,			FALSE,	FALSE,
    EL_ROBOT,				-1, -1
  },
  {
    Yalien_n,				FALSE,	FALSE,
    EL_ROBOT,				ACTION_MOVING, MV_BIT_UP
  },
  {
    Yalien_nB,				FALSE,	TRUE,
    EL_ROBOT,				ACTION_MOVING, MV_BIT_UP
  },
  {
    Yalien_e,				FALSE,	FALSE,
    EL_ROBOT,				ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Yalien_eB,				FALSE,	TRUE,
    EL_ROBOT,				ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Yalien_s,				FALSE,	FALSE,
    EL_ROBOT,				ACTION_MOVING, MV_BIT_DOWN
  },
  {
    Yalien_sB,				FALSE,	TRUE,
    EL_ROBOT,				ACTION_MOVING, MV_BIT_DOWN
  },
  {
    Yalien_w,				FALSE,	FALSE,
    EL_ROBOT,				ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Yalien_wB,				FALSE,	TRUE,
    EL_ROBOT,				ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Yalien_stone,			FALSE,	FALSE,
    EL_ROBOT,				ACTION_SMASHED_BY_ROCK, -1
  },
  {
    Yalien_spring,			FALSE,	FALSE,
    EL_ROBOT,				ACTION_SMASHED_BY_SPRING, -1
  },
  {
    Xemerald,				TRUE,	FALSE,
    EL_EMERALD,				-1, -1
  },
  {
    Xemerald_pause,			FALSE,	FALSE,
    EL_EMERALD,				-1, -1
  },
  {
    Xemerald_fall,			FALSE,	FALSE,
    EL_EMERALD,				-1, -1
  },
  {
    Xemerald_shine,			FALSE,	FALSE,
    EL_EMERALD,				ACTION_TWINKLING, -1
  },
  {
    Yemerald_s,				FALSE,	FALSE,
    EL_EMERALD,				ACTION_FALLING, -1
  },
  {
    Yemerald_sB,			FALSE,	TRUE,
    EL_EMERALD,				ACTION_FALLING, -1
  },
  {
    Yemerald_e,				FALSE,	FALSE,
    EL_EMERALD,				ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Yemerald_eB,			FALSE,	TRUE,
    EL_EMERALD,				ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Yemerald_w,				FALSE,	FALSE,
    EL_EMERALD,				ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Yemerald_wB,			FALSE,	TRUE,
    EL_EMERALD,				ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Yemerald_eat,			FALSE,	FALSE,
    EL_EMERALD,				ACTION_COLLECTING, -1
  },
  {
    Yemerald_stone,			FALSE,	FALSE,
    EL_NUT,				ACTION_BREAKING, -1
  },
  {
    Xdiamond,				TRUE,	FALSE,
    EL_DIAMOND,				-1, -1
  },
  {
    Xdiamond_pause,			FALSE,	FALSE,
    EL_DIAMOND,				-1, -1
  },
  {
    Xdiamond_fall,			FALSE,	FALSE,
    EL_DIAMOND,				-1, -1
  },
  {
    Xdiamond_shine,			FALSE,	FALSE,
    EL_DIAMOND,				ACTION_TWINKLING, -1
  },
  {
    Ydiamond_s,				FALSE,	FALSE,
    EL_DIAMOND,				ACTION_FALLING, -1
  },
  {
    Ydiamond_sB,			FALSE,	TRUE,
    EL_DIAMOND,				ACTION_FALLING, -1
  },
  {
    Ydiamond_e,				FALSE,	FALSE,
    EL_DIAMOND,				ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Ydiamond_eB,			FALSE,	TRUE,
    EL_DIAMOND,				ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Ydiamond_w,				FALSE,	FALSE,
    EL_DIAMOND,				ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Ydiamond_wB,			FALSE,	TRUE,
    EL_DIAMOND,				ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Ydiamond_eat,			FALSE,	FALSE,
    EL_DIAMOND,				ACTION_COLLECTING, -1
  },
  {
    Ydiamond_stone,			FALSE,	FALSE,
    EL_DIAMOND,				ACTION_SMASHED_BY_ROCK, -1
  },
  {
    Xdrip_fall,				TRUE,	FALSE,
    EL_AMOEBA_DROP,			-1, -1
  },
  {
    Xdrip_stretch,			FALSE,	FALSE,
    EL_AMOEBA_DROP,			ACTION_FALLING, -1
  },
  {
    Xdrip_stretchB,			FALSE,	TRUE,
    EL_AMOEBA_DROP,			ACTION_FALLING, -1
  },
  {
    Xdrip_eat,				FALSE,	FALSE,
    EL_AMOEBA_DROP,			ACTION_GROWING, -1
  },
  {
    Ydrip_s1,				FALSE,	FALSE,
    EL_AMOEBA_DROP,			ACTION_FALLING, -1
  },
  {
    Ydrip_s1B,				FALSE,	TRUE,
    EL_AMOEBA_DROP,			ACTION_FALLING, -1
  },
  {
    Ydrip_s2,				FALSE,	FALSE,
    EL_AMOEBA_DROP,			ACTION_FALLING, -1
  },
  {
    Ydrip_s2B,				FALSE,	TRUE,
    EL_AMOEBA_DROP,			ACTION_FALLING, -1
  },
  {
    Xbomb,				TRUE,	FALSE,
    EL_BOMB,				-1, -1
  },
  {
    Xbomb_pause,			FALSE,	FALSE,
    EL_BOMB,				-1, -1
  },
  {
    Xbomb_fall,				FALSE,	FALSE,
    EL_BOMB,				-1, -1
  },
  {
    Ybomb_s,				FALSE,	FALSE,
    EL_BOMB,				ACTION_FALLING, -1
  },
  {
    Ybomb_sB,				FALSE,	TRUE,
    EL_BOMB,				ACTION_FALLING, -1
  },
  {
    Ybomb_e,				FALSE,	FALSE,
    EL_BOMB,				ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Ybomb_eB,				FALSE,	TRUE,
    EL_BOMB,				ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Ybomb_w,				FALSE,	FALSE,
    EL_BOMB,				ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Ybomb_wB,				FALSE,	TRUE,
    EL_BOMB,				ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Ybomb_eat,				FALSE,	FALSE,
    EL_BOMB,				ACTION_ACTIVATING, -1
  },
  {
    Xballoon,				TRUE,	FALSE,
    EL_BALLOON,				-1, -1
  },
  {
    Yballoon_n,				FALSE,	FALSE,
    EL_BALLOON,				ACTION_MOVING, MV_BIT_UP
  },
  {
    Yballoon_nB,			FALSE,	TRUE,
    EL_BALLOON,				ACTION_MOVING, MV_BIT_UP
  },
  {
    Yballoon_e,				FALSE,	FALSE,
    EL_BALLOON,				ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Yballoon_eB,			FALSE,	TRUE,
    EL_BALLOON,				ACTION_MOVING, MV_BIT_RIGHT
  },
  {
    Yballoon_s,				FALSE,	FALSE,
    EL_BALLOON,				ACTION_MOVING, MV_BIT_DOWN
  },
  {
    Yballoon_sB,			FALSE,	TRUE,
    EL_BALLOON,				ACTION_MOVING, MV_BIT_DOWN
  },
  {
    Yballoon_w,				FALSE,	FALSE,
    EL_BALLOON,				ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Yballoon_wB,			FALSE,	TRUE,
    EL_BALLOON,				ACTION_MOVING, MV_BIT_LEFT
  },
  {
    Xgrass,				TRUE,	FALSE,
    EL_EMC_GRASS,			-1, -1
  },
  {
    Ygrass_nB,				FALSE,	FALSE,
    EL_EMC_GRASS,			ACTION_DIGGING, MV_BIT_UP
  },
  {
    Ygrass_eB,				FALSE,	FALSE,
    EL_EMC_GRASS,			ACTION_DIGGING, MV_BIT_RIGHT
  },
  {
    Ygrass_sB,				FALSE,	FALSE,
    EL_EMC_GRASS,			ACTION_DIGGING, MV_BIT_DOWN
  },
  {
    Ygrass_wB,				FALSE,	FALSE,
    EL_EMC_GRASS,			ACTION_DIGGING, MV_BIT_LEFT
  },
  {
    Xdirt,				TRUE,	FALSE,
    EL_SAND,				-1, -1
  },
  {
    Ydirt_nB,				FALSE,	FALSE,
    EL_SAND,				ACTION_DIGGING, MV_BIT_UP
  },
  {
    Ydirt_eB,				FALSE,	FALSE,
    EL_SAND,				ACTION_DIGGING, MV_BIT_RIGHT
  },
  {
    Ydirt_sB,				FALSE,	FALSE,
    EL_SAND,				ACTION_DIGGING, MV_BIT_DOWN
  },
  {
    Ydirt_wB,				FALSE,	FALSE,
    EL_SAND,				ACTION_DIGGING, MV_BIT_LEFT
  },
  {
    Xacid_ne,				TRUE,	FALSE,
    EL_ACID_POOL_TOPRIGHT,		-1, -1
  },
  {
    Xacid_se,				TRUE,	FALSE,
    EL_ACID_POOL_BOTTOMRIGHT,		-1, -1
  },
  {
    Xacid_s,				TRUE,	FALSE,
    EL_ACID_POOL_BOTTOM,		-1, -1
  },
  {
    Xacid_sw,				TRUE,	FALSE,
    EL_ACID_POOL_BOTTOMLEFT,		-1, -1
  },
  {
    Xacid_nw,				TRUE,	FALSE,
    EL_ACID_POOL_TOPLEFT,		-1, -1
  },
  {
    Xacid_1,				TRUE,	FALSE,
    EL_ACID,				-1, -1
  },
  {
    Xacid_2,				FALSE,	FALSE,
    EL_ACID,				-1, -1
  },
  {
    Xacid_3,				FALSE,	FALSE,
    EL_ACID,				-1, -1
  },
  {
    Xacid_4,				FALSE,	FALSE,
    EL_ACID,				-1, -1
  },
  {
    Xacid_5,				FALSE,	FALSE,
    EL_ACID,				-1, -1
  },
  {
    Xacid_6,				FALSE,	FALSE,
    EL_ACID,				-1, -1
  },
  {
    Xacid_7,				FALSE,	FALSE,
    EL_ACID,				-1, -1
  },
  {
    Xacid_8,				FALSE,	FALSE,
    EL_ACID,				-1, -1
  },
  {
    Xball_1,				TRUE,	FALSE,
    EL_EMC_MAGIC_BALL,			-1, -1
  },
  {
    Xball_1B,				FALSE,	FALSE,
    EL_EMC_MAGIC_BALL,			ACTION_ACTIVE, -1
  },
  {
    Xball_2,				FALSE,	FALSE,
    EL_EMC_MAGIC_BALL,			ACTION_ACTIVE, -1
  },
  {
    Xball_2B,				FALSE,	FALSE,
    EL_EMC_MAGIC_BALL,			ACTION_ACTIVE, -1
  },
  {
    Yball_eat,				FALSE,	FALSE,
    EL_EMC_MAGIC_BALL,			ACTION_DROPPING, -1
  },
  {
    Ykey_1_eat,				FALSE,	FALSE,
    EL_EM_KEY_1,			ACTION_COLLECTING, -1
  },
  {
    Ykey_2_eat,				FALSE,	FALSE,
    EL_EM_KEY_2,			ACTION_COLLECTING, -1
  },
  {
    Ykey_3_eat,				FALSE,	FALSE,
    EL_EM_KEY_3,			ACTION_COLLECTING, -1
  },
  {
    Ykey_4_eat,				FALSE,	FALSE,
    EL_EM_KEY_4,			ACTION_COLLECTING, -1
  },
  {
    Ykey_5_eat,				FALSE,	FALSE,
    EL_EMC_KEY_5,			ACTION_COLLECTING, -1
  },
  {
    Ykey_6_eat,				FALSE,	FALSE,
    EL_EMC_KEY_6,			ACTION_COLLECTING, -1
  },
  {
    Ykey_7_eat,				FALSE,	FALSE,
    EL_EMC_KEY_7,			ACTION_COLLECTING, -1
  },
  {
    Ykey_8_eat,				FALSE,	FALSE,
    EL_EMC_KEY_8,			ACTION_COLLECTING, -1
  },
  {
    Ylenses_eat,			FALSE,	FALSE,
    EL_EMC_LENSES,			ACTION_COLLECTING, -1
  },
  {
    Ymagnify_eat,			FALSE,	FALSE,
    EL_EMC_MAGNIFIER,			ACTION_COLLECTING, -1
  },
  {
    Ygrass_eat,				FALSE,	FALSE,
    EL_EMC_GRASS,			ACTION_SNAPPING, -1
  },
  {
    Ydirt_eat,				FALSE,	FALSE,
    EL_SAND,				ACTION_SNAPPING, -1
  },
  {
    Xgrow_ns,				TRUE,	FALSE,
    EL_EXPANDABLE_WALL_VERTICAL,	-1, -1
  },
  {
    Ygrow_ns_eat,			FALSE,	FALSE,
    EL_EXPANDABLE_WALL_VERTICAL,	ACTION_GROWING, -1
  },
  {
    Xgrow_ew,				TRUE,	FALSE,
    EL_EXPANDABLE_WALL_HORIZONTAL,	-1, -1
  },
  {
    Ygrow_ew_eat,			FALSE,	FALSE,
    EL_EXPANDABLE_WALL_HORIZONTAL,	ACTION_GROWING, -1
  },
  {
    Xwonderwall,			TRUE,	FALSE,
    EL_MAGIC_WALL,			-1, -1
  },
  {
    XwonderwallB,			FALSE,	FALSE,
    EL_MAGIC_WALL,			ACTION_ACTIVE, -1
  },
  {
    Xamoeba_1,				TRUE,	FALSE,
    EL_AMOEBA_DRY,			ACTION_OTHER, -1
  },
  {
    Xamoeba_2,				FALSE,	FALSE,
    EL_AMOEBA_DRY,			ACTION_OTHER, -1
  },
  {
    Xamoeba_3,				FALSE,	FALSE,
    EL_AMOEBA_DRY,			ACTION_OTHER, -1
  },
  {
    Xamoeba_4,				FALSE,	FALSE,
    EL_AMOEBA_DRY,			ACTION_OTHER, -1
  },
  {
    Xamoeba_5,				TRUE,	FALSE,
    EL_AMOEBA_WET,			ACTION_OTHER, -1
  },
  {
    Xamoeba_6,				FALSE,	FALSE,
    EL_AMOEBA_WET,			ACTION_OTHER, -1
  },
  {
    Xamoeba_7,				FALSE,	FALSE,
    EL_AMOEBA_WET,			ACTION_OTHER, -1
  },
  {
    Xamoeba_8,				FALSE,	FALSE,
    EL_AMOEBA_WET,			ACTION_OTHER, -1
  },
  {
    Xdoor_1,				TRUE,	FALSE,
    EL_EM_GATE_1,			-1, -1
  },
  {
    Xdoor_2,				TRUE,	FALSE,
    EL_EM_GATE_2,			-1, -1
  },
  {
    Xdoor_3,				TRUE,	FALSE,
    EL_EM_GATE_3,			-1, -1
  },
  {
    Xdoor_4,				TRUE,	FALSE,
    EL_EM_GATE_4,			-1, -1
  },
  {
    Xdoor_5,				TRUE,	FALSE,
    EL_EMC_GATE_5,			-1, -1
  },
  {
    Xdoor_6,				TRUE,	FALSE,
    EL_EMC_GATE_6,			-1, -1
  },
  {
    Xdoor_7,				TRUE,	FALSE,
    EL_EMC_GATE_7,			-1, -1
  },
  {
    Xdoor_8,				TRUE,	FALSE,
    EL_EMC_GATE_8,			-1, -1
  },
  {
    Xkey_1,				TRUE,	FALSE,
    EL_EM_KEY_1,			-1, -1
  },
  {
    Xkey_2,				TRUE,	FALSE,
    EL_EM_KEY_2,			-1, -1
  },
  {
    Xkey_3,				TRUE,	FALSE,
    EL_EM_KEY_3,			-1, -1
  },
  {
    Xkey_4,				TRUE,	FALSE,
    EL_EM_KEY_4,			-1, -1
  },
  {
    Xkey_5,				TRUE,	FALSE,
    EL_EMC_KEY_5,			-1, -1
  },
  {
    Xkey_6,				TRUE,	FALSE,
    EL_EMC_KEY_6,			-1, -1
  },
  {
    Xkey_7,				TRUE,	FALSE,
    EL_EMC_KEY_7,			-1, -1
  },
  {
    Xkey_8,				TRUE,	FALSE,
    EL_EMC_KEY_8,			-1, -1
  },
  {
    Xwind_n,				TRUE,	FALSE,
    EL_BALLOON_SWITCH_UP,		-1, -1
  },
  {
    Xwind_e,				TRUE,	FALSE,
    EL_BALLOON_SWITCH_RIGHT,		-1, -1
  },
  {
    Xwind_s,				TRUE,	FALSE,
    EL_BALLOON_SWITCH_DOWN,		-1, -1
  },
  {
    Xwind_w,				TRUE,	FALSE,
    EL_BALLOON_SWITCH_LEFT,		-1, -1
  },
  {
    Xwind_nesw,				TRUE,	FALSE,
    EL_BALLOON_SWITCH_ANY,		-1, -1
  },
  {
    Xwind_stop,				TRUE,	FALSE,
    EL_BALLOON_SWITCH_NONE,		-1, -1
  },
  {
    Xexit,				TRUE,	FALSE,
    EL_EM_EXIT_CLOSED,			-1, -1
  },
  {
    Xexit_1,				TRUE,	FALSE,
    EL_EM_EXIT_OPEN,			-1, -1
  },
  {
    Xexit_2,				FALSE,	FALSE,
    EL_EM_EXIT_OPEN,			-1, -1
  },
  {
    Xexit_3,				FALSE,	FALSE,
    EL_EM_EXIT_OPEN,			-1, -1
  },
  {
    Xdynamite,				TRUE,	FALSE,
    EL_EM_DYNAMITE,			-1, -1
  },
  {
    Ydynamite_eat,			FALSE,	FALSE,
    EL_EM_DYNAMITE,			ACTION_COLLECTING, -1
  },
  {
    Xdynamite_1,			TRUE,	FALSE,
    EL_EM_DYNAMITE_ACTIVE,		-1, -1
  },
  {
    Xdynamite_2,			FALSE,	FALSE,
    EL_EM_DYNAMITE_ACTIVE,		-1, -1
  },
  {
    Xdynamite_3,			FALSE,	FALSE,
    EL_EM_DYNAMITE_ACTIVE,		-1, -1
  },
  {
    Xdynamite_4,			FALSE,	FALSE,
    EL_EM_DYNAMITE_ACTIVE,		-1, -1
  },
  {
    Xbumper,				TRUE,	FALSE,
    EL_EMC_SPRING_BUMPER,		-1, -1
  },
  {
    XbumperB,				FALSE,	FALSE,
    EL_EMC_SPRING_BUMPER,		ACTION_ACTIVE, -1
  },
  {
    Xwheel,				TRUE,	FALSE,
    EL_ROBOT_WHEEL,			-1, -1
  },
  {
    XwheelB,				FALSE,	FALSE,
    EL_ROBOT_WHEEL,			ACTION_ACTIVE, -1
  },
  {
    Xswitch,				TRUE,	FALSE,
    EL_EMC_MAGIC_BALL_SWITCH,		-1, -1
  },
  {
    XswitchB,				FALSE,	FALSE,
    EL_EMC_MAGIC_BALL_SWITCH,		ACTION_ACTIVE, -1
  },
  {
    Xsand,				TRUE,	FALSE,
    EL_QUICKSAND_EMPTY,			-1, -1
  },
  {
    Xsand_stone,			TRUE,	FALSE,
    EL_QUICKSAND_FULL,			-1, -1
  },
  {
    Xsand_stonein_1,			FALSE,	TRUE,
    EL_ROCK,				ACTION_FILLING, -1
  },
  {
    Xsand_stonein_2,			FALSE,	TRUE,
    EL_ROCK,				ACTION_FILLING, -1
  },
  {
    Xsand_stonein_3,			FALSE,	TRUE,
    EL_ROCK,				ACTION_FILLING, -1
  },
  {
    Xsand_stonein_4,			FALSE,	TRUE,
    EL_ROCK,				ACTION_FILLING, -1
  },
#if 1
  {
    Xsand_stonesand_1,			FALSE,	FALSE,
    EL_QUICKSAND_EMPTYING,		-1, -1
  },
  {
    Xsand_stonesand_2,			FALSE,	FALSE,
    EL_QUICKSAND_EMPTYING,		-1, -1
  },
  {
    Xsand_stonesand_3,			FALSE,	FALSE,
    EL_QUICKSAND_EMPTYING,		-1, -1
  },
  {
    Xsand_stonesand_4,			FALSE,	FALSE,
    EL_QUICKSAND_EMPTYING,		-1, -1
  },
  {
    Xsand_stonesand_quickout_1,		FALSE,	FALSE,
    EL_QUICKSAND_EMPTYING,		-1, -1
  },
  {
    Xsand_stonesand_quickout_2,		FALSE,	FALSE,
    EL_QUICKSAND_EMPTYING,		-1, -1
  },
#else
  {
    Xsand_stonesand_1,			FALSE,	FALSE,
    EL_QUICKSAND_FULL,			-1, -1
  },
  {
    Xsand_stonesand_2,			FALSE,	FALSE,
    EL_QUICKSAND_FULL,			-1, -1
  },
  {
    Xsand_stonesand_3,			FALSE,	FALSE,
    EL_QUICKSAND_FULL,			-1, -1
  },
  {
    Xsand_stonesand_4,			FALSE,	FALSE,
    EL_QUICKSAND_FULL,			-1, -1
  },
#endif
  {
    Xsand_stoneout_1,			FALSE,	FALSE,
    EL_ROCK,				ACTION_EMPTYING, -1
  },
  {
    Xsand_stoneout_2,			FALSE,	FALSE,
    EL_ROCK,				ACTION_EMPTYING, -1
  },
#if 1
  {
    Xsand_sandstone_1,			FALSE,	FALSE,
    EL_QUICKSAND_FILLING,		-1, -1
  },
  {
    Xsand_sandstone_2,			FALSE,	FALSE,
    EL_QUICKSAND_FILLING,		-1, -1
  },
  {
    Xsand_sandstone_3,			FALSE,	FALSE,
    EL_QUICKSAND_FILLING,		-1, -1
  },
  {
    Xsand_sandstone_4,			FALSE,	FALSE,
    EL_QUICKSAND_FILLING,		-1, -1
  },
#else
  {
    Xsand_sandstone_1,			FALSE,	FALSE,
    EL_QUICKSAND_FULL,			-1, -1
  },
  {
    Xsand_sandstone_2,			FALSE,	FALSE,
    EL_QUICKSAND_FULL,			-1, -1
  },
  {
    Xsand_sandstone_3,			FALSE,	FALSE,
    EL_QUICKSAND_FULL,			-1, -1
  },
  {
    Xsand_sandstone_4,			FALSE,	FALSE,
    EL_QUICKSAND_FULL,			-1, -1
  },
#endif
  {
    Xplant,				TRUE,	FALSE,
    EL_EMC_PLANT,			-1, -1
  },
  {
    Yplant,				FALSE,	FALSE,
    EL_EMC_PLANT,			-1, -1
  },
  {
    Xlenses,				TRUE,	FALSE,
    EL_EMC_LENSES,			-1, -1
  },
  {
    Xmagnify,				TRUE,	FALSE,
    EL_EMC_MAGNIFIER,			-1, -1
  },
  {
    Xdripper,				TRUE,	FALSE,
    EL_EMC_DRIPPER,			-1, -1
  },
  {
    XdripperB,				FALSE,	FALSE,
    EL_EMC_DRIPPER,			ACTION_ACTIVE, -1
  },
  {
    Xfake_blank,			TRUE,	FALSE,
    EL_INVISIBLE_WALL,			-1, -1
  },
  {
    Xfake_blankB,			FALSE,	FALSE,
    EL_INVISIBLE_WALL,			ACTION_ACTIVE, -1
  },
  {
    Xfake_grass,			TRUE,	FALSE,
    EL_EMC_FAKE_GRASS,			-1, -1
  },
  {
    Xfake_grassB,			FALSE,	FALSE,
    EL_EMC_FAKE_GRASS,			ACTION_ACTIVE, -1
  },
  {
    Xfake_door_1,			TRUE,	FALSE,
    EL_EM_GATE_1_GRAY,			-1, -1
  },
  {
    Xfake_door_2,			TRUE,	FALSE,
    EL_EM_GATE_2_GRAY,			-1, -1
  },
  {
    Xfake_door_3,			TRUE,	FALSE,
    EL_EM_GATE_3_GRAY,			-1, -1
  },
  {
    Xfake_door_4,			TRUE,	FALSE,
    EL_EM_GATE_4_GRAY,			-1, -1
  },
  {
    Xfake_door_5,			TRUE,	FALSE,
    EL_EMC_GATE_5_GRAY,			-1, -1
  },
  {
    Xfake_door_6,			TRUE,	FALSE,
    EL_EMC_GATE_6_GRAY,			-1, -1
  },
  {
    Xfake_door_7,			TRUE,	FALSE,
    EL_EMC_GATE_7_GRAY,			-1, -1
  },
  {
    Xfake_door_8,			TRUE,	FALSE,
    EL_EMC_GATE_8_GRAY,			-1, -1
  },
  {
    Xfake_acid_1,			TRUE,	FALSE,
    EL_EMC_FAKE_ACID,			-1, -1
  },
  {
    Xfake_acid_2,			FALSE,	FALSE,
    EL_EMC_FAKE_ACID,			-1, -1
  },
  {
    Xfake_acid_3,			FALSE,	FALSE,
    EL_EMC_FAKE_ACID,			-1, -1
  },
  {
    Xfake_acid_4,			FALSE,	FALSE,
    EL_EMC_FAKE_ACID,			-1, -1
  },
  {
    Xfake_acid_5,			FALSE,	FALSE,
    EL_EMC_FAKE_ACID,			-1, -1
  },
  {
    Xfake_acid_6,			FALSE,	FALSE,
    EL_EMC_FAKE_ACID,			-1, -1
  },
  {
    Xfake_acid_7,			FALSE,	FALSE,
    EL_EMC_FAKE_ACID,			-1, -1
  },
  {
    Xfake_acid_8,			FALSE,	FALSE,
    EL_EMC_FAKE_ACID,			-1, -1
  },
  {
    Xsteel_1,				TRUE,	FALSE,
    EL_STEELWALL,			-1, -1
  },
  {
    Xsteel_2,				TRUE,	FALSE,
    EL_EMC_STEELWALL_2,			-1, -1
  },
  {
    Xsteel_3,				TRUE,	FALSE,
    EL_EMC_STEELWALL_3,			-1, -1
  },
  {
    Xsteel_4,				TRUE,	FALSE,
    EL_EMC_STEELWALL_4,			-1, -1
  },
  {
    Xwall_1,				TRUE,	FALSE,
    EL_WALL,				-1, -1
  },
  {
    Xwall_2,				TRUE,	FALSE,
    EL_EMC_WALL_14,			-1, -1
  },
  {
    Xwall_3,				TRUE,	FALSE,
    EL_EMC_WALL_15,			-1, -1
  },
  {
    Xwall_4,				TRUE,	FALSE,
    EL_EMC_WALL_16,			-1, -1
  },
  {
    Xround_wall_1,			TRUE,	FALSE,
    EL_WALL_SLIPPERY,			-1, -1
  },
  {
    Xround_wall_2,			TRUE,	FALSE,
    EL_EMC_WALL_SLIPPERY_2,		-1, -1
  },
  {
    Xround_wall_3,			TRUE,	FALSE,
    EL_EMC_WALL_SLIPPERY_3,		-1, -1
  },
  {
    Xround_wall_4,			TRUE,	FALSE,
    EL_EMC_WALL_SLIPPERY_4,		-1, -1
  },
  {
    Xdecor_1,				TRUE,	FALSE,
    EL_EMC_WALL_8,			-1, -1
  },
  {
    Xdecor_2,				TRUE,	FALSE,
    EL_EMC_WALL_6,			-1, -1
  },
  {
    Xdecor_3,				TRUE,	FALSE,
    EL_EMC_WALL_4,			-1, -1
  },
  {
    Xdecor_4,				TRUE,	FALSE,
    EL_EMC_WALL_7,			-1, -1
  },
  {
    Xdecor_5,				TRUE,	FALSE,
    EL_EMC_WALL_5,			-1, -1
  },
  {
    Xdecor_6,				TRUE,	FALSE,
    EL_EMC_WALL_9,			-1, -1
  },
  {
    Xdecor_7,				TRUE,	FALSE,
    EL_EMC_WALL_10,			-1, -1
  },
  {
    Xdecor_8,				TRUE,	FALSE,
    EL_EMC_WALL_1,			-1, -1
  },
  {
    Xdecor_9,				TRUE,	FALSE,
    EL_EMC_WALL_2,			-1, -1
  },
  {
    Xdecor_10,				TRUE,	FALSE,
    EL_EMC_WALL_3,			-1, -1
  },
  {
    Xdecor_11,				TRUE,	FALSE,
    EL_EMC_WALL_11,			-1, -1
  },
  {
    Xdecor_12,				TRUE,	FALSE,
    EL_EMC_WALL_12,			-1, -1
  },
  {
    Xalpha_0,				TRUE,	FALSE,
    EL_CHAR('0'),			-1, -1
  },
  {
    Xalpha_1,				TRUE,	FALSE,
    EL_CHAR('1'),			-1, -1
  },
  {
    Xalpha_2,				TRUE,	FALSE,
    EL_CHAR('2'),			-1, -1
  },
  {
    Xalpha_3,				TRUE,	FALSE,
    EL_CHAR('3'),			-1, -1
  },
  {
    Xalpha_4,				TRUE,	FALSE,
    EL_CHAR('4'),			-1, -1
  },
  {
    Xalpha_5,				TRUE,	FALSE,
    EL_CHAR('5'),			-1, -1
  },
  {
    Xalpha_6,				TRUE,	FALSE,
    EL_CHAR('6'),			-1, -1
  },
  {
    Xalpha_7,				TRUE,	FALSE,
    EL_CHAR('7'),			-1, -1
  },
  {
    Xalpha_8,				TRUE,	FALSE,
    EL_CHAR('8'),			-1, -1
  },
  {
    Xalpha_9,				TRUE,	FALSE,
    EL_CHAR('9'),			-1, -1
  },
  {
    Xalpha_excla,			TRUE,	FALSE,
    EL_CHAR('!'),			-1, -1
  },
  {
    Xalpha_quote,			TRUE,	FALSE,
    EL_CHAR('"'),			-1, -1
  },
  {
    Xalpha_comma,			TRUE,	FALSE,
    EL_CHAR(','),			-1, -1
  },
  {
    Xalpha_minus,			TRUE,	FALSE,
    EL_CHAR('-'),			-1, -1
  },
  {
    Xalpha_perio,			TRUE,	FALSE,
    EL_CHAR('.'),			-1, -1
  },
  {
    Xalpha_colon,			TRUE,	FALSE,
    EL_CHAR(':'),			-1, -1
  },
  {
    Xalpha_quest,			TRUE,	FALSE,
    EL_CHAR('?'),			-1, -1
  },
  {
    Xalpha_a,				TRUE,	FALSE,
    EL_CHAR('A'),			-1, -1
  },
  {
    Xalpha_b,				TRUE,	FALSE,
    EL_CHAR('B'),			-1, -1
  },
  {
    Xalpha_c,				TRUE,	FALSE,
    EL_CHAR('C'),			-1, -1
  },
  {
    Xalpha_d,				TRUE,	FALSE,
    EL_CHAR('D'),			-1, -1
  },
  {
    Xalpha_e,				TRUE,	FALSE,
    EL_CHAR('E'),			-1, -1
  },
  {
    Xalpha_f,				TRUE,	FALSE,
    EL_CHAR('F'),			-1, -1
  },
  {
    Xalpha_g,				TRUE,	FALSE,
    EL_CHAR('G'),			-1, -1
  },
  {
    Xalpha_h,				TRUE,	FALSE,
    EL_CHAR('H'),			-1, -1
  },
  {
    Xalpha_i,				TRUE,	FALSE,
    EL_CHAR('I'),			-1, -1
  },
  {
    Xalpha_j,				TRUE,	FALSE,
    EL_CHAR('J'),			-1, -1
  },
  {
    Xalpha_k,				TRUE,	FALSE,
    EL_CHAR('K'),			-1, -1
  },
  {
    Xalpha_l,				TRUE,	FALSE,
    EL_CHAR('L'),			-1, -1
  },
  {
    Xalpha_m,				TRUE,	FALSE,
    EL_CHAR('M'),			-1, -1
  },
  {
    Xalpha_n,				TRUE,	FALSE,
    EL_CHAR('N'),			-1, -1
  },
  {
    Xalpha_o,				TRUE,	FALSE,
    EL_CHAR('O'),			-1, -1
  },
  {
    Xalpha_p,				TRUE,	FALSE,
    EL_CHAR('P'),			-1, -1
  },
  {
    Xalpha_q,				TRUE,	FALSE,
    EL_CHAR('Q'),			-1, -1
  },
  {
    Xalpha_r,				TRUE,	FALSE,
    EL_CHAR('R'),			-1, -1
  },
  {
    Xalpha_s,				TRUE,	FALSE,
    EL_CHAR('S'),			-1, -1
  },
  {
    Xalpha_t,				TRUE,	FALSE,
    EL_CHAR('T'),			-1, -1
  },
  {
    Xalpha_u,				TRUE,	FALSE,
    EL_CHAR('U'),			-1, -1
  },
  {
    Xalpha_v,				TRUE,	FALSE,
    EL_CHAR('V'),			-1, -1
  },
  {
    Xalpha_w,				TRUE,	FALSE,
    EL_CHAR('W'),			-1, -1
  },
  {
    Xalpha_x,				TRUE,	FALSE,
    EL_CHAR('X'),			-1, -1
  },
  {
    Xalpha_y,				TRUE,	FALSE,
    EL_CHAR('Y'),			-1, -1
  },
  {
    Xalpha_z,				TRUE,	FALSE,
    EL_CHAR('Z'),			-1, -1
  },
  {
    Xalpha_arrow_e,			TRUE,	FALSE,
    EL_CHAR('>'),			-1, -1
  },
  {
    Xalpha_arrow_w,			TRUE,	FALSE,
    EL_CHAR('<'),			-1, -1
  },
  {
    Xalpha_copyr,			TRUE,	FALSE,
    EL_CHAR('�'),			-1, -1
  },

  {
    Xboom_bug,				FALSE,	FALSE,
    EL_BUG,				ACTION_EXPLODING, -1
  },
  {
    Xboom_bomb,				FALSE,	FALSE,
    EL_BOMB,				ACTION_EXPLODING, -1
  },
  {
    Xboom_android,			FALSE,	FALSE,
    EL_EMC_ANDROID,			ACTION_OTHER, -1
  },
  {
    Xboom_1,				FALSE,	FALSE,
    EL_DEFAULT,				ACTION_EXPLODING, -1
  },
  {
    Xboom_2,				FALSE,	FALSE,
    EL_DEFAULT,				ACTION_EXPLODING, -1
  },
  {
    Znormal,				FALSE,	FALSE,
    EL_EMPTY,				-1, -1
  },
  {
    Zdynamite,				FALSE,	FALSE,
    EL_EMPTY,				-1, -1
  },
  {
    Zplayer,				FALSE,	FALSE,
    EL_EMPTY,				-1, -1
  },
  {
    ZBORDER,				FALSE,	FALSE,
    EL_EMPTY,				-1, -1
  },

  {
    -1,					FALSE,	FALSE,
    -1,					-1, -1
  }
};

static struct Mapping_EM_to_RND_player
{
  int action_em;
  int player_nr;

  int element_rnd;
  int action;
  int direction;
}
em_player_mapping_list[] =
{
  {
    SPR_walk + 0,			0,
    EL_PLAYER_1,			ACTION_MOVING, MV_BIT_UP,
  },
  {
    SPR_walk + 1,			0,
    EL_PLAYER_1,			ACTION_MOVING, MV_BIT_RIGHT,
  },
  {
    SPR_walk + 2,			0,
    EL_PLAYER_1,			ACTION_MOVING, MV_BIT_DOWN,
  },
  {
    SPR_walk + 3,			0,
    EL_PLAYER_1,			ACTION_MOVING, MV_BIT_LEFT,
  },
  {
    SPR_push + 0,			0,
    EL_PLAYER_1,			ACTION_PUSHING, MV_BIT_UP,
  },
  {
    SPR_push + 1,			0,
    EL_PLAYER_1,			ACTION_PUSHING, MV_BIT_RIGHT,
  },
  {
    SPR_push + 2,			0,
    EL_PLAYER_1,			ACTION_PUSHING, MV_BIT_DOWN,
  },
  {
    SPR_push + 3,			0,
    EL_PLAYER_1,			ACTION_PUSHING, MV_BIT_LEFT,
  },
  {
    SPR_spray + 0,			0,
    EL_PLAYER_1,			ACTION_SNAPPING, MV_BIT_UP,
  },
  {
    SPR_spray + 1,			0,
    EL_PLAYER_1,			ACTION_SNAPPING, MV_BIT_RIGHT,
  },
  {
    SPR_spray + 2,			0,
    EL_PLAYER_1,			ACTION_SNAPPING, MV_BIT_DOWN,
  },
  {
    SPR_spray + 3,			0,
    EL_PLAYER_1,			ACTION_SNAPPING, MV_BIT_LEFT,
  },
  {
    SPR_walk + 0,			1,
    EL_PLAYER_2,			ACTION_MOVING, MV_BIT_UP,
  },
  {
    SPR_walk + 1,			1,
    EL_PLAYER_2,			ACTION_MOVING, MV_BIT_RIGHT,
  },
  {
    SPR_walk + 2,			1,
    EL_PLAYER_2,			ACTION_MOVING, MV_BIT_DOWN,
  },
  {
    SPR_walk + 3,			1,
    EL_PLAYER_2,			ACTION_MOVING, MV_BIT_LEFT,
  },
  {
    SPR_push + 0,			1,
    EL_PLAYER_2,			ACTION_PUSHING, MV_BIT_UP,
  },
  {
    SPR_push + 1,			1,
    EL_PLAYER_2,			ACTION_PUSHING, MV_BIT_RIGHT,
  },
  {
    SPR_push + 2,			1,
    EL_PLAYER_2,			ACTION_PUSHING, MV_BIT_DOWN,
  },
  {
    SPR_push + 3,			1,
    EL_PLAYER_2,			ACTION_PUSHING, MV_BIT_LEFT,
  },
  {
    SPR_spray + 0,			1,
    EL_PLAYER_2,			ACTION_SNAPPING, MV_BIT_UP,
  },
  {
    SPR_spray + 1,			1,
    EL_PLAYER_2,			ACTION_SNAPPING, MV_BIT_RIGHT,
  },
  {
    SPR_spray + 2,			1,
    EL_PLAYER_2,			ACTION_SNAPPING, MV_BIT_DOWN,
  },
  {
    SPR_spray + 3,			1,
    EL_PLAYER_2,			ACTION_SNAPPING, MV_BIT_LEFT,
  },
  {
    SPR_still,				0,
    EL_PLAYER_1,			ACTION_DEFAULT, -1,
  },
  {
    SPR_still,				1,
    EL_PLAYER_2,			ACTION_DEFAULT, -1,
  },
  {
    SPR_walk + 0,			2,
    EL_PLAYER_3,			ACTION_MOVING, MV_BIT_UP,
  },
  {
    SPR_walk + 1,			2,
    EL_PLAYER_3,			ACTION_MOVING, MV_BIT_RIGHT,
  },
  {
    SPR_walk + 2,			2,
    EL_PLAYER_3,			ACTION_MOVING, MV_BIT_DOWN,
  },
  {
    SPR_walk + 3,			2,
    EL_PLAYER_3,			ACTION_MOVING, MV_BIT_LEFT,
  },
  {
    SPR_push + 0,			2,
    EL_PLAYER_3,			ACTION_PUSHING, MV_BIT_UP,
  },
  {
    SPR_push + 1,			2,
    EL_PLAYER_3,			ACTION_PUSHING, MV_BIT_RIGHT,
  },
  {
    SPR_push + 2,			2,
    EL_PLAYER_3,			ACTION_PUSHING, MV_BIT_DOWN,
  },
  {
    SPR_push + 3,			2,
    EL_PLAYER_3,			ACTION_PUSHING, MV_BIT_LEFT,
  },
  {
    SPR_spray + 0,			2,
    EL_PLAYER_3,			ACTION_SNAPPING, MV_BIT_UP,
  },
  {
    SPR_spray + 1,			2,
    EL_PLAYER_3,			ACTION_SNAPPING, MV_BIT_RIGHT,
  },
  {
    SPR_spray + 2,			2,
    EL_PLAYER_3,			ACTION_SNAPPING, MV_BIT_DOWN,
  },
  {
    SPR_spray + 3,			2,
    EL_PLAYER_3,			ACTION_SNAPPING, MV_BIT_LEFT,
  },
  {
    SPR_walk + 0,			3,
    EL_PLAYER_4,			ACTION_MOVING, MV_BIT_UP,
  },
  {
    SPR_walk + 1,			3,
    EL_PLAYER_4,			ACTION_MOVING, MV_BIT_RIGHT,
  },
  {
    SPR_walk + 2,			3,
    EL_PLAYER_4,			ACTION_MOVING, MV_BIT_DOWN,
  },
  {
    SPR_walk + 3,			3,
    EL_PLAYER_4,			ACTION_MOVING, MV_BIT_LEFT,
  },
  {
    SPR_push + 0,			3,
    EL_PLAYER_4,			ACTION_PUSHING, MV_BIT_UP,
  },
  {
    SPR_push + 1,			3,
    EL_PLAYER_4,			ACTION_PUSHING, MV_BIT_RIGHT,
  },
  {
    SPR_push + 2,			3,
    EL_PLAYER_4,			ACTION_PUSHING, MV_BIT_DOWN,
  },
  {
    SPR_push + 3,			3,
    EL_PLAYER_4,			ACTION_PUSHING, MV_BIT_LEFT,
  },
  {
    SPR_spray + 0,			3,
    EL_PLAYER_4,			ACTION_SNAPPING, MV_BIT_UP,
  },
  {
    SPR_spray + 1,			3,
    EL_PLAYER_4,			ACTION_SNAPPING, MV_BIT_RIGHT,
  },
  {
    SPR_spray + 2,			3,
    EL_PLAYER_4,			ACTION_SNAPPING, MV_BIT_DOWN,
  },
  {
    SPR_spray + 3,			3,
    EL_PLAYER_4,			ACTION_SNAPPING, MV_BIT_LEFT,
  },
  {
    SPR_still,				2,
    EL_PLAYER_3,			ACTION_DEFAULT, -1,
  },
  {
    SPR_still,				3,
    EL_PLAYER_4,			ACTION_DEFAULT, -1,
  },

  {
    -1,					-1,
    -1,					-1, -1
  }
};

int map_element_RND_to_EM(int element_rnd)
{
  static unsigned short mapping_RND_to_EM[NUM_FILE_ELEMENTS];
  static boolean mapping_initialized = FALSE;

  if (!mapping_initialized)
  {
    int i;

    /* return "Xalpha_quest" for all undefined elements in mapping array */
    for (i = 0; i < NUM_FILE_ELEMENTS; i++)
      mapping_RND_to_EM[i] = Xalpha_quest;

    for (i = 0; em_object_mapping_list[i].element_em != -1; i++)
      if (em_object_mapping_list[i].is_rnd_to_em_mapping)
	mapping_RND_to_EM[em_object_mapping_list[i].element_rnd] =
	  em_object_mapping_list[i].element_em;

    mapping_initialized = TRUE;
  }

  if (element_rnd >= 0 && element_rnd < NUM_FILE_ELEMENTS)
    return mapping_RND_to_EM[element_rnd];

  Error(ERR_WARN, "invalid RND level element %d", element_rnd);

  return EL_UNKNOWN;
}

int map_element_EM_to_RND(int element_em)
{
  static unsigned short mapping_EM_to_RND[TILE_MAX];
  static boolean mapping_initialized = FALSE;

  if (!mapping_initialized)
  {
    int i;

    /* return "EL_UNKNOWN" for all undefined elements in mapping array */
    for (i = 0; i < TILE_MAX; i++)
      mapping_EM_to_RND[i] = EL_UNKNOWN;

    for (i = 0; em_object_mapping_list[i].element_em != -1; i++)
      mapping_EM_to_RND[em_object_mapping_list[i].element_em] =
	em_object_mapping_list[i].element_rnd;

    mapping_initialized = TRUE;
  }

  if (element_em >= 0 && element_em < TILE_MAX)
    return mapping_EM_to_RND[element_em];

  Error(ERR_WARN, "invalid EM level element %d", element_em);

  return EL_UNKNOWN;
}

void map_android_clone_elements_RND_to_EM(struct LevelInfo *level)
{
  struct LevelInfo_EM *level_em = level->native_em_level;
  struct LEVEL *lev = level_em->lev;
  int i, j;

  for (i = 0; i < TILE_MAX; i++)
    lev->android_array[i] = Xblank;

  for (i = 0; i < level->num_android_clone_elements; i++)
  {
    int element_rnd = level->android_clone_element[i];
    int element_em = map_element_RND_to_EM(element_rnd);

    for (j = 0; em_object_mapping_list[j].element_em != -1; j++)
      if (em_object_mapping_list[j].element_rnd == element_rnd)
	lev->android_array[em_object_mapping_list[j].element_em] = element_em;
  }
}

void map_android_clone_elements_EM_to_RND(struct LevelInfo *level)
{
  struct LevelInfo_EM *level_em = level->native_em_level;
  struct LEVEL *lev = level_em->lev;
  int i, j;

  level->num_android_clone_elements = 0;

  for (i = 0; i < TILE_MAX; i++)
  {
    int element_em = lev->android_array[i];
    int element_rnd;
    boolean element_found = FALSE;

    if (element_em == Xblank)
      continue;

    element_rnd = map_element_EM_to_RND(element_em);

    for (j = 0; j < level->num_android_clone_elements; j++)
      if (level->android_clone_element[j] == element_rnd)
	element_found = TRUE;

    if (!element_found)
    {
      level->android_clone_element[level->num_android_clone_elements++] =
	element_rnd;

      if (level->num_android_clone_elements == MAX_ANDROID_ELEMENTS)
	break;
    }
  }

  if (level->num_android_clone_elements == 0)
  {
    level->num_android_clone_elements = 1;
    level->android_clone_element[0] = EL_EMPTY;
  }
}

int map_direction_RND_to_EM(int direction)
{
  return (direction == MV_UP    ? 0 :
	  direction == MV_RIGHT ? 1 :
	  direction == MV_DOWN  ? 2 :
	  direction == MV_LEFT  ? 3 :
	  -1);
}

int map_direction_EM_to_RND(int direction)
{
  return (direction == 0 ? MV_UP    :
	  direction == 1 ? MV_RIGHT :
	  direction == 2 ? MV_DOWN  :
	  direction == 3 ? MV_LEFT  :
	  MV_NONE);
}

int map_element_RND_to_SP(int element_rnd)
{
  int element_sp = 0x20;	/* map unknown elements to yellow "hardware" */

  if (element_rnd >= EL_SP_START &&
      element_rnd <= EL_SP_END)
    element_sp = element_rnd - EL_SP_START;
  else if (element_rnd == EL_EMPTY_SPACE)
    element_sp = 0x00;
  else if (element_rnd == EL_INVISIBLE_WALL)
    element_sp = 0x28;

  return element_sp;
}

int map_element_SP_to_RND(int element_sp)
{
  int element_rnd = EL_UNKNOWN;

  if (element_sp >= 0x00 &&
      element_sp <= 0x27)
    element_rnd = EL_SP_START + element_sp;
  else if (element_sp == 0x28)
    element_rnd = EL_INVISIBLE_WALL;

  return element_rnd;
}

int map_action_SP_to_RND(int action_sp)
{
  switch (action_sp)
  {
    case actActive:		return ACTION_ACTIVE;
    case actImpact:		return ACTION_IMPACT;
    case actExploding:		return ACTION_EXPLODING;
    case actDigging:		return ACTION_DIGGING;
    case actSnapping:		return ACTION_SNAPPING;
    case actCollecting:		return ACTION_COLLECTING;
    case actPassing:		return ACTION_PASSING;
    case actPushing:		return ACTION_PUSHING;
    case actDropping:		return ACTION_DROPPING;

    default:			return ACTION_DEFAULT;
  }
}

int get_next_element(int element)
{
  switch (element)
  {
    case EL_QUICKSAND_FILLING:		return EL_QUICKSAND_FULL;
    case EL_QUICKSAND_EMPTYING:		return EL_QUICKSAND_EMPTY;
    case EL_QUICKSAND_FAST_FILLING:	return EL_QUICKSAND_FAST_FULL;
    case EL_QUICKSAND_FAST_EMPTYING:	return EL_QUICKSAND_FAST_EMPTY;
    case EL_MAGIC_WALL_FILLING:		return EL_MAGIC_WALL_FULL;
    case EL_MAGIC_WALL_EMPTYING:	return EL_MAGIC_WALL_ACTIVE;
    case EL_BD_MAGIC_WALL_FILLING:	return EL_BD_MAGIC_WALL_FULL;
    case EL_BD_MAGIC_WALL_EMPTYING:	return EL_BD_MAGIC_WALL_ACTIVE;
    case EL_DC_MAGIC_WALL_FILLING:	return EL_DC_MAGIC_WALL_FULL;
    case EL_DC_MAGIC_WALL_EMPTYING:	return EL_DC_MAGIC_WALL_ACTIVE;
    case EL_AMOEBA_DROPPING:		return EL_AMOEBA_WET;

    default:				return element;
  }
}

#if 0
int el_act_dir2img(int element, int action, int direction)
{
  element = GFX_ELEMENT(element);

  if (direction == MV_NONE)
    return element_info[element].graphic[action];

  direction = MV_DIR_TO_BIT(direction);

  return element_info[element].direction_graphic[action][direction];
}
#else
int el_act_dir2img(int element, int action, int direction)
{
  element = GFX_ELEMENT(element);
  direction = MV_DIR_TO_BIT(direction);	/* default: MV_NONE => MV_DOWN */

  /* direction_graphic[][] == graphic[] for undefined direction graphics */
  return element_info[element].direction_graphic[action][direction];
}
#endif

#if 0
static int el_act_dir2crm(int element, int action, int direction)
{
  element = GFX_ELEMENT(element);

  if (direction == MV_NONE)
    return element_info[element].crumbled[action];

  direction = MV_DIR_TO_BIT(direction);

  return element_info[element].direction_crumbled[action][direction];
}
#else
static int el_act_dir2crm(int element, int action, int direction)
{
  element = GFX_ELEMENT(element);
  direction = MV_DIR_TO_BIT(direction);	/* default: MV_NONE => MV_DOWN */

  /* direction_graphic[][] == graphic[] for undefined direction graphics */
  return element_info[element].direction_crumbled[action][direction];
}
#endif

int el_act2img(int element, int action)
{
  element = GFX_ELEMENT(element);

  return element_info[element].graphic[action];
}

int el_act2crm(int element, int action)
{
  element = GFX_ELEMENT(element);

  return element_info[element].crumbled[action];
}

int el_dir2img(int element, int direction)
{
  element = GFX_ELEMENT(element);

  return el_act_dir2img(element, ACTION_DEFAULT, direction);
}

int el2baseimg(int element)
{
  return element_info[element].graphic[ACTION_DEFAULT];
}

int el2img(int element)
{
  element = GFX_ELEMENT(element);

  return element_info[element].graphic[ACTION_DEFAULT];
}

int el2edimg(int element)
{
  element = GFX_ELEMENT(element);

  return element_info[element].special_graphic[GFX_SPECIAL_ARG_EDITOR];
}

int el2preimg(int element)
{
  element = GFX_ELEMENT(element);

  return element_info[element].special_graphic[GFX_SPECIAL_ARG_PREVIEW];
}

int el2panelimg(int element)
{
  element = GFX_ELEMENT(element);

  return element_info[element].special_graphic[GFX_SPECIAL_ARG_PANEL];
}

int font2baseimg(int font_nr)
{
  return font_info[font_nr].special_graphic[GFX_SPECIAL_ARG_DEFAULT];
}

int getBeltNrFromBeltElement(int element)
{
  return (element < EL_CONVEYOR_BELT_2_LEFT ? 0 :
	  element < EL_CONVEYOR_BELT_3_LEFT ? 1 :
	  element < EL_CONVEYOR_BELT_4_LEFT ? 2 : 3);
}

int getBeltNrFromBeltActiveElement(int element)
{
  return (element < EL_CONVEYOR_BELT_2_LEFT_ACTIVE ? 0 :
	  element < EL_CONVEYOR_BELT_3_LEFT_ACTIVE ? 1 :
	  element < EL_CONVEYOR_BELT_4_LEFT_ACTIVE ? 2 : 3);
}

int getBeltNrFromBeltSwitchElement(int element)
{
  return (element < EL_CONVEYOR_BELT_2_SWITCH_LEFT ? 0 :
	  element < EL_CONVEYOR_BELT_3_SWITCH_LEFT ? 1 :
	  element < EL_CONVEYOR_BELT_4_SWITCH_LEFT ? 2 : 3);
}

int getBeltDirNrFromBeltElement(int element)
{
  static int belt_base_element[4] =
  {
    EL_CONVEYOR_BELT_1_LEFT,
    EL_CONVEYOR_BELT_2_LEFT,
    EL_CONVEYOR_BELT_3_LEFT,
    EL_CONVEYOR_BELT_4_LEFT
  };

  int belt_nr = getBeltNrFromBeltElement(element);
  int belt_dir_nr = element - belt_base_element[belt_nr];

  return (belt_dir_nr % 3);
}

int getBeltDirNrFromBeltSwitchElement(int element)
{
  static int belt_base_element[4] =
  {
    EL_CONVEYOR_BELT_1_SWITCH_LEFT,
    EL_CONVEYOR_BELT_2_SWITCH_LEFT,
    EL_CONVEYOR_BELT_3_SWITCH_LEFT,
    EL_CONVEYOR_BELT_4_SWITCH_LEFT
  };

  int belt_nr = getBeltNrFromBeltSwitchElement(element);
  int belt_dir_nr = element - belt_base_element[belt_nr];

  return (belt_dir_nr % 3);
}

int getBeltDirFromBeltElement(int element)
{
  static int belt_move_dir[3] =
  {
    MV_LEFT,
    MV_NONE,
    MV_RIGHT
  };

  int belt_dir_nr = getBeltDirNrFromBeltElement(element);

  return belt_move_dir[belt_dir_nr];
}

int getBeltDirFromBeltSwitchElement(int element)
{
  static int belt_move_dir[3] =
  {
    MV_LEFT,
    MV_NONE,
    MV_RIGHT
  };

  int belt_dir_nr = getBeltDirNrFromBeltSwitchElement(element);

  return belt_move_dir[belt_dir_nr];
}

int getBeltElementFromBeltNrAndBeltDirNr(int belt_nr, int belt_dir_nr)
{
  static int belt_base_element[4] =
  {
    EL_CONVEYOR_BELT_1_LEFT,
    EL_CONVEYOR_BELT_2_LEFT,
    EL_CONVEYOR_BELT_3_LEFT,
    EL_CONVEYOR_BELT_4_LEFT
  };

  return belt_base_element[belt_nr] + belt_dir_nr;
}

int getBeltElementFromBeltNrAndBeltDir(int belt_nr, int belt_dir)
{
  int belt_dir_nr = (belt_dir == MV_LEFT ? 0 : belt_dir == MV_RIGHT ? 2 : 1);

  return getBeltElementFromBeltNrAndBeltDirNr(belt_nr, belt_dir_nr);
}

int getBeltSwitchElementFromBeltNrAndBeltDirNr(int belt_nr, int belt_dir_nr)
{
  static int belt_base_element[4] =
  {
    EL_CONVEYOR_BELT_1_SWITCH_LEFT,
    EL_CONVEYOR_BELT_2_SWITCH_LEFT,
    EL_CONVEYOR_BELT_3_SWITCH_LEFT,
    EL_CONVEYOR_BELT_4_SWITCH_LEFT
  };

  return belt_base_element[belt_nr] + belt_dir_nr;
}

int getBeltSwitchElementFromBeltNrAndBeltDir(int belt_nr, int belt_dir)
{
  int belt_dir_nr = (belt_dir == MV_LEFT ? 0 : belt_dir == MV_RIGHT ? 2 : 1);

  return getBeltSwitchElementFromBeltNrAndBeltDirNr(belt_nr, belt_dir_nr);
}

int getNumActivePlayers_EM()
{
  int num_players = 0;
  int i;

  if (!tape.playing)
    return -1;

  for (i = 0; i < MAX_PLAYERS; i++)
    if (tape.player_participates[i])
      num_players++;

  return num_players;
}

int getGameFrameDelay_EM(int native_em_game_frame_delay)
{
  int game_frame_delay_value;

  game_frame_delay_value =
    (tape.playing && tape.fast_forward ? FfwdFrameDelay :
     GameFrameDelay == GAME_FRAME_DELAY ? native_em_game_frame_delay :
     GameFrameDelay);

  if (tape.playing && tape.warp_forward && !tape.pausing)
    game_frame_delay_value = 0;

  return game_frame_delay_value;
}

unsigned int InitRND(int seed)
{
  if (level.game_engine_type == GAME_ENGINE_TYPE_EM)
    return InitEngineRandom_EM(seed);
  else if (level.game_engine_type == GAME_ENGINE_TYPE_SP)
    return InitEngineRandom_SP(seed);
  else
    return InitEngineRandom_RND(seed);
}

#if 1
static struct Mapping_EM_to_RND_object object_mapping[TILE_MAX];
static struct Mapping_EM_to_RND_player player_mapping[MAX_PLAYERS][SPR_MAX];
#endif

inline static int get_effective_element_EM(int tile, int frame_em)
{
  int element             = object_mapping[tile].element_rnd;
  int action              = object_mapping[tile].action;
  boolean is_backside     = object_mapping[tile].is_backside;
  boolean action_removing = (action == ACTION_DIGGING ||
			     action == ACTION_SNAPPING ||
			     action == ACTION_COLLECTING);

  if (frame_em < 7)
  {
    switch (tile)
    {
      case Yacid_splash_eB:
      case Yacid_splash_wB:
	return (frame_em > 5 ? EL_EMPTY : element);

#if 0
	/* !!! FIX !!! */
      case Ydiamond_stone:
	//  if (!game.use_native_emc_graphics_engine)
	return EL_ROCK;
#endif

      default:
	return element;
    }
  }
  else	/* frame_em == 7 */
  {
    switch (tile)
    {
      case Yacid_splash_eB:
      case Yacid_splash_wB:
	return EL_EMPTY;

      case Yemerald_stone:
	return EL_EMERALD;

      case Ydiamond_stone:
	return EL_ROCK;

      case Xdrip_stretch:
      case Xdrip_stretchB:
      case Ydrip_s1:
      case Ydrip_s1B:
      case Xball_1B:
      case Xball_2:
      case Xball_2B:
      case Yball_eat:
      case Ykey_1_eat:
      case Ykey_2_eat:
      case Ykey_3_eat:
      case Ykey_4_eat:
      case Ykey_5_eat:
      case Ykey_6_eat:
      case Ykey_7_eat:
      case Ykey_8_eat:
      case Ylenses_eat:
      case Ymagnify_eat:
      case Ygrass_eat:
      case Ydirt_eat:
      case Xsand_stonein_1:
      case Xsand_stonein_2:
      case Xsand_stonein_3:
      case Xsand_stonein_4:
	return element;

      default:
	return (is_backside || action_removing ? EL_EMPTY : element);
    }
  }
}

inline static boolean check_linear_animation_EM(int tile)
{
  switch (tile)
  {
    case Xsand_stonesand_1:
    case Xsand_stonesand_quickout_1:
    case Xsand_sandstone_1:
    case Xsand_stonein_1:
    case Xsand_stoneout_1:
    case Xboom_1:
    case Xdynamite_1:
    case Ybug_w_n:
    case Ybug_n_e:
    case Ybug_e_s:
    case Ybug_s_w:
    case Ybug_e_n:
    case Ybug_s_e:
    case Ybug_w_s:
    case Ybug_n_w:
    case Ytank_w_n:
    case Ytank_n_e:
    case Ytank_e_s:
    case Ytank_s_w:
    case Ytank_e_n:
    case Ytank_s_e:
    case Ytank_w_s:
    case Ytank_n_w:
#if 1
    case Yacid_splash_eB:
    case Yacid_splash_wB:
    case Yemerald_stone:
#endif
      return TRUE;
  }

  return FALSE;
}

inline static void set_crumbled_graphics_EM(struct GraphicInfo_EM *g_em,
					    boolean has_crumbled_graphics,
					    int crumbled, int sync_frame)
{
  /* if element can be crumbled, but certain action graphics are just empty
     space (like instantly snapping sand to empty space in 1 frame), do not
     treat these empty space graphics as crumbled graphics in EMC engine */
  if (crumbled == IMG_EMPTY_SPACE)
    has_crumbled_graphics = FALSE;

  if (has_crumbled_graphics)
  {
    struct GraphicInfo *g_crumbled = &graphic_info[crumbled];
    int frame_crumbled = getAnimationFrame(g_crumbled->anim_frames,
					   g_crumbled->anim_delay,
					   g_crumbled->anim_mode,
					   g_crumbled->anim_start_frame,
					   sync_frame);

    getGraphicSource(crumbled, frame_crumbled, &g_em->crumbled_bitmap,
		     &g_em->crumbled_src_x, &g_em->crumbled_src_y);

    g_em->crumbled_border_size = graphic_info[crumbled].border_size;

    g_em->has_crumbled_graphics = TRUE;
  }
  else
  {
    g_em->crumbled_bitmap = NULL;
    g_em->crumbled_src_x = 0;
    g_em->crumbled_src_y = 0;
    g_em->crumbled_border_size = 0;

    g_em->has_crumbled_graphics = FALSE;
  }
}

void ResetGfxAnimation_EM(int x, int y, int tile)
{
  GfxFrame[x][y] = 0;
}

void SetGfxAnimation_EM(struct GraphicInfo_EM *g_em,
			int tile, int frame_em, int x, int y)
{
  int action = object_mapping[tile].action;
#if 1
  int direction = object_mapping[tile].direction;
  int effective_element = get_effective_element_EM(tile, frame_em);
  int graphic = (direction == MV_NONE ?
		 el_act2img(effective_element, action) :
		 el_act_dir2img(effective_element, action, direction));
  struct GraphicInfo *g = &graphic_info[graphic];
  int sync_frame;
#endif
  boolean action_removing = (action == ACTION_DIGGING ||
			     action == ACTION_SNAPPING ||
			     action == ACTION_COLLECTING);
  boolean action_moving   = (action == ACTION_FALLING ||
			     action == ACTION_MOVING ||
			     action == ACTION_PUSHING ||
			     action == ACTION_EATING ||
			     action == ACTION_FILLING ||
			     action == ACTION_EMPTYING);
  boolean action_falling  = (action == ACTION_FALLING ||
			     action == ACTION_FILLING ||
			     action == ACTION_EMPTYING);

  /* special case: graphic uses "2nd movement tile" and has defined
     7 frames for movement animation (or less) => use default graphic
     for last (8th) frame which ends the movement animation */
  if (g->double_movement && g->anim_frames < 8 && frame_em == 7)
  {
    action = ACTION_DEFAULT;	/* (keep action_* unchanged for now) */
    graphic = (direction == MV_NONE ?
	       el_act2img(effective_element, action) :
	       el_act_dir2img(effective_element, action, direction));

    g = &graphic_info[graphic];
  }

#if 0
  if (tile == Xsand_stonesand_1 ||
      tile == Xsand_stonesand_2 ||
      tile == Xsand_stonesand_3 ||
      tile == Xsand_stonesand_4)
    printf("::: 1: quicksand frame %d [%d]\n", GfxFrame[x][y], tile);
#endif

#if 1
  if ((action_removing || check_linear_animation_EM(tile)) && frame_em == 0)
  {
    GfxFrame[x][y] = 0;

    // printf("::: resetting... [%d]\n", tile);
  }
#else
  if (action_removing || check_linear_animation_EM(tile))
  {
    GfxFrame[x][y] = frame_em;

    // printf("::: resetting... [%d]\n", tile);
  }
#endif
  else if (action_moving)
  {
    boolean is_backside = object_mapping[tile].is_backside;

    if (is_backside)
    {
      int direction = object_mapping[tile].direction;
      int move_dir = (action_falling ? MV_DOWN : direction);

      GfxFrame[x][y]++;

#if 1
      /* !!! TEST !!! NEW !!! DOES NOT WORK RIGHT YET !!! */
      if (g->double_movement && frame_em == 0)
      {
	GfxFrame[x][y] = 0;

	// printf("::: resetting... [%d]\n", tile);
      }
#endif

      if (move_dir == MV_LEFT)
	GfxFrame[x - 1][y] = GfxFrame[x][y];
      else if (move_dir == MV_RIGHT)
	GfxFrame[x + 1][y] = GfxFrame[x][y];
      else if (move_dir == MV_UP)
	GfxFrame[x][y - 1] = GfxFrame[x][y];
      else if (move_dir == MV_DOWN)
	GfxFrame[x][y + 1] = GfxFrame[x][y];
    }
  }
  else
  {
    GfxFrame[x][y]++;

    /* special case: animation for Xsand_stonesand_quickout_1/2 twice as fast */
    if (tile == Xsand_stonesand_quickout_1 ||
	tile == Xsand_stonesand_quickout_2)
      GfxFrame[x][y]++;
  }

#if 0
  if (tile == Xsand_stonesand_1 ||
      tile == Xsand_stonesand_2 ||
      tile == Xsand_stonesand_3 ||
      tile == Xsand_stonesand_4)
    printf("::: 2: quicksand frame %d [%d]\n", GfxFrame[x][y], tile);
#endif

#if 1
  if (graphic_info[graphic].anim_global_sync)
    sync_frame = FrameCounter;
  else if (IN_FIELD(x, y, MAX_LEV_FIELDX, MAX_LEV_FIELDY))
    sync_frame = GfxFrame[x][y];
  else
    sync_frame = 0;	/* playfield border (pseudo steel) */

  SetRandomAnimationValue(x, y);

  int frame = getAnimationFrame(g->anim_frames,
				g->anim_delay,
				g->anim_mode,
				g->anim_start_frame,
				sync_frame);

  g_em->unique_identifier =
    (graphic << 16) | ((frame % 8) << 12) | (g_em->width << 6) | g_em->height;
#endif
}

void getGraphicSourceObjectExt_EM(struct GraphicInfo_EM *g_em,
				  int tile, int frame_em, int x, int y)
{
  int action = object_mapping[tile].action;
  int direction = object_mapping[tile].direction;
  boolean is_backside = object_mapping[tile].is_backside;
  int effective_element = get_effective_element_EM(tile, frame_em);
#if 1
  int effective_action = action;
#else
  int effective_action = (frame_em < 7 ? action : ACTION_DEFAULT);
#endif
  int graphic = (direction == MV_NONE ?
		 el_act2img(effective_element, effective_action) :
		 el_act_dir2img(effective_element, effective_action,
				direction));
  int crumbled = (direction == MV_NONE ?
		  el_act2crm(effective_element, effective_action) :
		  el_act_dir2crm(effective_element, effective_action,
				 direction));
  int base_graphic = el_act2img(effective_element, ACTION_DEFAULT);
  int base_crumbled = el_act2crm(effective_element, ACTION_DEFAULT);
  boolean has_crumbled_graphics = (base_crumbled != base_graphic);
  struct GraphicInfo *g = &graphic_info[graphic];
#if 0
  struct GraphicInfo *g_crumbled = &graphic_info[crumbled];
#endif
  int sync_frame;

  /* special case: graphic uses "2nd movement tile" and has defined
     7 frames for movement animation (or less) => use default graphic
     for last (8th) frame which ends the movement animation */
  if (g->double_movement && g->anim_frames < 8 && frame_em == 7)
  {
    effective_action = ACTION_DEFAULT;
    graphic = (direction == MV_NONE ?
	       el_act2img(effective_element, effective_action) :
	       el_act_dir2img(effective_element, effective_action,
			      direction));
    crumbled = (direction == MV_NONE ?
		el_act2crm(effective_element, effective_action) :
		el_act_dir2crm(effective_element, effective_action,
			       direction));

    g = &graphic_info[graphic];
  }

#if 0
  if (frame_em == 7)
    return;
#endif


#if 0
  if (frame_em == 0)	/* reset animation frame for certain elements */
  {
    if (check_linear_animation_EM(tile))
      GfxFrame[x][y] = 0;
  }
#endif

  if (graphic_info[graphic].anim_global_sync)
    sync_frame = FrameCounter;
  else if (IN_FIELD(x, y, MAX_LEV_FIELDX, MAX_LEV_FIELDY))
    sync_frame = GfxFrame[x][y];
  else
    sync_frame = 0;	/* playfield border (pseudo steel) */

  SetRandomAnimationValue(x, y);

#if 0
  int i = tile;
  int j = frame_em;
  int xxx_sync_frame = (i == Xdrip_stretch ? 7 :
			i == Xdrip_stretchB ? 7 :
			i == Ydrip_s2 ? j + 8 :
			i == Ydrip_s2B ? j + 8 :
			i == Xacid_1 ? 0 :
			i == Xacid_2 ? 10 :
			i == Xacid_3 ? 20 :
			i == Xacid_4 ? 30 :
			i == Xacid_5 ? 40 :
			i == Xacid_6 ? 50 :
			i == Xacid_7 ? 60 :
			i == Xacid_8 ? 70 :
			i == Xfake_acid_1 ? 0 :
			i == Xfake_acid_2 ? 10 :
			i == Xfake_acid_3 ? 20 :
			i == Xfake_acid_4 ? 30 :
			i == Xfake_acid_5 ? 40 :
			i == Xfake_acid_6 ? 50 :
			i == Xfake_acid_7 ? 60 :
			i == Xfake_acid_8 ? 70 :
			i == Xball_2 ? 7 :
			i == Xball_2B ? j + 8 :
			i == Yball_eat ? j + 1 :
			i == Ykey_1_eat ? j + 1 :
			i == Ykey_2_eat ? j + 1 :
			i == Ykey_3_eat ? j + 1 :
			i == Ykey_4_eat ? j + 1 :
			i == Ykey_5_eat ? j + 1 :
			i == Ykey_6_eat ? j + 1 :
			i == Ykey_7_eat ? j + 1 :
			i == Ykey_8_eat ? j + 1 :
			i == Ylenses_eat ? j + 1 :
			i == Ymagnify_eat ? j + 1 :
			i == Ygrass_eat ? j + 1 :
			i == Ydirt_eat ? j + 1 :
			i == Xamoeba_1 ? 0 :
			i == Xamoeba_2 ? 1 :
			i == Xamoeba_3 ? 2 :
			i == Xamoeba_4 ? 3 :
			i == Xamoeba_5 ? 0 :
			i == Xamoeba_6 ? 1 :
			i == Xamoeba_7 ? 2 :
			i == Xamoeba_8 ? 3 :
			i == Xexit_2 ? j + 8 :
			i == Xexit_3 ? j + 16 :
			i == Xdynamite_1 ? 0 :
			i == Xdynamite_2 ? 8 :
			i == Xdynamite_3 ? 16 :
			i == Xdynamite_4 ? 24 :
			i == Xsand_stonein_1 ? j + 1 :
			i == Xsand_stonein_2 ? j + 9 :
			i == Xsand_stonein_3 ? j + 17 :
			i == Xsand_stonein_4 ? j + 25 :
			i == Xsand_stoneout_1 && j == 0 ? 0 :
			i == Xsand_stoneout_1 && j == 1 ? 0 :
			i == Xsand_stoneout_1 && j == 2 ? 1 :
			i == Xsand_stoneout_1 && j == 3 ? 2 :
			i == Xsand_stoneout_1 && j == 4 ? 2 :
			i == Xsand_stoneout_1 && j == 5 ? 3 :
			i == Xsand_stoneout_1 && j == 6 ? 4 :
			i == Xsand_stoneout_1 && j == 7 ? 4 :
			i == Xsand_stoneout_2 && j == 0 ? 5 :
			i == Xsand_stoneout_2 && j == 1 ? 6 :
			i == Xsand_stoneout_2 && j == 2 ? 7 :
			i == Xsand_stoneout_2 && j == 3 ? 8 :
			i == Xsand_stoneout_2 && j == 4 ? 9 :
			i == Xsand_stoneout_2 && j == 5 ? 11 :
			i == Xsand_stoneout_2 && j == 6 ? 13 :
			i == Xsand_stoneout_2 && j == 7 ? 15 :
			i == Xboom_bug && j == 1 ? 2 :
			i == Xboom_bug && j == 2 ? 2 :
			i == Xboom_bug && j == 3 ? 4 :
			i == Xboom_bug && j == 4 ? 4 :
			i == Xboom_bug && j == 5 ? 2 :
			i == Xboom_bug && j == 6 ? 2 :
			i == Xboom_bug && j == 7 ? 0 :
			i == Xboom_bomb && j == 1 ? 2 :
			i == Xboom_bomb && j == 2 ? 2 :
			i == Xboom_bomb && j == 3 ? 4 :
			i == Xboom_bomb && j == 4 ? 4 :
			i == Xboom_bomb && j == 5 ? 2 :
			i == Xboom_bomb && j == 6 ? 2 :
			i == Xboom_bomb && j == 7 ? 0 :
			i == Xboom_android && j == 7 ? 6 :
			i == Xboom_1 && j == 1 ? 2 :
			i == Xboom_1 && j == 2 ? 2 :
			i == Xboom_1 && j == 3 ? 4 :
			i == Xboom_1 && j == 4 ? 4 :
			i == Xboom_1 && j == 5 ? 6 :
			i == Xboom_1 && j == 6 ? 6 :
			i == Xboom_1 && j == 7 ? 8 :
			i == Xboom_2 && j == 0 ? 8 :
			i == Xboom_2 && j == 1 ? 8 :
			i == Xboom_2 && j == 2 ? 10 :
			i == Xboom_2 && j == 3 ? 10 :
			i == Xboom_2 && j == 4 ? 10 :
			i == Xboom_2 && j == 5 ? 12 :
			i == Xboom_2 && j == 6 ? 12 :
			i == Xboom_2 && j == 7 ? 12 :
#if 0
			special_animation && j == 4 ? 3 :
			effective_action != action ? 0 :
#endif
			j);
#endif

#if 0
  int xxx_effective_action;
  int xxx_has_action_graphics;

  {
    int element = object_mapping[i].element_rnd;
    int action = object_mapping[i].action;
    int direction = object_mapping[i].direction;
    boolean is_backside = object_mapping[i].is_backside;
#if 0
    boolean action_removing = (action == ACTION_DIGGING ||
			       action == ACTION_SNAPPING ||
			       action == ACTION_COLLECTING);
#endif
    boolean action_exploding = ((action == ACTION_EXPLODING ||
				 action == ACTION_SMASHED_BY_ROCK ||
				 action == ACTION_SMASHED_BY_SPRING) &&
				element != EL_DIAMOND);
    boolean action_active = (action == ACTION_ACTIVE);
    boolean action_other = (action == ACTION_OTHER);

    {
#if 1
      int effective_element = get_effective_element_EM(i, j);
#else
      int effective_element = (j > 5 && i == Yacid_splash_eB ? EL_EMPTY :
			       j > 5 && i == Yacid_splash_wB ? EL_EMPTY :
			       j < 7 ? element :
			       i == Xdrip_stretch ? element :
			       i == Xdrip_stretchB ? element :
			       i == Ydrip_s1 ? element :
			       i == Ydrip_s1B ? element :
			       i == Xball_1B ? element :
			       i == Xball_2 ? element :
			       i == Xball_2B ? element :
			       i == Yball_eat ? element :
			       i == Ykey_1_eat ? element :
			       i == Ykey_2_eat ? element :
			       i == Ykey_3_eat ? element :
			       i == Ykey_4_eat ? element :
			       i == Ykey_5_eat ? element :
			       i == Ykey_6_eat ? element :
			       i == Ykey_7_eat ? element :
			       i == Ykey_8_eat ? element :
			       i == Ylenses_eat ? element :
			       i == Ymagnify_eat ? element :
			       i == Ygrass_eat ? element :
			       i == Ydirt_eat ? element :
			       i == Yemerald_stone ? EL_EMERALD :
			       i == Ydiamond_stone ? EL_ROCK :
			       i == Xsand_stonein_1 ? element :
			       i == Xsand_stonein_2 ? element :
			       i == Xsand_stonein_3 ? element :
			       i == Xsand_stonein_4 ? element :
			       is_backside ? EL_EMPTY :
			       action_removing ? EL_EMPTY :
			       element);
#endif
      int effective_action = (j < 7 ? action :
			      i == Xdrip_stretch ? action :
			      i == Xdrip_stretchB ? action :
			      i == Ydrip_s1 ? action :
			      i == Ydrip_s1B ? action :
			      i == Xball_1B ? action :
			      i == Xball_2 ? action :
			      i == Xball_2B ? action :
			      i == Yball_eat ? action :
			      i == Ykey_1_eat ? action :
			      i == Ykey_2_eat ? action :
			      i == Ykey_3_eat ? action :
			      i == Ykey_4_eat ? action :
			      i == Ykey_5_eat ? action :
			      i == Ykey_6_eat ? action :
			      i == Ykey_7_eat ? action :
			      i == Ykey_8_eat ? action :
			      i == Ylenses_eat ? action :
			      i == Ymagnify_eat ? action :
			      i == Ygrass_eat ? action :
			      i == Ydirt_eat ? action :
			      i == Xsand_stonein_1 ? action :
			      i == Xsand_stonein_2 ? action :
			      i == Xsand_stonein_3 ? action :
			      i == Xsand_stonein_4 ? action :
			      i == Xsand_stoneout_1 ? action :
			      i == Xsand_stoneout_2 ? action :
			      i == Xboom_android ? ACTION_EXPLODING :
			      action_exploding ? ACTION_EXPLODING :
			      action_active ? action :
			      action_other ? action :
			      ACTION_DEFAULT);
      int graphic = (el_act_dir2img(effective_element, effective_action,
				    direction));
      int crumbled = (el_act_dir2crm(effective_element, effective_action,
				     direction));
      int base_graphic = el_act2img(effective_element, ACTION_DEFAULT);
      int base_crumbled = el_act2crm(effective_element, ACTION_DEFAULT);
      boolean has_action_graphics = (graphic != base_graphic);
      boolean has_crumbled_graphics = (base_crumbled != base_graphic);
      struct GraphicInfo *g = &graphic_info[graphic];
#if 0
      struct GraphicInfo *g_crumbled = &graphic_info[crumbled];
#endif
      struct GraphicInfo_EM *g_em = &graphic_info_em_object[i][7 - j];
      Bitmap *src_bitmap;
      int src_x, src_y;
      /* ensure to get symmetric 3-frame, 2-delay animations as used in EM */
      boolean special_animation = (action != ACTION_DEFAULT &&
				   g->anim_frames == 3 &&
				   g->anim_delay == 2 &&
				   g->anim_mode & ANIM_LINEAR);
      xxx_sync_frame = (i == Xdrip_stretch ? 7 :
			i == Xdrip_stretchB ? 7 :
			i == Ydrip_s2 ? j + 8 :
			i == Ydrip_s2B ? j + 8 :
			i == Xacid_1 ? 0 :
			i == Xacid_2 ? 10 :
			i == Xacid_3 ? 20 :
			i == Xacid_4 ? 30 :
			i == Xacid_5 ? 40 :
			i == Xacid_6 ? 50 :
			i == Xacid_7 ? 60 :
			i == Xacid_8 ? 70 :
			i == Xfake_acid_1 ? 0 :
			i == Xfake_acid_2 ? 10 :
			i == Xfake_acid_3 ? 20 :
			i == Xfake_acid_4 ? 30 :
			i == Xfake_acid_5 ? 40 :
			i == Xfake_acid_6 ? 50 :
			i == Xfake_acid_7 ? 60 :
			i == Xfake_acid_8 ? 70 :
			i == Xball_2 ? 7 :
			i == Xball_2B ? j + 8 :
			i == Yball_eat ? j + 1 :
			i == Ykey_1_eat ? j + 1 :
			i == Ykey_2_eat ? j + 1 :
			i == Ykey_3_eat ? j + 1 :
			i == Ykey_4_eat ? j + 1 :
			i == Ykey_5_eat ? j + 1 :
			i == Ykey_6_eat ? j + 1 :
			i == Ykey_7_eat ? j + 1 :
			i == Ykey_8_eat ? j + 1 :
			i == Ylenses_eat ? j + 1 :
			i == Ymagnify_eat ? j + 1 :
			i == Ygrass_eat ? j + 1 :
			i == Ydirt_eat ? j + 1 :
			i == Xamoeba_1 ? 0 :
			i == Xamoeba_2 ? 1 :
			i == Xamoeba_3 ? 2 :
			i == Xamoeba_4 ? 3 :
			i == Xamoeba_5 ? 0 :
			i == Xamoeba_6 ? 1 :
			i == Xamoeba_7 ? 2 :
			i == Xamoeba_8 ? 3 :
			i == Xexit_2 ? j + 8 :
			i == Xexit_3 ? j + 16 :
			i == Xdynamite_1 ? 0 :
			i == Xdynamite_2 ? 8 :
			i == Xdynamite_3 ? 16 :
			i == Xdynamite_4 ? 24 :
			i == Xsand_stonein_1 ? j + 1 :
			i == Xsand_stonein_2 ? j + 9 :
			i == Xsand_stonein_3 ? j + 17 :
			i == Xsand_stonein_4 ? j + 25 :
			i == Xsand_stoneout_1 && j == 0 ? 0 :
			i == Xsand_stoneout_1 && j == 1 ? 0 :
			i == Xsand_stoneout_1 && j == 2 ? 1 :
			i == Xsand_stoneout_1 && j == 3 ? 2 :
			i == Xsand_stoneout_1 && j == 4 ? 2 :
			i == Xsand_stoneout_1 && j == 5 ? 3 :
			i == Xsand_stoneout_1 && j == 6 ? 4 :
			i == Xsand_stoneout_1 && j == 7 ? 4 :
			i == Xsand_stoneout_2 && j == 0 ? 5 :
			i == Xsand_stoneout_2 && j == 1 ? 6 :
			i == Xsand_stoneout_2 && j == 2 ? 7 :
			i == Xsand_stoneout_2 && j == 3 ? 8 :
			i == Xsand_stoneout_2 && j == 4 ? 9 :
			i == Xsand_stoneout_2 && j == 5 ? 11 :
			i == Xsand_stoneout_2 && j == 6 ? 13 :
			i == Xsand_stoneout_2 && j == 7 ? 15 :
			i == Xboom_bug && j == 1 ? 2 :
			i == Xboom_bug && j == 2 ? 2 :
			i == Xboom_bug && j == 3 ? 4 :
			i == Xboom_bug && j == 4 ? 4 :
			i == Xboom_bug && j == 5 ? 2 :
			i == Xboom_bug && j == 6 ? 2 :
			i == Xboom_bug && j == 7 ? 0 :
			i == Xboom_bomb && j == 1 ? 2 :
			i == Xboom_bomb && j == 2 ? 2 :
			i == Xboom_bomb && j == 3 ? 4 :
			i == Xboom_bomb && j == 4 ? 4 :
			i == Xboom_bomb && j == 5 ? 2 :
			i == Xboom_bomb && j == 6 ? 2 :
			i == Xboom_bomb && j == 7 ? 0 :
			i == Xboom_android && j == 7 ? 6 :
			i == Xboom_1 && j == 1 ? 2 :
			i == Xboom_1 && j == 2 ? 2 :
			i == Xboom_1 && j == 3 ? 4 :
			i == Xboom_1 && j == 4 ? 4 :
			i == Xboom_1 && j == 5 ? 6 :
			i == Xboom_1 && j == 6 ? 6 :
			i == Xboom_1 && j == 7 ? 8 :
			i == Xboom_2 && j == 0 ? 8 :
			i == Xboom_2 && j == 1 ? 8 :
			i == Xboom_2 && j == 2 ? 10 :
			i == Xboom_2 && j == 3 ? 10 :
			i == Xboom_2 && j == 4 ? 10 :
			i == Xboom_2 && j == 5 ? 12 :
			i == Xboom_2 && j == 6 ? 12 :
			i == Xboom_2 && j == 7 ? 12 :
			special_animation && j == 4 ? 3 :
			effective_action != action ? 0 :
			j);

      xxx_effective_action = effective_action;
      xxx_has_action_graphics = has_action_graphics;
    }
  }
#endif

  int frame = getAnimationFrame(g->anim_frames,
				g->anim_delay,
				g->anim_mode,
				g->anim_start_frame,
				sync_frame);


#if 0
  return;
#endif

#if 0
  if (frame_em == 7)
    return;
#endif

#if 0
  int old_src_x = g_em->src_x;
  int old_src_y = g_em->src_y;
#endif

#if 1
  getGraphicSourceExt(graphic, frame, &g_em->bitmap, &g_em->src_x, &g_em->src_y,
		      g->double_movement && is_backside);
#else
  getGraphicSourceExt(graphic, frame, &g_em->bitmap,
		      &g_em->src_x, &g_em->src_y, FALSE);
#endif


#if 0
  if (tile == Ydiamond_stone)
    printf("::: stone smashing diamond... %d: %d, %d, %d, %d, %d -> %d [%d, %d, %d, %d, %d, %d] [%d]\n",
	   frame_em,
	   g->anim_frames,
	   g->anim_delay,
	   g->anim_mode,
	   g->anim_start_frame,
	   sync_frame,
	   frame,
	   g_em->src_x, g_em->src_y,
	   g_em->src_offset_x, g_em->src_offset_y,
	   g_em->dst_offset_x, g_em->dst_offset_y,
	   graphic);
#endif


#if 0
  return;
#endif

#if 0
  if (frame_em == 7)
  {
    if (graphic == IMG_BUG_MOVING_RIGHT)
      printf("::: %d, %d, %d: %d, %d [%d, %d -> %d, %d]\n", graphic, x, y,
	     g->double_movement, is_backside,
	     old_src_x, old_src_y, g_em->src_x, g_em->src_y);

    return;
  }
#endif


#if 0
  g_em->src_offset_x = 0;
  g_em->src_offset_y = 0;
  g_em->dst_offset_x = 0;
  g_em->dst_offset_y = 0;
  g_em->width  = TILEX;
  g_em->height = TILEY;

  g_em->preserve_background = FALSE;
#endif

  /* (updating the "crumbled" graphic definitions is probably not really needed,
     as animations for crumbled graphics can't be longer than one EMC cycle) */
#if 1
  set_crumbled_graphics_EM(g_em, has_crumbled_graphics, crumbled,
			   sync_frame);

#else

  g_em->crumbled_bitmap = NULL;
  g_em->crumbled_src_x = 0;
  g_em->crumbled_src_y = 0;

  g_em->has_crumbled_graphics = FALSE;

  if (has_crumbled_graphics && crumbled != IMG_EMPTY_SPACE)
  {
    int frame_crumbled = getAnimationFrame(g_crumbled->anim_frames,
					   g_crumbled->anim_delay,
					   g_crumbled->anim_mode,
					   g_crumbled->anim_start_frame,
					   sync_frame);

    getGraphicSource(crumbled, frame_crumbled, &g_em->crumbled_bitmap,
		     &g_em->crumbled_src_x, &g_em->crumbled_src_y);

    g_em->has_crumbled_graphics = TRUE;
  }
#endif

#if 0
 {
   int effective_action = xxx_effective_action;
   int has_action_graphics = xxx_has_action_graphics;

      if ((!g->double_movement && (effective_action == ACTION_FALLING ||
				   effective_action == ACTION_MOVING  ||
				   effective_action == ACTION_PUSHING ||
				   effective_action == ACTION_EATING)) ||
	  (!has_action_graphics && (effective_action == ACTION_FILLING ||
				    effective_action == ACTION_EMPTYING)))
      {
	int move_dir =
	  (effective_action == ACTION_FALLING ||
	   effective_action == ACTION_FILLING ||
	   effective_action == ACTION_EMPTYING ? MV_DOWN : direction);
	int dx = (move_dir == MV_LEFT ? -1 : move_dir == MV_RIGHT ? 1 : 0);
	int dy = (move_dir == MV_UP   ? -1 : move_dir == MV_DOWN  ? 1 : 0);
	int num_steps = (i == Ydrip_s1  ? 16 :
			 i == Ydrip_s1B ? 16 :
			 i == Ydrip_s2  ? 16 :
			 i == Ydrip_s2B ? 16 :
			 i == Xsand_stonein_1 ? 32 :
			 i == Xsand_stonein_2 ? 32 :
			 i == Xsand_stonein_3 ? 32 :
			 i == Xsand_stonein_4 ? 32 :
			 i == Xsand_stoneout_1 ? 16 :
			 i == Xsand_stoneout_2 ? 16 : 8);
	int cx = ABS(dx) * (TILEX / num_steps);
	int cy = ABS(dy) * (TILEY / num_steps);
	int step_frame = (i == Ydrip_s2         ? j + 8 :
			  i == Ydrip_s2B        ? j + 8 :
			  i == Xsand_stonein_2  ? j + 8 :
			  i == Xsand_stonein_3  ? j + 16 :
			  i == Xsand_stonein_4  ? j + 24 :
			  i == Xsand_stoneout_2 ? j + 8 : j) + 1;
	int step = (is_backside ? step_frame : num_steps - step_frame);

	if (is_backside)	/* tile where movement starts */
	{
	  if (dx < 0 || dy < 0)
	  {
	    g_em->src_offset_x = cx * step;
	    g_em->src_offset_y = cy * step;
	  }
	  else
	  {
	    g_em->dst_offset_x = cx * step;
	    g_em->dst_offset_y = cy * step;
	  }
	}
	else			/* tile where movement ends */
	{
	  if (dx < 0 || dy < 0)
	  {
	    g_em->dst_offset_x = cx * step;
	    g_em->dst_offset_y = cy * step;
	  }
	  else
	  {
	    g_em->src_offset_x = cx * step;
	    g_em->src_offset_y = cy * step;
	  }
	}

	g_em->width  = TILEX - cx * step;
	g_em->height = TILEY - cy * step;
      }

      /* create unique graphic identifier to decide if tile must be redrawn */
      /* bit 31 - 16 (16 bit): EM style graphic
	 bit 15 - 12 ( 4 bit): EM style frame
	 bit 11 -  6 ( 6 bit): graphic width
	 bit  5 -  0 ( 6 bit): graphic height */
      g_em->unique_identifier =
	(graphic << 16) | (frame << 12) | (g_em->width << 6) | g_em->height;
 }
#endif

}

void getGraphicSourcePlayerExt_EM(struct GraphicInfo_EM *g_em,
				  int player_nr, int anim, int frame_em)
{
  int element   = player_mapping[player_nr][anim].element_rnd;
  int action    = player_mapping[player_nr][anim].action;
  int direction = player_mapping[player_nr][anim].direction;
  int graphic = (direction == MV_NONE ?
		 el_act2img(element, action) :
		 el_act_dir2img(element, action, direction));
  struct GraphicInfo *g = &graphic_info[graphic];
  int sync_frame;

  InitPlayerGfxAnimation(&stored_player[player_nr], action, direction);

  stored_player[player_nr].StepFrame = frame_em;

  sync_frame = stored_player[player_nr].Frame;

  int frame = getAnimationFrame(g->anim_frames,
				g->anim_delay,
				g->anim_mode,
				g->anim_start_frame,
				sync_frame);

  getGraphicSourceExt(graphic, frame, &g_em->bitmap,
		      &g_em->src_x, &g_em->src_y, FALSE);

#if 0
  printf("::: %d: %d, %d [%d]\n",
	 player_nr,
	 stored_player[player_nr].Frame,
	 stored_player[player_nr].StepFrame,
	 FrameCounter);
#endif
}

void InitGraphicInfo_EM(void)
{
#if 0
  struct Mapping_EM_to_RND_object object_mapping[TILE_MAX];
  struct Mapping_EM_to_RND_player player_mapping[MAX_PLAYERS][SPR_MAX];
#endif
  int i, j, p;

#if DEBUG_EM_GFX
  int num_em_gfx_errors = 0;

  if (graphic_info_em_object[0][0].bitmap == NULL)
  {
    /* EM graphics not yet initialized in em_open_all() */

    return;
  }

  printf("::: [4 errors can be ignored (1 x 'bomb', 3 x 'em_dynamite']\n");
#endif

  /* always start with reliable default values */
  for (i = 0; i < TILE_MAX; i++)
  {
    object_mapping[i].element_rnd = EL_UNKNOWN;
    object_mapping[i].is_backside = FALSE;
    object_mapping[i].action = ACTION_DEFAULT;
    object_mapping[i].direction = MV_NONE;
  }

  /* always start with reliable default values */
  for (p = 0; p < MAX_PLAYERS; p++)
  {
    for (i = 0; i < SPR_MAX; i++)
    {
      player_mapping[p][i].element_rnd = EL_UNKNOWN;
      player_mapping[p][i].action = ACTION_DEFAULT;
      player_mapping[p][i].direction = MV_NONE;
    }
  }

  for (i = 0; em_object_mapping_list[i].element_em != -1; i++)
  {
    int e = em_object_mapping_list[i].element_em;

    object_mapping[e].element_rnd = em_object_mapping_list[i].element_rnd;
    object_mapping[e].is_backside = em_object_mapping_list[i].is_backside;

    if (em_object_mapping_list[i].action != -1)
      object_mapping[e].action = em_object_mapping_list[i].action;

    if (em_object_mapping_list[i].direction != -1)
      object_mapping[e].direction =
	MV_DIR_FROM_BIT(em_object_mapping_list[i].direction);
  }

  for (i = 0; em_player_mapping_list[i].action_em != -1; i++)
  {
    int a = em_player_mapping_list[i].action_em;
    int p = em_player_mapping_list[i].player_nr;

    player_mapping[p][a].element_rnd = em_player_mapping_list[i].element_rnd;

    if (em_player_mapping_list[i].action != -1)
      player_mapping[p][a].action = em_player_mapping_list[i].action;

    if (em_player_mapping_list[i].direction != -1)
      player_mapping[p][a].direction =
	MV_DIR_FROM_BIT(em_player_mapping_list[i].direction);
  }

  for (i = 0; i < TILE_MAX; i++)
  {
    int element = object_mapping[i].element_rnd;
    int action = object_mapping[i].action;
    int direction = object_mapping[i].direction;
    boolean is_backside = object_mapping[i].is_backside;
#if 0
    boolean action_removing = (action == ACTION_DIGGING ||
			       action == ACTION_SNAPPING ||
			       action == ACTION_COLLECTING);
#endif
    boolean action_exploding = ((action == ACTION_EXPLODING ||
				 action == ACTION_SMASHED_BY_ROCK ||
				 action == ACTION_SMASHED_BY_SPRING) &&
				element != EL_DIAMOND);
    boolean action_active = (action == ACTION_ACTIVE);
    boolean action_other = (action == ACTION_OTHER);

    for (j = 0; j < 8; j++)
    {
#if 1
      int effective_element = get_effective_element_EM(i, j);
#else
      int effective_element = (j > 5 && i == Yacid_splash_eB ? EL_EMPTY :
			       j > 5 && i == Yacid_splash_wB ? EL_EMPTY :
			       j < 7 ? element :
			       i == Xdrip_stretch ? element :
			       i == Xdrip_stretchB ? element :
			       i == Ydrip_s1 ? element :
			       i == Ydrip_s1B ? element :
			       i == Xball_1B ? element :
			       i == Xball_2 ? element :
			       i == Xball_2B ? element :
			       i == Yball_eat ? element :
			       i == Ykey_1_eat ? element :
			       i == Ykey_2_eat ? element :
			       i == Ykey_3_eat ? element :
			       i == Ykey_4_eat ? element :
			       i == Ykey_5_eat ? element :
			       i == Ykey_6_eat ? element :
			       i == Ykey_7_eat ? element :
			       i == Ykey_8_eat ? element :
			       i == Ylenses_eat ? element :
			       i == Ymagnify_eat ? element :
			       i == Ygrass_eat ? element :
			       i == Ydirt_eat ? element :
			       i == Yemerald_stone ? EL_EMERALD :
			       i == Ydiamond_stone ? EL_ROCK :
			       i == Xsand_stonein_1 ? element :
			       i == Xsand_stonein_2 ? element :
			       i == Xsand_stonein_3 ? element :
			       i == Xsand_stonein_4 ? element :
			       is_backside ? EL_EMPTY :
			       action_removing ? EL_EMPTY :
			       element);
#endif
      int effective_action = (j < 7 ? action :
			      i == Xdrip_stretch ? action :
			      i == Xdrip_stretchB ? action :
			      i == Ydrip_s1 ? action :
			      i == Ydrip_s1B ? action :
			      i == Xball_1B ? action :
			      i == Xball_2 ? action :
			      i == Xball_2B ? action :
			      i == Yball_eat ? action :
			      i == Ykey_1_eat ? action :
			      i == Ykey_2_eat ? action :
			      i == Ykey_3_eat ? action :
			      i == Ykey_4_eat ? action :
			      i == Ykey_5_eat ? action :
			      i == Ykey_6_eat ? action :
			      i == Ykey_7_eat ? action :
			      i == Ykey_8_eat ? action :
			      i == Ylenses_eat ? action :
			      i == Ymagnify_eat ? action :
			      i == Ygrass_eat ? action :
			      i == Ydirt_eat ? action :
			      i == Xsand_stonein_1 ? action :
			      i == Xsand_stonein_2 ? action :
			      i == Xsand_stonein_3 ? action :
			      i == Xsand_stonein_4 ? action :
			      i == Xsand_stoneout_1 ? action :
			      i == Xsand_stoneout_2 ? action :
			      i == Xboom_android ? ACTION_EXPLODING :
			      action_exploding ? ACTION_EXPLODING :
			      action_active ? action :
			      action_other ? action :
			      ACTION_DEFAULT);
      int graphic = (el_act_dir2img(effective_element, effective_action,
				    direction));
      int crumbled = (el_act_dir2crm(effective_element, effective_action,
				     direction));
      int base_graphic = el_act2img(effective_element, ACTION_DEFAULT);
      int base_crumbled = el_act2crm(effective_element, ACTION_DEFAULT);
      boolean has_action_graphics = (graphic != base_graphic);
      boolean has_crumbled_graphics = (base_crumbled != base_graphic);
      struct GraphicInfo *g = &graphic_info[graphic];
#if 0
      struct GraphicInfo *g_crumbled = &graphic_info[crumbled];
#endif
      struct GraphicInfo_EM *g_em = &graphic_info_em_object[i][7 - j];
      Bitmap *src_bitmap;
      int src_x, src_y;
      /* ensure to get symmetric 3-frame, 2-delay animations as used in EM */
      boolean special_animation = (action != ACTION_DEFAULT &&
				   g->anim_frames == 3 &&
				   g->anim_delay == 2 &&
				   g->anim_mode & ANIM_LINEAR);
      int sync_frame = (i == Xdrip_stretch ? 7 :
			i == Xdrip_stretchB ? 7 :
			i == Ydrip_s2 ? j + 8 :
			i == Ydrip_s2B ? j + 8 :
			i == Xacid_1 ? 0 :
			i == Xacid_2 ? 10 :
			i == Xacid_3 ? 20 :
			i == Xacid_4 ? 30 :
			i == Xacid_5 ? 40 :
			i == Xacid_6 ? 50 :
			i == Xacid_7 ? 60 :
			i == Xacid_8 ? 70 :
			i == Xfake_acid_1 ? 0 :
			i == Xfake_acid_2 ? 10 :
			i == Xfake_acid_3 ? 20 :
			i == Xfake_acid_4 ? 30 :
			i == Xfake_acid_5 ? 40 :
			i == Xfake_acid_6 ? 50 :
			i == Xfake_acid_7 ? 60 :
			i == Xfake_acid_8 ? 70 :
			i == Xball_2 ? 7 :
			i == Xball_2B ? j + 8 :
			i == Yball_eat ? j + 1 :
			i == Ykey_1_eat ? j + 1 :
			i == Ykey_2_eat ? j + 1 :
			i == Ykey_3_eat ? j + 1 :
			i == Ykey_4_eat ? j + 1 :
			i == Ykey_5_eat ? j + 1 :
			i == Ykey_6_eat ? j + 1 :
			i == Ykey_7_eat ? j + 1 :
			i == Ykey_8_eat ? j + 1 :
			i == Ylenses_eat ? j + 1 :
			i == Ymagnify_eat ? j + 1 :
			i == Ygrass_eat ? j + 1 :
			i == Ydirt_eat ? j + 1 :
			i == Xamoeba_1 ? 0 :
			i == Xamoeba_2 ? 1 :
			i == Xamoeba_3 ? 2 :
			i == Xamoeba_4 ? 3 :
			i == Xamoeba_5 ? 0 :
			i == Xamoeba_6 ? 1 :
			i == Xamoeba_7 ? 2 :
			i == Xamoeba_8 ? 3 :
			i == Xexit_2 ? j + 8 :
			i == Xexit_3 ? j + 16 :
			i == Xdynamite_1 ? 0 :
			i == Xdynamite_2 ? 8 :
			i == Xdynamite_3 ? 16 :
			i == Xdynamite_4 ? 24 :
			i == Xsand_stonein_1 ? j + 1 :
			i == Xsand_stonein_2 ? j + 9 :
			i == Xsand_stonein_3 ? j + 17 :
			i == Xsand_stonein_4 ? j + 25 :
			i == Xsand_stoneout_1 && j == 0 ? 0 :
			i == Xsand_stoneout_1 && j == 1 ? 0 :
			i == Xsand_stoneout_1 && j == 2 ? 1 :
			i == Xsand_stoneout_1 && j == 3 ? 2 :
			i == Xsand_stoneout_1 && j == 4 ? 2 :
			i == Xsand_stoneout_1 && j == 5 ? 3 :
			i == Xsand_stoneout_1 && j == 6 ? 4 :
			i == Xsand_stoneout_1 && j == 7 ? 4 :
			i == Xsand_stoneout_2 && j == 0 ? 5 :
			i == Xsand_stoneout_2 && j == 1 ? 6 :
			i == Xsand_stoneout_2 && j == 2 ? 7 :
			i == Xsand_stoneout_2 && j == 3 ? 8 :
			i == Xsand_stoneout_2 && j == 4 ? 9 :
			i == Xsand_stoneout_2 && j == 5 ? 11 :
			i == Xsand_stoneout_2 && j == 6 ? 13 :
			i == Xsand_stoneout_2 && j == 7 ? 15 :
			i == Xboom_bug && j == 1 ? 2 :
			i == Xboom_bug && j == 2 ? 2 :
			i == Xboom_bug && j == 3 ? 4 :
			i == Xboom_bug && j == 4 ? 4 :
			i == Xboom_bug && j == 5 ? 2 :
			i == Xboom_bug && j == 6 ? 2 :
			i == Xboom_bug && j == 7 ? 0 :
			i == Xboom_bomb && j == 1 ? 2 :
			i == Xboom_bomb && j == 2 ? 2 :
			i == Xboom_bomb && j == 3 ? 4 :
			i == Xboom_bomb && j == 4 ? 4 :
			i == Xboom_bomb && j == 5 ? 2 :
			i == Xboom_bomb && j == 6 ? 2 :
			i == Xboom_bomb && j == 7 ? 0 :
			i == Xboom_android && j == 7 ? 6 :
			i == Xboom_1 && j == 1 ? 2 :
			i == Xboom_1 && j == 2 ? 2 :
			i == Xboom_1 && j == 3 ? 4 :
			i == Xboom_1 && j == 4 ? 4 :
			i == Xboom_1 && j == 5 ? 6 :
			i == Xboom_1 && j == 6 ? 6 :
			i == Xboom_1 && j == 7 ? 8 :
			i == Xboom_2 && j == 0 ? 8 :
			i == Xboom_2 && j == 1 ? 8 :
			i == Xboom_2 && j == 2 ? 10 :
			i == Xboom_2 && j == 3 ? 10 :
			i == Xboom_2 && j == 4 ? 10 :
			i == Xboom_2 && j == 5 ? 12 :
			i == Xboom_2 && j == 6 ? 12 :
			i == Xboom_2 && j == 7 ? 12 :
			special_animation && j == 4 ? 3 :
			effective_action != action ? 0 :
			j);

#if DEBUG_EM_GFX
      Bitmap *debug_bitmap = g_em->bitmap;
      int debug_src_x = g_em->src_x;
      int debug_src_y = g_em->src_y;
#endif

      int frame = getAnimationFrame(g->anim_frames,
				    g->anim_delay,
				    g->anim_mode,
				    g->anim_start_frame,
				    sync_frame);

      getGraphicSourceExt(graphic, frame, &src_bitmap, &src_x, &src_y,
			  g->double_movement && is_backside);

      g_em->bitmap = src_bitmap;
      g_em->src_x = src_x;
      g_em->src_y = src_y;
      g_em->src_offset_x = 0;
      g_em->src_offset_y = 0;
      g_em->dst_offset_x = 0;
      g_em->dst_offset_y = 0;
      g_em->width  = TILEX;
      g_em->height = TILEY;

      g_em->preserve_background = FALSE;

#if 1
      set_crumbled_graphics_EM(g_em, has_crumbled_graphics, crumbled,
			       sync_frame);

#else

      g_em->crumbled_bitmap = NULL;
      g_em->crumbled_src_x = 0;
      g_em->crumbled_src_y = 0;
      g_em->crumbled_border_size = 0;

      g_em->has_crumbled_graphics = FALSE;

#if 0
      if (has_crumbled_graphics && crumbled == IMG_EMPTY_SPACE)
	printf("::: empty crumbled: %d [%s], %d, %d\n",
	       effective_element, element_info[effective_element].token_name,
	       effective_action, direction);
#endif

      /* if element can be crumbled, but certain action graphics are just empty
	 space (like instantly snapping sand to empty space in 1 frame), do not
	 treat these empty space graphics as crumbled graphics in EMC engine */
      if (has_crumbled_graphics && crumbled != IMG_EMPTY_SPACE)
      {
	int frame_crumbled = getAnimationFrame(g_crumbled->anim_frames,
					       g_crumbled->anim_delay,
					       g_crumbled->anim_mode,
					       g_crumbled->anim_start_frame,
					       sync_frame);

	getGraphicSource(crumbled, frame_crumbled, &src_bitmap, &src_x, &src_y);

	g_em->has_crumbled_graphics = TRUE;
	g_em->crumbled_bitmap = src_bitmap;
	g_em->crumbled_src_x = src_x;
	g_em->crumbled_src_y = src_y;
	g_em->crumbled_border_size = graphic_info[crumbled].border_size;


#if 0
	if (g_em == &graphic_info_em_object[207][0])
	  printf("... %d, %d [%d, %d, %d, %d] [%d, %d, %d, %d, %d, %d => %d]\n",
		 graphic_info_em_object[207][0].crumbled_src_x,
		 graphic_info_em_object[207][0].crumbled_src_y,

		 crumbled, frame, src_x, src_y,

		 g->anim_frames,
		 g->anim_delay,
		 g->anim_mode,
		 g->anim_start_frame,
		 sync_frame,
		 gfx.anim_random_frame,
		 frame);
#endif

#if 0
	printf("::: EMC tile %d is crumbled\n", i);
#endif
      }
#endif

#if 0
      if (element == EL_ROCK &&
	  effective_action == ACTION_FILLING)
	printf("::: has_action_graphics == %d\n", has_action_graphics);
#endif

      if ((!g->double_movement && (effective_action == ACTION_FALLING ||
				   effective_action == ACTION_MOVING  ||
				   effective_action == ACTION_PUSHING ||
				   effective_action == ACTION_EATING)) ||
	  (!has_action_graphics && (effective_action == ACTION_FILLING ||
				    effective_action == ACTION_EMPTYING)))
      {
	int move_dir =
	  (effective_action == ACTION_FALLING ||
	   effective_action == ACTION_FILLING ||
	   effective_action == ACTION_EMPTYING ? MV_DOWN : direction);
	int dx = (move_dir == MV_LEFT ? -1 : move_dir == MV_RIGHT ? 1 : 0);
	int dy = (move_dir == MV_UP   ? -1 : move_dir == MV_DOWN  ? 1 : 0);
	int num_steps = (i == Ydrip_s1  ? 16 :
			 i == Ydrip_s1B ? 16 :
			 i == Ydrip_s2  ? 16 :
			 i == Ydrip_s2B ? 16 :
			 i == Xsand_stonein_1 ? 32 :
			 i == Xsand_stonein_2 ? 32 :
			 i == Xsand_stonein_3 ? 32 :
			 i == Xsand_stonein_4 ? 32 :
			 i == Xsand_stoneout_1 ? 16 :
			 i == Xsand_stoneout_2 ? 16 : 8);
	int cx = ABS(dx) * (TILEX / num_steps);
	int cy = ABS(dy) * (TILEY / num_steps);
	int step_frame = (i == Ydrip_s2         ? j + 8 :
			  i == Ydrip_s2B        ? j + 8 :
			  i == Xsand_stonein_2  ? j + 8 :
			  i == Xsand_stonein_3  ? j + 16 :
			  i == Xsand_stonein_4  ? j + 24 :
			  i == Xsand_stoneout_2 ? j + 8 : j) + 1;
	int step = (is_backside ? step_frame : num_steps - step_frame);

	if (is_backside)	/* tile where movement starts */
	{
	  if (dx < 0 || dy < 0)
	  {
	    g_em->src_offset_x = cx * step;
	    g_em->src_offset_y = cy * step;
	  }
	  else
	  {
	    g_em->dst_offset_x = cx * step;
	    g_em->dst_offset_y = cy * step;
	  }
	}
	else			/* tile where movement ends */
	{
	  if (dx < 0 || dy < 0)
	  {
	    g_em->dst_offset_x = cx * step;
	    g_em->dst_offset_y = cy * step;
	  }
	  else
	  {
	    g_em->src_offset_x = cx * step;
	    g_em->src_offset_y = cy * step;
	  }
	}

	g_em->width  = TILEX - cx * step;
	g_em->height = TILEY - cy * step;
      }

      /* create unique graphic identifier to decide if tile must be redrawn */
      /* bit 31 - 16 (16 bit): EM style graphic
	 bit 15 - 12 ( 4 bit): EM style frame
	 bit 11 -  6 ( 6 bit): graphic width
	 bit  5 -  0 ( 6 bit): graphic height */
      g_em->unique_identifier =
	(graphic << 16) | (frame << 12) | (g_em->width << 6) | g_em->height;

#if DEBUG_EM_GFX

      /* skip check for EMC elements not contained in original EMC artwork */
      if (element == EL_EMC_FAKE_ACID)
	continue;

      if (g_em->bitmap != debug_bitmap ||
	  g_em->src_x != debug_src_x ||
	  g_em->src_y != debug_src_y ||
	  g_em->src_offset_x != 0 ||
	  g_em->src_offset_y != 0 ||
	  g_em->dst_offset_x != 0 ||
	  g_em->dst_offset_y != 0 ||
	  g_em->width != TILEX ||
	  g_em->height != TILEY)
      {
	static int last_i = -1;

	if (i != last_i)
	{
	  printf("\n");
	  last_i = i;
	}

	printf("::: EMC GFX ERROR for element %d -> %d ('%s', '%s', %d)",
	       i, element, element_info[element].token_name,
	       element_action_info[effective_action].suffix, direction);

	if (element != effective_element)
	  printf(" [%d ('%s')]",
		 effective_element,
		 element_info[effective_element].token_name);

	printf("\n");

	if (g_em->bitmap != debug_bitmap)
	  printf("    %d (%d): different bitmap! (0x%08x != 0x%08x)\n",
		 j, is_backside, (int)(g_em->bitmap), (int)(debug_bitmap));

	if (g_em->src_x != debug_src_x ||
	    g_em->src_y != debug_src_y)
	  printf("    frame %d (%c): %d,%d (%d,%d) should be %d,%d (%d,%d)\n",
		 j, (is_backside ? 'B' : 'F'),
		 g_em->src_x, g_em->src_y,
		 g_em->src_x / 32, g_em->src_y / 32,
		 debug_src_x, debug_src_y,
		 debug_src_x / 32, debug_src_y / 32);

	if (g_em->src_offset_x != 0 ||
	    g_em->src_offset_y != 0 ||
	    g_em->dst_offset_x != 0 ||
	    g_em->dst_offset_y != 0)
	  printf("    %d (%d): offsets %d,%d and %d,%d should be all 0\n",
		 j, is_backside,
		 g_em->src_offset_x, g_em->src_offset_y,
		 g_em->dst_offset_x, g_em->dst_offset_y);

	if (g_em->width != TILEX ||
	    g_em->height != TILEY)
	  printf("    %d (%d): size %d,%d should be %d,%d\n",
		 j, is_backside,
		 g_em->width, g_em->height, TILEX, TILEY);

	num_em_gfx_errors++;
      }
#endif

    }
  }

  for (i = 0; i < TILE_MAX; i++)
  {
    for (j = 0; j < 8; j++)
    {
      int element = object_mapping[i].element_rnd;
      int action = object_mapping[i].action;
      int direction = object_mapping[i].direction;
      boolean is_backside = object_mapping[i].is_backside;
      int graphic_action  = el_act_dir2img(element, action, direction);
      int graphic_default = el_act_dir2img(element, ACTION_DEFAULT, direction);

      if ((action == ACTION_SMASHED_BY_ROCK ||
	   action == ACTION_SMASHED_BY_SPRING ||
	   action == ACTION_EATING) &&
	  graphic_action == graphic_default)
      {
	int e = (action == ACTION_SMASHED_BY_ROCK   ? Ystone_s  :
		 action == ACTION_SMASHED_BY_SPRING ? Yspring_s :
		 direction == MV_LEFT  ? (is_backside? Yspring_wB: Yspring_w) :
		 direction == MV_RIGHT ? (is_backside? Yspring_eB: Yspring_e) :
		 Xspring);

	/* no separate animation for "smashed by rock" -- use rock instead */
	struct GraphicInfo_EM *g_em = &graphic_info_em_object[i][7 - j];
	struct GraphicInfo_EM *g_xx = &graphic_info_em_object[e][7 - j];

	g_em->bitmap		= g_xx->bitmap;
	g_em->src_x		= g_xx->src_x;
	g_em->src_y		= g_xx->src_y;
	g_em->src_offset_x	= g_xx->src_offset_x;
	g_em->src_offset_y	= g_xx->src_offset_y;
	g_em->dst_offset_x	= g_xx->dst_offset_x;
	g_em->dst_offset_y	= g_xx->dst_offset_y;
	g_em->width 		= g_xx->width;
	g_em->height		= g_xx->height;
	g_em->unique_identifier	= g_xx->unique_identifier;

	if (!is_backside)
	  g_em->preserve_background = TRUE;
      }
    }
  }

  for (p = 0; p < MAX_PLAYERS; p++)
  {
    for (i = 0; i < SPR_MAX; i++)
    {
      int element = player_mapping[p][i].element_rnd;
      int action = player_mapping[p][i].action;
      int direction = player_mapping[p][i].direction;

      for (j = 0; j < 8; j++)
      {
	int effective_element = element;
	int effective_action = action;
	int graphic = (direction == MV_NONE ?
		       el_act2img(effective_element, effective_action) :
		       el_act_dir2img(effective_element, effective_action,
				      direction));
	struct GraphicInfo *g = &graphic_info[graphic];
	struct GraphicInfo_EM *g_em = &graphic_info_em_player[p][i][7 - j];
	Bitmap *src_bitmap;
	int src_x, src_y;
	int sync_frame = j;

#if DEBUG_EM_GFX
	Bitmap *debug_bitmap = g_em->bitmap;
	int debug_src_x = g_em->src_x;
	int debug_src_y = g_em->src_y;
#endif

	int frame = getAnimationFrame(g->anim_frames,
				      g->anim_delay,
				      g->anim_mode,
				      g->anim_start_frame,
				      sync_frame);

	getGraphicSourceExt(graphic, frame, &src_bitmap, &src_x, &src_y, FALSE);

	g_em->bitmap = src_bitmap;
	g_em->src_x = src_x;
	g_em->src_y = src_y;
	g_em->src_offset_x = 0;
	g_em->src_offset_y = 0;
	g_em->dst_offset_x = 0;
	g_em->dst_offset_y = 0;
	g_em->width  = TILEX;
	g_em->height = TILEY;

#if DEBUG_EM_GFX

	/* skip check for EMC elements not contained in original EMC artwork */
	if (element == EL_PLAYER_3 ||
	    element == EL_PLAYER_4)
	  continue;

	if (g_em->bitmap != debug_bitmap ||
	    g_em->src_x != debug_src_x ||
	    g_em->src_y != debug_src_y)
	{
	  static int last_i = -1;

	  if (i != last_i)
	  {
	    printf("\n");
	    last_i = i;
	  }

	  printf("::: EMC GFX ERROR for p/a %d/%d -> %d ('%s', '%s', %d)",
		 p, i, element, element_info[element].token_name,
		 element_action_info[effective_action].suffix, direction);

	  if (element != effective_element)
	    printf(" [%d ('%s')]",
		   effective_element,
		   element_info[effective_element].token_name);

	  printf("\n");

	  if (g_em->bitmap != debug_bitmap)
	    printf("    %d: different bitmap! (0x%08x != 0x%08x)\n",
		   j, (int)(g_em->bitmap), (int)(debug_bitmap));

	  if (g_em->src_x != debug_src_x ||
	      g_em->src_y != debug_src_y)
	    printf("    frame %d: %d,%d (%d,%d) should be %d,%d (%d,%d)\n",
		   j,
		   g_em->src_x, g_em->src_y,
		   g_em->src_x / 32, g_em->src_y / 32,
		   debug_src_x, debug_src_y,
		   debug_src_x / 32, debug_src_y / 32);

	  num_em_gfx_errors++;
	}
#endif

      }
    }
  }

#if DEBUG_EM_GFX
  printf("\n");
  printf("::: [%d errors found]\n", num_em_gfx_errors);

  exit(0);
#endif
}

void CheckSingleStepMode_EM(byte action[MAX_PLAYERS], int frame,
			    boolean any_player_moving,
			    boolean player_is_dropping)
{
  if (tape.single_step && tape.recording && !tape.pausing)
  {
#if 0
    boolean active_players = FALSE;
    int i;

    for (i = 0; i < MAX_PLAYERS; i++)
      if (action[i] != JOY_NO_ACTION)
	active_players = TRUE;
#endif

    // if (frame == 0)
    if (frame == 0 && !player_is_dropping)
      TapeTogglePause(TAPE_TOGGLE_AUTOMATIC);
  }
}

void CheckSingleStepMode_SP(boolean murphy_is_waiting,
			    boolean murphy_is_dropping)
{
#if 0
  printf("::: waiting: %d, dropping: %d\n",
	 murphy_is_waiting, murphy_is_dropping);
#endif

  if (tape.single_step && tape.recording && !tape.pausing)
  {
    // if (murphy_is_waiting || murphy_is_dropping)
    if (murphy_is_waiting)
    {
#if 0
      printf("::: murphy is waiting -> pause mode\n");
#endif

      TapeTogglePause(TAPE_TOGGLE_AUTOMATIC);
    }
  }
}

void getGraphicSource_SP(struct GraphicInfo_SP *g_sp,
			 int graphic, int sync_frame, int x, int y)
{
  int frame = getGraphicAnimationFrame(graphic, sync_frame);

  getGraphicSource(graphic, frame, &g_sp->bitmap, &g_sp->src_x, &g_sp->src_y);
}

boolean isNextAnimationFrame_SP(int graphic, int sync_frame)
{
  return (IS_NEXT_FRAME(sync_frame, graphic));
}

int getGraphicInfo_Delay(int graphic)
{
  return graphic_info[graphic].anim_delay;
}

void PlayMenuSoundExt(int sound)
{
  if (sound == SND_UNDEFINED)
    return;

  if ((!setup.sound_simple && !IS_LOOP_SOUND(sound)) ||
      (!setup.sound_loops && IS_LOOP_SOUND(sound)))
    return;

  if (IS_LOOP_SOUND(sound))
    PlaySoundLoop(sound);
  else
    PlaySound(sound);
}

void PlayMenuSound()
{
  PlayMenuSoundExt(menu.sound[game_status]);
}

void PlayMenuSoundStereo(int sound, int stereo_position)
{
  if (sound == SND_UNDEFINED)
    return;

  if ((!setup.sound_simple && !IS_LOOP_SOUND(sound)) ||
      (!setup.sound_loops && IS_LOOP_SOUND(sound)))
    return;

  if (IS_LOOP_SOUND(sound))
    PlaySoundExt(sound, SOUND_MAX_VOLUME, stereo_position, SND_CTRL_PLAY_LOOP);
  else
    PlaySoundStereo(sound, stereo_position);
}

void PlayMenuSoundIfLoopExt(int sound)
{
  if (sound == SND_UNDEFINED)
    return;

  if ((!setup.sound_simple && !IS_LOOP_SOUND(sound)) ||
      (!setup.sound_loops && IS_LOOP_SOUND(sound)))
    return;

  if (IS_LOOP_SOUND(sound))
    PlaySoundLoop(sound);
}

void PlayMenuSoundIfLoop()
{
  PlayMenuSoundIfLoopExt(menu.sound[game_status]);
}

void PlayMenuMusicExt(int music)
{
  if (music == MUS_UNDEFINED)
    return;

  if (!setup.sound_music)
    return;

  PlayMusic(music);
}

void PlayMenuMusic()
{
  PlayMenuMusicExt(menu.music[game_status]);
}

void PlaySoundActivating()
{
#if 0
  PlaySound(SND_MENU_ITEM_ACTIVATING);
#endif
}

void PlaySoundSelecting()
{
#if 0
  PlaySound(SND_MENU_ITEM_SELECTING);
#endif
}

void ToggleFullscreenIfNeeded()
{
  boolean change_fullscreen = (setup.fullscreen !=
			       video.fullscreen_enabled);
  boolean change_fullscreen_mode = (video.fullscreen_enabled &&
				    !strEqual(setup.fullscreen_mode,
					      video.fullscreen_mode_current));

  if (!video.fullscreen_available)
    return;

  if (change_fullscreen || change_fullscreen_mode)
  {
    Bitmap *tmp_backbuffer = CreateBitmap(WIN_XSIZE, WIN_YSIZE, DEFAULT_DEPTH);

    /* save backbuffer content which gets lost when toggling fullscreen mode */
    BlitBitmap(backbuffer, tmp_backbuffer, 0, 0, WIN_XSIZE, WIN_YSIZE, 0, 0);

    if (change_fullscreen_mode)
    {
      /* keep fullscreen, but change fullscreen mode (screen resolution) */
      video.fullscreen_enabled = FALSE;		/* force new fullscreen mode */
    }

    /* toggle fullscreen */
    ChangeVideoModeIfNeeded(setup.fullscreen);

    setup.fullscreen = video.fullscreen_enabled;

    /* restore backbuffer content from temporary backbuffer backup bitmap */
    BlitBitmap(tmp_backbuffer, backbuffer, 0, 0, WIN_XSIZE, WIN_YSIZE, 0, 0);

    FreeBitmap(tmp_backbuffer);

#if 1
    /* update visible window/screen */
    BlitBitmap(backbuffer, window, 0, 0, WIN_XSIZE, WIN_YSIZE, 0, 0);
#else
    redraw_mask = REDRAW_ALL;
#endif
  }
}

void ChangeViewportPropertiesIfNeeded()
{
  int *door_1_x = &DX;
  int *door_1_y = &DY;
  int *door_2_x = (game_status == GAME_MODE_EDITOR ? &EX : &VX);
  int *door_2_y = (game_status == GAME_MODE_EDITOR ? &EY : &VY);
  int gfx_game_mode = (game_status == GAME_MODE_PLAYING ||
		       game_status == GAME_MODE_EDITOR ? game_status :
		       GAME_MODE_MAIN);
  struct RectWithBorder *vp_playfield = &viewport.playfield[gfx_game_mode];
  struct RectWithBorder *vp_door_1 = &viewport.door_1[gfx_game_mode];
  struct RectWithBorder *vp_door_2 = &viewport.door_2[gfx_game_mode];
  int border_size = vp_playfield->border_size;
  int new_sx = vp_playfield->x + border_size;
  int new_sy = vp_playfield->y + border_size;
  int new_sxsize = vp_playfield->width  - 2 * border_size;
  int new_sysize = vp_playfield->height - 2 * border_size;
  int new_real_sx = vp_playfield->x;
  int new_real_sy = vp_playfield->y;
  int new_full_sxsize = vp_playfield->width;
  int new_full_sysize = vp_playfield->height;
#if NEW_TILESIZE
  int new_tilesize_var = TILESIZE / (setup.small_game_graphics ? 2 : 1);
  int tilesize = (gfx_game_mode == GAME_MODE_PLAYING ? new_tilesize_var :
		  gfx_game_mode == GAME_MODE_EDITOR ? MINI_TILESIZE : TILESIZE);
  int new_scr_fieldx = new_sxsize / tilesize;
  int new_scr_fieldy = new_sysize / tilesize;
  int new_scr_fieldx_buffers = new_sxsize / new_tilesize_var;
  int new_scr_fieldy_buffers = new_sysize / new_tilesize_var;
#else
  int new_scr_fieldx = (vp_playfield->width  - 2 * border_size) / TILESIZE;
  int new_scr_fieldy = (vp_playfield->height - 2 * border_size) / TILESIZE;
#endif
  boolean init_gfx_buffers = FALSE;
  boolean init_video_buffer = FALSE;
  boolean init_gadgets_and_toons = FALSE;

#if 0
  /* !!! TEST ONLY !!! */
  // InitGfxBuffers();
  return;
#endif

  if (viewport.window.width  != WIN_XSIZE ||
      viewport.window.height != WIN_YSIZE)
  {
    WIN_XSIZE = viewport.window.width;
    WIN_YSIZE = viewport.window.height;

#if 1
    init_video_buffer = TRUE;
    init_gfx_buffers = TRUE;
#else
    InitVideoBuffer(WIN_XSIZE, WIN_YSIZE, DEFAULT_DEPTH, setup.fullscreen);
    InitGfxBuffers();

#if 1
    SetDrawDeactivationMask(REDRAW_NONE);
    SetDrawBackgroundMask(REDRAW_FIELD);

    // RedrawBackground();
#endif
#endif

    // printf("::: video: init_video_buffer, init_gfx_buffers\n");
  }

  if (new_scr_fieldx != SCR_FIELDX ||
      new_scr_fieldy != SCR_FIELDY)
  {
    /* this always toggles between MAIN and GAME when using small tile size */

    SCR_FIELDX = new_scr_fieldx;
    SCR_FIELDY = new_scr_fieldy;

    // printf("::: new_scr_fieldx != SCR_FIELDX ...\n");
  }

#if 0
  if (new_tilesize_var != TILESIZE_VAR &&
      gfx_game_mode == GAME_MODE_PLAYING)
  {
    /* doing this outside GAME_MODE_PLAYING would give wrong playfield size */

    TILESIZE_VAR = new_tilesize_var;

    init_gfx_buffers = TRUE;

    // printf("::: tilesize: init_gfx_buffers\n");
  }
#endif

  if (new_sx != SX ||
      new_sy != SY ||
      new_sxsize != SXSIZE ||
      new_sysize != SYSIZE ||
      new_real_sx != REAL_SX ||
      new_real_sy != REAL_SY ||
      new_full_sxsize != FULL_SXSIZE ||
      new_full_sysize != FULL_SYSIZE ||
      new_tilesize_var != TILESIZE_VAR ||
      vp_door_1->x != *door_1_x ||
      vp_door_1->y != *door_1_y ||
      vp_door_2->x != *door_2_x ||
      vp_door_2->y != *door_2_y)
  {
    SX = new_sx;
    SY = new_sy;
    SXSIZE = new_sxsize;
    SYSIZE = new_sysize;
    REAL_SX = new_real_sx;
    REAL_SY = new_real_sy;
    FULL_SXSIZE = new_full_sxsize;
    FULL_SYSIZE = new_full_sysize;
    TILESIZE_VAR = new_tilesize_var;

#if 0
    printf("::: %d, %d, %d [%d]\n",
	   SCR_FIELDX, SCR_FIELDY, TILESIZE_VAR,
	   setup.small_game_graphics);
#endif

    *door_1_x = vp_door_1->x;
    *door_1_y = vp_door_1->y;
    *door_2_x = vp_door_2->x;
    *door_2_y = vp_door_2->y;

#if 1
    init_gfx_buffers = TRUE;

    // printf("::: viewports: init_gfx_buffers\n");
#else
    InitGfxBuffers();
#endif

    if (gfx_game_mode == GAME_MODE_MAIN)
    {
#if 1
      init_gadgets_and_toons = TRUE;

      // printf("::: viewports: init_gadgets_and_toons\n");
#else
      InitGadgets();
      InitToons();
#endif
    }
  }

  if (init_gfx_buffers)
  {
    // printf("::: init_gfx_buffers\n");

    SCR_FIELDX = new_scr_fieldx_buffers;
    SCR_FIELDY = new_scr_fieldy_buffers;

    InitGfxBuffers();

    SCR_FIELDX = new_scr_fieldx;
    SCR_FIELDY = new_scr_fieldy;
  }

  if (init_video_buffer)
  {
    // printf("::: init_video_buffer\n");

    InitVideoBuffer(WIN_XSIZE, WIN_YSIZE, DEFAULT_DEPTH, setup.fullscreen);

    SetDrawDeactivationMask(REDRAW_NONE);
    SetDrawBackgroundMask(REDRAW_FIELD);
  }

  if (init_gadgets_and_toons)
  {
    // printf("::: init_gadgets_and_toons\n");

    InitGadgets();
    InitToons();
  }

#if 0
  printf("::: %d, %d  /  %d, %d [%d]\n", VX, VY, EX, EY, game_status);
#endif
}
