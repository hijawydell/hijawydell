Terimakasih sudah mendownload Platypus II di Blog ralfar-library.blogspot.com
Readme ini untuk kalian yang tidak bisa menginstall atau tidak bisa menjalankan aplikasi nya.
Ikuti dengan benar dan praktekan ini!

1.Ekstrak File "Platypus_II" di Desktop (atau dimana pun yang anda suka)
2.buka platypus2.exe dan Install
3.Enjoy!

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Licence Name: cindy kamka
Licence Code: txqb7-kdrq8-fnsvn

Oke Selamat bermain dan jangan lupa untuk Follow dan meninggalkan komentar di blog kami ^_^